import { accounts, sessions, users, verifications } from "./schema/auth";
import { orderShipments } from "./schema/courier-checker";
import { orderFlows } from "./schema/order-flow";
import { orderPackings, orderPickings } from "./schema/pick-and-pack";
import { courierPincodes, zoneMappings } from "./schema/pincodes";
import { products } from "./schema/products";
import { rateConditions, rates, rateSlabs } from "./schema/rates";
import {
  damagedProductsRecords,
  inboundInventoryRecords,
  offlineSalesRecords,
  recoveredProductsRecords,
  seedsBundlingRecords,
} from "./schema/records";
import { orderReviews } from "./schema/review-desk";
import { boxes, couriers } from "./schema/shipping";
import { vendorInquiries, vendorInquiryProducts, vendorProducts, vendors } from "./schema/vendor";
import { warehouses } from "./schema/warehouse";

export type OrderReview = typeof orderReviews.$inferSelect;
export type OrderShipment = typeof orderShipments.$inferSelect;
export type OrderFlow = typeof orderFlows.$inferSelect;
export type OrderPacking = typeof orderPackings.$inferSelect;
export type OrderPicking = typeof orderPickings.$inferSelect;
export type User = typeof users.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type Account = typeof accounts.$inferSelect;
export type Verification = typeof verifications.$inferSelect;
export type Vendor = typeof vendors.$inferSelect;
export type VendorInquiry = typeof vendorInquiries.$inferSelect;
export type VendorProduct = typeof vendorProducts.$inferSelect;
export type VendorInquiryProduct = typeof vendorInquiryProducts.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Warehouse = typeof warehouses.$inferSelect;
export type Courier = typeof couriers.$inferSelect;
export type Box = typeof boxes.$inferSelect;
export type Rate = typeof rates.$inferSelect;
export type RateSlab = typeof rateSlabs.$inferSelect;
export type RateCondition = typeof rateConditions.$inferSelect;
export type CourierPincode = typeof courierPincodes.$inferSelect;
export type ZoneMapping = typeof zoneMappings.$inferSelect;
export type SeedsBundlingRecord = typeof seedsBundlingRecords.$inferSelect;
export type DamagedProductsRecord = typeof damagedProductsRecords.$inferSelect;
export type InboundInventoryRecord = typeof inboundInventoryRecords.$inferSelect;
export type OfflineSalesRecord = typeof offlineSalesRecords.$inferSelect;
export type RecoveredProductsRecord = typeof recoveredProductsRecords.$inferSelect;
