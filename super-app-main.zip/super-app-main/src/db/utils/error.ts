export const DB_ERROR_CODES = {
  UNIQUE_VIOLATION: "23505",
  FOREIGN_KEY_VIOLATION: "23503",
  NOT_NULL_VIOLATION: "23502",
  CHECK_VIOLATION: "23514",
  PROTOCOL_VIOLATION: "08P01",

  // Connection and authentication errors
  CONNECTION_FAILURE: "08006",
  CONNECTION_DOES_NOT_EXIST: "08003",
  INVALID_PASSWORD: "28P01",
  INVALID_AUTHORIZATION: "28000",

  // Transaction-related error codes
  SERIALIZATION_FAILURE: "40001", // Transaction was rolled back due to serialization failure
  DEADLOCK_DETECTED: "40P01", // Deadlock detected
  TRANSACTION_ROLLBACK: "25P02", // Transaction is aborted, commands ignored until end of transaction block

  // Data type and syntax errors
  INVALID_TEXT_REPRESENTATION: "22P02", // Invalid input syntax for type
  NUMERIC_VALUE_OUT_OF_RANGE: "22003",
  DIVISION_BY_ZERO: "22012",
  INVALID_DATETIME_FORMAT: "22007",

  // Permission and access errors
  INSUFFICIENT_PRIVILEGE: "42501",
  UNDEFINED_TABLE: "42P01",
  UNDEFINED_COLUMN: "42703",
  UNDEFINED_FUNCTION: "42883",

  // Disk and resource errors
  DISK_FULL: "53100",
  OUT_OF_MEMORY: "53200",
  TOO_MANY_CONNECTIONS: "53300",
} as const;

export interface DatabaseError extends Error {
  readonly code?: string;
  readonly constraint?: string;
  readonly detail?: string;
  readonly table?: string;
  readonly column?: string;
}

export interface ErrorMessages {
  readonly uniqueConstraint?: string;
  readonly foreignKeyConstraint?: string;
  readonly notNullConstraint?: string;
  readonly checkConstraint?: string;
  readonly parameterLimit?: string;
  readonly notFound?: string;
  readonly transactionConflict?: string;
  readonly deadlock?: string;
  readonly transactionAborted?: string;
  readonly connectionFailure?: string;
  readonly authenticationFailure?: string;
  readonly invalidInput?: string;
  readonly permissionDenied?: string;
  readonly resourceExhausted?: string;
  readonly fallback?: string;
}

export function isDatabaseError(error: unknown): error is DatabaseError {
  return hasDatabaseErrorCode(error) || hasDatabaseErrorInCause(error);
}

function hasDatabaseErrorCode(error: unknown): error is DatabaseError {
  return error instanceof Error && typeof (error as any).code === "string";
}

function hasDatabaseErrorInCause(error: unknown): boolean {
  return error != null && typeof error === "object" && "cause" in error && hasDatabaseErrorCode((error as any).cause);
}

export function extractDatabaseError(error: unknown): DatabaseError | null {
  if (hasDatabaseErrorCode(error)) {
    return error;
  }

  if (hasDatabaseErrorInCause(error)) {
    return (error as any).cause as DatabaseError;
  }

  return null;
}

const DEFAULT_ERROR_MESSAGES = {
  [DB_ERROR_CODES.UNIQUE_VIOLATION]: "Record already exists with this combination",
  [DB_ERROR_CODES.FOREIGN_KEY_VIOLATION]: "Invalid reference - please ensure the referenced record exists",
  [DB_ERROR_CODES.NOT_NULL_VIOLATION]: "Required field is missing",
  [DB_ERROR_CODES.CHECK_VIOLATION]: "Data violates check constraint",
  [DB_ERROR_CODES.PROTOCOL_VIOLATION]: "Too many parameters - try reducing the batch size",

  // Connection and authentication errors
  [DB_ERROR_CODES.CONNECTION_FAILURE]: "Database connection failed",
  [DB_ERROR_CODES.CONNECTION_DOES_NOT_EXIST]: "Database connection lost",
  [DB_ERROR_CODES.INVALID_PASSWORD]: "Invalid database credentials",
  [DB_ERROR_CODES.INVALID_AUTHORIZATION]: "Database authentication failed",

  // Transaction error messages
  [DB_ERROR_CODES.SERIALIZATION_FAILURE]: "Transaction conflict detected - please retry the operation",
  [DB_ERROR_CODES.DEADLOCK_DETECTED]: "Database deadlock detected - please retry the operation",
  [DB_ERROR_CODES.TRANSACTION_ROLLBACK]: "Transaction was aborted - please retry the operation",

  // Data type and syntax errors
  [DB_ERROR_CODES.INVALID_TEXT_REPRESENTATION]: "Invalid data format provided",
  [DB_ERROR_CODES.NUMERIC_VALUE_OUT_OF_RANGE]: "Numeric value is out of range",
  [DB_ERROR_CODES.DIVISION_BY_ZERO]: "Division by zero is not allowed",
  [DB_ERROR_CODES.INVALID_DATETIME_FORMAT]: "Invalid date or time format",

  // Permission and access errors
  [DB_ERROR_CODES.INSUFFICIENT_PRIVILEGE]: "Insufficient permissions to perform this operation",
  [DB_ERROR_CODES.UNDEFINED_TABLE]: "Table does not exist",
  [DB_ERROR_CODES.UNDEFINED_COLUMN]: "Column does not exist",
  [DB_ERROR_CODES.UNDEFINED_FUNCTION]: "Function does not exist",

  // Resource errors
  [DB_ERROR_CODES.DISK_FULL]: "Database storage is full",
  [DB_ERROR_CODES.OUT_OF_MEMORY]: "Database server is out of memory",
  [DB_ERROR_CODES.TOO_MANY_CONNECTIONS]: "Too many database connections",

  DEFAULT: "Database operation failed",
  NOT_FOUND: "Record not found",
} as const;

/**
 * Creates a database error message with optional custom messages
 *
 * This function handles various database errors including:
 * - Standard constraint violations (unique, foreign key, not null, check)
 * - Connection and authentication errors
 * - Transaction-related errors:
 *   - Serialization failures: Occur when concurrent transactions conflict
 *   - Deadlocks: When two or more transactions are waiting for each other
 *   - Transaction rollbacks: When a transaction is aborted and needs to be retried
 * - Data type and syntax errors
 * - Permission and access errors
 * - Resource exhaustion errors
 *
 * Transaction errors are typically recoverable by retrying the operation,
 * while constraint violations usually require data changes.
 *
 * @param error - The database error (can be nested in cause property)
 * @param customMessages - Optional custom error messages for each error type
 * @returns User-friendly error message
 */
export function getDatabaseErrorMessage(error: unknown, customMessages: ErrorMessages = {}): string {
  const dbError = extractDatabaseError(error);

  if (!dbError?.code) {
    return customMessages.fallback || DEFAULT_ERROR_MESSAGES.DEFAULT;
  }

  switch (dbError.code) {
    case DB_ERROR_CODES.UNIQUE_VIOLATION:
      return customMessages.uniqueConstraint || DEFAULT_ERROR_MESSAGES[DB_ERROR_CODES.UNIQUE_VIOLATION];

    case DB_ERROR_CODES.FOREIGN_KEY_VIOLATION:
      return customMessages.foreignKeyConstraint || DEFAULT_ERROR_MESSAGES[DB_ERROR_CODES.FOREIGN_KEY_VIOLATION];

    case DB_ERROR_CODES.NOT_NULL_VIOLATION:
      return customMessages.notNullConstraint || DEFAULT_ERROR_MESSAGES[DB_ERROR_CODES.NOT_NULL_VIOLATION];

    case DB_ERROR_CODES.CHECK_VIOLATION:
      return customMessages.checkConstraint || DEFAULT_ERROR_MESSAGES[DB_ERROR_CODES.CHECK_VIOLATION];

    case DB_ERROR_CODES.PROTOCOL_VIOLATION:
      return customMessages.parameterLimit || DEFAULT_ERROR_MESSAGES[DB_ERROR_CODES.PROTOCOL_VIOLATION];

    // Connection and authentication errors
    case DB_ERROR_CODES.CONNECTION_FAILURE:
    case DB_ERROR_CODES.CONNECTION_DOES_NOT_EXIST:
      return customMessages.connectionFailure || DEFAULT_ERROR_MESSAGES[dbError.code];

    case DB_ERROR_CODES.INVALID_PASSWORD:
    case DB_ERROR_CODES.INVALID_AUTHORIZATION:
      return customMessages.authenticationFailure || DEFAULT_ERROR_MESSAGES[dbError.code];

    // Transaction error handling - these are typically retryable errors
    case DB_ERROR_CODES.SERIALIZATION_FAILURE:
      return customMessages.transactionConflict || DEFAULT_ERROR_MESSAGES[DB_ERROR_CODES.SERIALIZATION_FAILURE];

    case DB_ERROR_CODES.DEADLOCK_DETECTED:
      return customMessages.deadlock || DEFAULT_ERROR_MESSAGES[DB_ERROR_CODES.DEADLOCK_DETECTED];

    case DB_ERROR_CODES.TRANSACTION_ROLLBACK:
      return customMessages.transactionAborted || DEFAULT_ERROR_MESSAGES[DB_ERROR_CODES.TRANSACTION_ROLLBACK];

    // Data type and syntax errors
    case DB_ERROR_CODES.INVALID_TEXT_REPRESENTATION:
    case DB_ERROR_CODES.NUMERIC_VALUE_OUT_OF_RANGE:
    case DB_ERROR_CODES.DIVISION_BY_ZERO:
    case DB_ERROR_CODES.INVALID_DATETIME_FORMAT:
      return customMessages.invalidInput || DEFAULT_ERROR_MESSAGES[dbError.code];

    // Permission and access errors
    case DB_ERROR_CODES.INSUFFICIENT_PRIVILEGE:
    case DB_ERROR_CODES.UNDEFINED_TABLE:
    case DB_ERROR_CODES.UNDEFINED_COLUMN:
    case DB_ERROR_CODES.UNDEFINED_FUNCTION:
      return customMessages.permissionDenied || DEFAULT_ERROR_MESSAGES[dbError.code];

    // Resource errors
    case DB_ERROR_CODES.DISK_FULL:
    case DB_ERROR_CODES.OUT_OF_MEMORY:
    case DB_ERROR_CODES.TOO_MANY_CONNECTIONS:
      return customMessages.resourceExhausted || DEFAULT_ERROR_MESSAGES[dbError.code];

    default:
      return handleUnknownError(dbError, customMessages);
  }
}

/**
 * Checks if the error is a retryable transaction error
 * These errors typically occur due to concurrent access and can be resolved by retrying
 */
export function isRetryableTransactionError(error: unknown): boolean {
  const dbError = extractDatabaseError(error);

  if (!dbError?.code) {
    return false;
  }

  return [
    DB_ERROR_CODES.SERIALIZATION_FAILURE,
    DB_ERROR_CODES.DEADLOCK_DETECTED,
    DB_ERROR_CODES.TRANSACTION_ROLLBACK,
  ].includes(dbError.code as any);
}

/**
 * Checks if the error is a connection-related error
 * These errors indicate issues with database connectivity
 */
export function isConnectionError(error: unknown): boolean {
  const dbError = extractDatabaseError(error);

  if (!dbError?.code) {
    return false;
  }

  return [
    DB_ERROR_CODES.CONNECTION_FAILURE,
    DB_ERROR_CODES.CONNECTION_DOES_NOT_EXIST,
    DB_ERROR_CODES.TOO_MANY_CONNECTIONS,
  ].includes(dbError.code as any);
}

/**
 * Checks if the error is an authentication-related error
 */
export function isAuthenticationError(error: unknown): boolean {
  const dbError = extractDatabaseError(error);

  if (!dbError?.code) {
    return false;
  }

  return [DB_ERROR_CODES.INVALID_PASSWORD, DB_ERROR_CODES.INVALID_AUTHORIZATION].includes(dbError.code as any);
}

function handleUnknownError(dbError: DatabaseError, customMessages: ErrorMessages): string {
  const isNotFoundError = dbError.message?.includes("not found") || dbError.message?.includes("no rows");

  if (isNotFoundError) {
    return customMessages.notFound || DEFAULT_ERROR_MESSAGES.NOT_FOUND;
  }

  return customMessages.fallback || DEFAULT_ERROR_MESSAGES.DEFAULT;
}
