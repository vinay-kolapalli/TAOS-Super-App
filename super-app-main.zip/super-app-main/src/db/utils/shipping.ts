import { SelectOption } from "@/types/general";
import { db } from "..";

export async function getCourierOptions(): Promise<SelectOption[]> {
  const couriers = await db.query.couriers.findMany({
    limit: 500,
    columns: {
      id: true,
      name: true,
    },
  });
  const courierOptions = couriers.map((courier) => ({ label: courier.name, value: courier.id }));
  return courierOptions;
}

export async function getBoxOptions(): Promise<SelectOption[]> {
  const boxes = await db.query.boxes.findMany({
    limit: 500,
    columns: {
      id: true,
      name: true,
    },
  });
  const boxOptions = boxes.map((box) => ({ label: box.name, value: box.id }));
  return boxOptions;
}
