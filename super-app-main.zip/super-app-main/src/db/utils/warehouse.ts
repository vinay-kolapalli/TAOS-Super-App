import { db } from "@/db";
import { warehouses } from "@/db/schema/warehouse";
import { SelectOption } from "@/types/general";
import { eq } from "drizzle-orm";

export async function getWarehouse(warehouseId: number) {
  const warehouse = await db.query.warehouses.findFirst({
    where: eq(warehouses.id, warehouseId),
  });
  if (!warehouse) {
    throw new Error("Warehouse not found");
  }
  return warehouse;
}

export async function getWarehouseOptions(): Promise<SelectOption[]> {
  const warehouses = await db.query.warehouses.findMany({
    limit: 500,
    columns: {
      id: true,
      name: true,
    },
  });
  const warehouseOptions = warehouses.map((warehouse) => ({ label: warehouse.name, value: String(warehouse.id) }));
  return warehouseOptions;
}
