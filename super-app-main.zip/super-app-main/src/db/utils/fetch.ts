export async function fetchAllData<T extends { id: any }>(
  cursor: any | undefined,
  callback: (cursor?: any) => Promise<T[]>
): Promise<T[]> {
  const data = await callback(cursor);

  if (data.length === 0) {
    return data;
  }

  const lastId = data[data.length - 1].id;

  if (lastId && lastId !== cursor) {
    const moreData = await fetchAllData(lastId, callback);
    return [...data, ...moreData];
  }

  return data;
}
