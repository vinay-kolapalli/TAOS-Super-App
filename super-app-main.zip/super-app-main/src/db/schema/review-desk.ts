import { bigint, index, integer, json, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { warehouses } from "./warehouse";

export const orderReviews = pgTable(
  "order_reviews",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    orderId: bigint("order_id", {
      mode: "number",
    }).notNull(),
    orderNumber: integer("order_number").notNull(),
    reviewedBy: text("reviewed_by").notNull(),
    scannedProducts: json("scanned_products").$type<string[]>().notNull(),
    warehouse: integer("warehouse")
      .references(() => warehouses.id)
      .notNull(),
  },
  (table) => [
    index("order_reviews_order_number_idx").on(table.orderNumber),
    index("order_reviews_created_at_warehouse_idx").on(table.createdAt, table.warehouse),
    index("order_reviews_created_at_id_warehouse_idx").on(table.createdAt, table.id, table.warehouse),
  ]
);
