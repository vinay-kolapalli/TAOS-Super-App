import { relations } from "drizzle-orm";
import { boolean, decimal, index, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import {
  courierServicesEnum,
  platformEnum,
  rateConditionOperatorsEnum,
  rateConditionsEnum,
  weightTypeEnum,
} from "./enum";
import { couriers } from "./shipping";

export const rates = pgTable(
  "rates",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    courier: text("courier")
      .references(() => couriers.id, {
        onDelete: "cascade",
      })
      .notNull(),
    service: courierServicesEnum("service").notNull(),
    displayName: text("display_name").notNull(),
    description: text("description").notNull(),
    weightType: weightTypeEnum("weight_type").notNull().default("volumetric_weight"),
    platform: platformEnum("platform"),
    isActive: boolean("is_active").notNull().default(true),
  },
  (table) => [
    index("rates_display_name_description_idx").on(table.displayName, table.description),
    index("rates_courier_is_active_idx").on(table.courier, table.isActive),
  ]
);

export const rateSlabs = pgTable(
  "rate_slabs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    slabName: text("slab_name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    platformId: text("platform_id"),
    minWeight: decimal("min_weight", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    maxWeight: decimal("max_weight", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    additionalUnit: decimal("additional_unit", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    additionalMaxWeight: decimal("additional_max_weight", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    localBaseRate: decimal("local_base_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    localAdditionalRate: decimal("local_additional_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    regionalBaseRate: decimal("regional_base_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    regionalAdditionalRate: decimal("regional_additional_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    metroBaseRate: decimal("metro_base_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    metroAdditionalRate: decimal("metro_additional_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    restOfIndiaBaseRate: decimal("rest_of_india_base_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    restOfIndiaAdditionalRate: decimal("rest_of_india_additional_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    northEastBaseRate: decimal("north_east_base_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    northEastAdditionalRate: decimal("north_east_additional_rate", {
      precision: 10,
      scale: 2,
      mode: "number",
    }).notNull(),
    rate: uuid("rate")
      .references(() => rates.id, { onDelete: "cascade" })
      .notNull(),
  },
  (table) => [index("rate_slabs_rate_is_active_idx").on(table.rate, table.isActive)]
);

export const rateConditions = pgTable(
  "rate_conditions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    type: rateConditionsEnum("type").notNull(),
    values: text("values").array().notNull(),
    operator: rateConditionOperatorsEnum("operator").notNull(),
    rate: uuid("rate")
      .references(() => rates.id, { onDelete: "cascade" })
      .notNull(),
  },
  (table) => []
);

export const ratesRelations = relations(rates, ({ one }) => ({
  courier: one(couriers, {
    fields: [rates.courier],
    references: [couriers.id],
  }),
}));
