import { relations } from "drizzle-orm";
import { bigint, boolean, decimal, index, integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { courierPlatformsEnum, courierServicesEnum, zoneEnum } from "./enum";
import { boxes, couriers } from "./shipping";
import { warehouses } from "./warehouse";

export const orderShipmentsStatus = ["pending", "delivered", "rto", "expired", "unknown"] as const;

export const orderShipments = pgTable(
  "order_shipments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    orderId: bigint("order_id", {
      mode: "number",
    }).notNull(),
    orderNumber: integer("order_number").notNull(),
    pincode: integer("pincode").notNull(),
    weight: decimal("weight", { precision: 10, scale: 2, mode: "number" }).notNull(),
    box: text("box")
      .notNull()
      .references(() => boxes.id, { onDelete: "cascade" }),
    rate: uuid("rate"),
    trackingNumber: text("tracking_number").notNull(),
    packedBy: text("packed_by").notNull(),
    scannedBy: text("scanned_by").notNull(),
    isReshipped: boolean("is_reshipped").notNull().default(false),
    nonPriorityReason: text("non_priority_reason"),
    status: text("status", { enum: orderShipmentsStatus }).notNull().default("pending"),
    pickedAt: timestamp("picked_at"),
    deliveredAt: timestamp("delivered_at"),
    warehouse: integer("warehouse")
      .references(() => warehouses.id)
      .notNull(),
  },
  (table) => [
    index("order_shipments_pincode_idx").on(table.pincode),
    index("order_shipments_order_number_idx").on(table.orderNumber),
    index("order_shipments_pincode_id_idx").on(table.pincode, table.id),
    index("order_shipments_created_at_warehouse_idx").on(table.createdAt, table.warehouse),
    index("order_shipments_created_at_warehouse_id_idx").on(table.createdAt, table.warehouse, table.id),
  ]
);

export const orderShipmentRelations = relations(orderShipments, ({ one }) => ({
  warehouse: one(warehouses, {
    fields: [orderShipments.warehouse],
    references: [warehouses.id],
  }),
  box: one(boxes, {
    fields: [orderShipments.box],
    references: [boxes.id],
  }),
  rate: one(orderShipmentRates, {
    fields: [orderShipments.rate],
    references: [orderShipmentRates.id],
  }),
}));

export const orderShipmentRates = pgTable("order_shipment_rates", {
  id: uuid("id").primaryKey().defaultRandom(),
  courier: text("courier")
    .notNull()
    .references(() => couriers.id, { onDelete: "cascade" }),
  courierService: courierServicesEnum("courier_service").notNull(),
  platform: courierPlatformsEnum("platform"),
  rate: decimal("rate", { precision: 10, scale: 2, mode: "number" }).notNull(),
  zone: zoneEnum("zone").notNull(),
  priority: integer("priority").notNull(),
  orderShipment: uuid("order_shipment")
    .notNull()
    .references(() => orderShipments.id, { onDelete: "cascade" }),
});

export const orderShipmentRatesRelations = relations(orderShipmentRates, ({ one }) => ({
  courier: one(couriers, {
    fields: [orderShipmentRates.courier],
    references: [couriers.id],
  }),
}));
