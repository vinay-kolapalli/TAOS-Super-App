import { relations } from "drizzle-orm";
import { decimal, index, integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { products } from "./products";

export const seedsBundlingRecords = pgTable(
  "seeds_bundling_records",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    date: timestamp("date").notNull(),
    product: integer("product")
      .notNull()
      .references(() => products.id, {
        onDelete: "cascade",
      }),
    issuedTo: text("issued_to").notNull(),
    issuedDate: timestamp("issued_date").notNull(),
    weight: decimal("weight", { precision: 10, scale: 2, mode: "number" }).notNull(),
    returnDate: timestamp("return_date").notNull(),
    noOfPackets: integer("no_of_packets").notNull(),
  },
  (table) => [index("seeds_bundling_records_product_issued_to_idx").on(table.product, table.issuedTo)]
);

export const damagedProductsRecords = pgTable(
  "damaged_products_records",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    date: timestamp("date").notNull(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    product: integer("product")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    quantity: integer("quantity").notNull(),
    comments: text("comments").notNull(),
  },
  (table) => [
    index("damaged_products_records_name_email_product_comments_idx").on(
      table.name,
      table.email,
      table.product,
      table.comments
    ),
  ]
);

export const recoveredProductsRecords = pgTable(
  "recovered_products_records",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    date: timestamp("date").notNull(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    product: integer("product")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    quantity: integer("quantity").notNull(),
    comments: text("comments").notNull(),
  },
  (table) => [
    index("recovered_products_records_name_email_product_comments_idx").on(
      table.name,
      table.email,
      table.product,
      table.comments
    ),
  ]
);

export const offlineSalesRecords = pgTable(
  "offline_sales_records",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    date: timestamp("date").notNull(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    product: integer("product")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    quantity: integer("quantity").notNull(),
    placeOfSale: text("place_of_sale").notNull(),
    comments: text("comments").notNull(),
  },
  (table) => [
    index("offline_sales_records_name_email_product_comments_idx").on(
      table.name,
      table.email,
      table.product,
      table.comments
    ),
  ]
);

export const inboundInventoryRecords = pgTable(
  "inbound_inventory_records",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    date: timestamp("date").notNull(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    product: integer("product")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    poNumber: text("po_number").notNull(),
    quantityOrdered: integer("quantity_ordered").notNull(),
    quantityReceived: integer("quantity_received").notNull(),
    quantityUpdated: integer("quantity_updated").notNull(),
    reason: text("reason").notNull(),
    comments: text("comments").notNull(),
  },
  (table) => [
    index("inbound_inventory_records_name_email_product_comments_idx").on(
      table.name,
      table.email,
      table.product,
      table.comments
    ),
  ]
);

export const seedsBundlingRecordsRelations = relations(seedsBundlingRecords, ({ one }) => ({
  product: one(products, {
    fields: [seedsBundlingRecords.product],
    references: [products.id],
  }),
}));

export const damagedProductsRecordsRelations = relations(damagedProductsRecords, ({ one }) => ({
  product: one(products, {
    fields: [damagedProductsRecords.product],
    references: [products.id],
  }),
}));

export const recoveredProductsRecordsRelations = relations(recoveredProductsRecords, ({ one }) => ({
  product: one(products, {
    fields: [recoveredProductsRecords.product],
    references: [products.id],
  }),
}));

export const offlineSalesRecordsRelations = relations(offlineSalesRecords, ({ one }) => ({
  product: one(products, {
    fields: [offlineSalesRecords.product],
    references: [products.id],
  }),
}));

export const inboundInventoryRecordsRelations = relations(inboundInventoryRecords, ({ one }) => ({
  product: one(products, {
    fields: [inboundInventoryRecords.product],
    references: [products.id],
  }),
}));
