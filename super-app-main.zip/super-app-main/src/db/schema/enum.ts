import {
  courierPlatforms,
  courierServiceabilityCheck,
  courierServices,
  rateConditionOperators,
  rateConditions,
  weightTypes,
  zones,
} from "@/data/shipping";
import { vendorUnits } from "@/data/vendors";
import { pgEnum } from "drizzle-orm/pg-core";

export const courierPlatformsEnum = pgEnum("warehouse_platforms", courierPlatforms);
export const courierServicesEnum = pgEnum("courier_services", courierServices);
export const courierServiceabilityCheckEnum = pgEnum("courier_serviceability_check", courierServiceabilityCheck);

export const zoneEnum = pgEnum("zone", zones);
export const platformEnum = pgEnum("platform", courierPlatforms);

export const rateConditionsEnum = pgEnum("r_conditions", rateConditions);
export const rateConditionOperatorsEnum = pgEnum("r_condition_operators", rateConditionOperators);

export const weightTypeEnum = pgEnum("weight_type", weightTypes);
export const vendorUnitEnum = pgEnum("vendor_unit", vendorUnits);
