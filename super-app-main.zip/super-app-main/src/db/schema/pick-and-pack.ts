import { index, integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { warehouses } from "./warehouse";

export const orderPackings = pgTable(
  "order_packings",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    employee: text("employee").notNull(),
    orderNumber: integer("order_number").notNull(),
    warehouse: integer("warehouse")
      .references(() => warehouses.id)
      .notNull(),
  },
  (table) => [
    index("order_packings_order_number_idx").on(table.orderNumber),
    index("order_packings_created_at_warehouse_idx").on(table.createdAt, table.warehouse),
    index("order_packings_created_at_id_warehouse_idx").on(table.createdAt, table.id, table.warehouse),
  ]
);

export const orderPickings = pgTable(
  "order_pickings",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    type: text("type").notNull(),
    employee: text("employee").notNull(),
    orderNumber: integer("order_number").notNull(),
    image: text("image"),
    warehouse: integer("warehouse")
      .references(() => warehouses.id)
      .notNull(),
  },
  (table) => [
    index("order_pickings_order_number_idx").on(table.orderNumber),
    index("order_pickings_created_at_type_warehouse_idx").on(table.createdAt, table.type, table.warehouse),
    index("order_pickings_created_at_type_id_warehouse_idx").on(table.createdAt, table.type, table.id, table.warehouse),
  ]
);
