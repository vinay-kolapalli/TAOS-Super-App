import { integer, jsonb, pgTable, text } from "drizzle-orm/pg-core";
import { courierPlatformsEnum } from "./enum";

interface WarehouseMetadata {
  shiprocketWarehouseId?: string;
  shipwayWarehouseId?: string;
  shiphereWarehouseId?: string;
  delhiveryWarehouseId?: string;
  fshipWarehouseId?: string;
  iThinkLogisticsWarehouseId?: string;
  storeId?: string;
}

export const warehouses = pgTable("warehouses", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: text("name").notNull(),
  address1: text("address1").notNull(),
  address2: text("address2").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  country: text("country").notNull(),
  pincode: integer("pincode").notNull(),
  spocName: text("spoc_name").notNull(),
  phone: text("phone").notNull(),
  availableCouriers: text("available_couriers").array().notNull().default([]),
  availablePlatforms: courierPlatformsEnum("available_platforms").array().notNull().default([]),
  metadata: jsonb("metadata").$type<WarehouseMetadata>().notNull().default({}),
});
