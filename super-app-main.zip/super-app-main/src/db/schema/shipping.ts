import { boolean, index, numeric, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { courierServiceabilityCheckEnum, courierServicesEnum } from "./enum";

export const couriers = pgTable(
  "couriers",
  {
    id: text("id").primaryKey(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    name: text("name").notNull(),
    image: text("image").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    services: courierServicesEnum("services").array().default(["surface"]).notNull(),
    serviceabilityCheck: courierServiceabilityCheckEnum("serviceability_check")
      .array()
      .default(["always_available"])
      .notNull(),
  },
  (table) => [
    index("couriers_name_idx").on(table.name),
    index("couriers_is_active_idx").on(table.isActive),
    index("couriers_id_name_idx").on(table.id, table.name),
    index("couriers_serviceability_check_idx").on(table.serviceabilityCheck),
    index("couriers_is_active_serviceability_check_idx").on(table.isActive, table.serviceabilityCheck),
  ]
);

// Boxes table
export const boxes = pgTable(
  "boxes",
  {
    id: text("id").primaryKey(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    name: text("name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    length: numeric("length", { precision: 10, scale: 2, mode: "number" }).notNull(),
    breadth: numeric("breadth", { precision: 10, scale: 2, mode: "number" }).notNull(),
    height: numeric("height", { precision: 10, scale: 2, mode: "number" }).notNull(),
    volumetricWeight: numeric("volumetric_weight", { precision: 10, scale: 2, mode: "number" }).notNull(),
  },
  (table) => [
    index("boxes_name_idx").on(table.name),
    index("boxes_is_active_idx").on(table.isActive),
    index("boxes_id_name_idx").on(table.id, table.name),
  ]
);
