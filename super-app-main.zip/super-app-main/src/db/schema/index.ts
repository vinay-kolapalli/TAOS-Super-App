import * as auth from "./auth";
import * as orderShipments from "./courier-checker";
import * as orderFlows from "./order-flow";
import * as orderPackings from "./pick-and-pack";
import * as pincodes from "./pincodes";
import * as products from "./products";
import * as rates from "./rates";
import * as records from "./records";
import * as reviewDesk from "./review-desk";
import * as shipping from "./shipping";
import * as vendor from "./vendor";
import * as warehouses from "./warehouse";

export const schema = {
  ...auth,
  ...orderFlows,
  ...orderPackings,
  ...orderShipments,
  ...products,
  ...reviewDesk,
  ...shipping,
  ...vendor,
  ...warehouses,
  ...rates,
  ...pincodes,
  ...records,
};
