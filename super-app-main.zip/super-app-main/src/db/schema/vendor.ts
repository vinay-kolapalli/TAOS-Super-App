import { relations } from "drizzle-orm";
import { decimal, index, integer, pgTable, text, timestamp, unique, uuid } from "drizzle-orm/pg-core";
import { users } from "./auth";
import { vendorUnitEnum } from "./enum";
import { products } from "./products";

export const vendorStatus = ["active", "inactive"] as const;
export type VendorStatus = (typeof vendorStatus)[number];

export const vendors = pgTable(
  "vendors",
  {
    id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    name: text("name").notNull(),
    email: text("email"),
    phone: text("phone"),
    status: text("status").notNull().default("active").$type<VendorStatus>(),
    note: text("note").notNull().default(""),
    files: text("files").array().notNull().default([]),
    createdBy: uuid("created_by")
      .references(() => users.id, {
        onDelete: "set null",
      })
      .notNull(),
    updatedBy: uuid("updated_by")
      .references(() => users.id, {
        onDelete: "set null",
      })
      .notNull(),
  },
  (table) => [
    index("vendors_status_idx").on(table.status),
    index("vendors_name_email_phone_idx").on(table.name, table.email, table.phone),
  ]
);

export const vendorRelations = relations(vendors, ({ many, one }) => ({
  inquiries: many(vendorInquiries),
  products: many(vendorProducts),
  createdBy: one(users, {
    fields: [vendors.createdBy],
    references: [users.id],
  }),
  updatedBy: one(users, {
    fields: [vendors.updatedBy],
    references: [users.id],
  }),
}));

export const vendorInquiryStatus = ["inquired", "replied", "negotiated", "abandoned", "finalized"] as const;
export type VendorInquiryStatus = (typeof vendorInquiryStatus)[number];

export const vendorInquiries = pgTable(
  "vendor_inquiries",
  {
    id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    status: text("status").notNull().default("pending").$type<VendorInquiryStatus>(),
    note: text("note").notNull().default(""),
    files: text("files").array().notNull().default([]),
    createdBy: uuid("created_by")
      .references(() => users.id, {
        onDelete: "set null",
      })
      .notNull(),
    updatedBy: uuid("updated_by")
      .references(() => users.id, {
        onDelete: "set null",
      })
      .notNull(),
    vendor: integer("vendor_id")
      .references(() => vendors.id, {
        onDelete: "cascade",
      })
      .notNull(),
  },
  (table) => [index("vendor_inquiries_created_at_idx").on(table.createdAt)]
);

export const vendorInquiryRelations = relations(vendorInquiries, ({ one, many }) => ({
  vendor: one(vendors, {
    fields: [vendorInquiries.vendor],
    references: [vendors.id],
  }),
  products: many(vendorInquiryProducts),
  createdBy: one(users, {
    fields: [vendorInquiries.createdBy],
    references: [users.id],
  }),
  updatedBy: one(users, {
    fields: [vendorInquiries.updatedBy],
    references: [users.id],
  }),
}));

export const vendorProducts = pgTable(
  "vendor_products",
  {
    id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
    quantity: integer("quantity").notNull(),
    unit: vendorUnitEnum("unit").notNull(),
    price: decimal("price", { precision: 10, scale: 2, mode: "number" }).notNull(),
    vendor: integer("vendor_id")
      .references(() => vendors.id, {
        onDelete: "cascade",
      })
      .notNull(),
    product: integer("product_id")
      .references(() => products.id, {
        onDelete: "cascade",
      })
      .notNull(),
  },
  (table) => [unique("vendor_products_vendor_product_unique").on(table.vendor, table.product)]
);

export const vendorInquiryProducts = pgTable(
  "vendor_inquiry_products",
  {
    id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
    quantity: integer("quantity").notNull(),
    unit: vendorUnitEnum("unit").notNull(),
    price: decimal("price", { precision: 10, scale: 2, mode: "number" }).notNull(),
    vendorInquiry: integer("vendor_inquiry_id")
      .references(() => vendorInquiries.id, {
        onDelete: "cascade",
      })
      .notNull(),
    product: integer("product_id")
      .references(() => products.id, {
        onDelete: "cascade",
      })
      .notNull(),
  },
  (table) => [unique("vendor_inquiry_products_inquiry_product_unique").on(table.vendorInquiry, table.product)]
);

export const vendorProductsRelations = relations(vendorProducts, ({ one }) => ({
  vendor: one(vendors, {
    fields: [vendorProducts.vendor],
    references: [vendors.id],
  }),
  product: one(products, {
    fields: [vendorProducts.product],
    references: [products.id],
  }),
}));

export const vendorInquiryProductsRelations = relations(vendorInquiryProducts, ({ one }) => ({
  vendorInquiry: one(vendorInquiries, {
    fields: [vendorInquiryProducts.vendorInquiry],
    references: [vendorInquiries.id],
  }),
  product: one(products, {
    fields: [vendorInquiryProducts.product],
    references: [products.id],
  }),
}));
