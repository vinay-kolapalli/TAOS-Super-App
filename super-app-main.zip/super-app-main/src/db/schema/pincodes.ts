import { relations } from "drizzle-orm";
import { index, integer, jsonb, pgTable, text, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { courierServicesEnum, zoneEnum } from "./enum";
import { couriers } from "./shipping";
import { warehouses } from "./warehouse";

export interface CourierPincodeMetadata {
  key: string;
  value: string;
}

export const courierPincodes = pgTable(
  "courier_pincodes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    pincode: integer().notNull(),
    metadata: jsonb("metadata").$type<CourierPincodeMetadata[]>().notNull(),
    courier: text("courier")
      .references(() => couriers.id, { onDelete: "cascade" })
      .notNull(),
    courierService: courierServicesEnum("courier_service").notNull(),
  },
  (table) => [
    index("courier_service_idx").on(table.courier, table.courierService),
    index("courier_service_pincode_idx").on(table.courier, table.courierService, table.pincode),
    uniqueIndex("pincode_courier_service_unique").on(table.pincode, table.courier, table.courierService),
  ]
);

export const zoneMappings = pgTable(
  "zone_mappings",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    pincode: integer("pincode").notNull(),
    zone: zoneEnum("zone").notNull(),
    courier: text("courier")
      .references(() => couriers.id, { onDelete: "cascade" })
      .notNull(),
    warehouse: integer("warehouse")
      .references(() => warehouses.id, {
        onDelete: "cascade",
      })
      .notNull(),
  },
  (table) => [
    index("courier_pincode_idx").on(table.courier, table.pincode),
    index("courier_pincode_zone_idx").on(table.courier, table.pincode, table.zone),
    index("courier_pincode_warehouse_idx").on(table.courier, table.pincode, table.warehouse),
    index("courier_pincode_zone_warehouse_idx").on(table.courier, table.pincode, table.zone, table.warehouse),
    uniqueIndex("pincode_courier_warehouse_unique").on(table.pincode, table.courier, table.warehouse),
  ]
);

export const zoneMappingsRelations = relations(zoneMappings, ({ one }) => ({
  warehouse: one(warehouses, {
    fields: [zoneMappings.warehouse],
    references: [warehouses.id],
  }),
  courier: one(couriers, {
    fields: [zoneMappings.courier],
    references: [couriers.id],
  }),
}));
