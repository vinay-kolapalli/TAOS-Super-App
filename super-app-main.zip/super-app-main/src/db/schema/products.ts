import { relations } from "drizzle-orm";
import { integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { users } from "./auth";
import { vendorInquiries, vendorProducts } from "./vendor";

export const products = pgTable("products", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  name: text("name").notNull(),
  image: text("image"),
  description: text("description").notNull(),
  sku: text("sku").notNull().unique(),
  createdBy: uuid("created_by")
    .references(() => users.id, {
      onDelete: "set null",
    })
    .notNull(),
  updatedBy: uuid("updated_by")
    .references(() => users.id, {
      onDelete: "set null",
    })
    .notNull(),
});

export const productsRelations = relations(products, ({ many, one }) => ({
  vendorProducts: many(vendorProducts),
  vendorInquiries: many(vendorInquiries),
  createdBy: one(users, {
    fields: [products.createdBy],
    references: [users.id],
  }),
  updatedBy: one(users, {
    fields: [products.updatedBy],
    references: [users.id],
  }),
}));
