import { relations } from "drizzle-orm";
import { index, integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { warehouses } from "./warehouse";

export const orderFlows = pgTable(
  "order_flows",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    orderNumber: integer("order_number").notNull().unique(),
    status: text("status").notNull(),
    plantsPickedAt: timestamp("plants_picked_at"),
    othersPickedAt: timestamp("others_picked_at"),
    reviewedAt: timestamp("reviewed_at"),
    packedAt: timestamp("packed_at"),
    courierCheckedAt: timestamp("courier_checked_at"),
    warehouse: integer("warehouse")
      .references(() => warehouses.id)
      .notNull(),
  },
  (table) => [index("order_flows_order_number_idx").on(table.orderNumber)]
);

export const orderFlowRelations = relations(orderFlows, ({ one }) => ({
  warehouse: one(warehouses, {
    fields: [orderFlows.warehouse],
    references: [warehouses.id],
  }),
}));
