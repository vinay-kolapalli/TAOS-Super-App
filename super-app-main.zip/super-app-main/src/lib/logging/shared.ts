import { Logger } from "@axiomhq/logging";

export interface LogFields {
  input?: any;
  parsedInput?: any;
  response?: any;
  parsedResponse?: any;
  error?: any;
  parsedError?: any;
  fetchError?: any;
  data?: any;
  session?: any;
  user?: any;
}

export class TypedLogger {
  private logger: Logger;

  constructor(logger: Logger) {
    this.logger = logger;
  }

  info(message: string, fields?: LogFields) {
    this.logger.info(message, fields);
  }

  error(message: string, fields?: LogFields) {
    this.logger.error(message, fields);
  }

  warn(message: string, fields?: LogFields) {
    this.logger.warn(message, fields);
  }

  debug(message: string, fields?: LogFields) {
    this.logger.debug(message, fields);
  }
}
