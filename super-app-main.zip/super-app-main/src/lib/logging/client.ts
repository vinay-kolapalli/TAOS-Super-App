"use client";
import { Logger, ProxyTransport } from "@axiomhq/logging";
import { createUseLogger, createWebVitalsComponent } from "@axiomhq/react";
import { TypedLogger } from "./shared";

export const baseLogger = new Logger({
  transports: [new ProxyTransport({ url: "/api/axiom", autoFlush: true })],
});

export const logger = new TypedLogger(baseLogger);

const useLogger = createUseLogger(baseLogger);
const WebVitals = createWebVitalsComponent(baseLogger);

export { useLogger, WebVitals };
