import axiomClient from "@/lib/logging/axiom";
import { AxiomJSTransport, Logger } from "@axiomhq/logging";
import { createAxiomRouteHandler, nextJsFormatters } from "@axiomhq/nextjs";
import { TypedLogger } from "./shared";

export const baseLogger = new Logger({
  transports: [new AxiomJSTransport({ axiom: axiomClient, dataset: process.env.AXIOM_DATASET })],
  formatters: nextJsFormatters,
});

export const logger = new TypedLogger(baseLogger);

export const withAxiom = createAxiomRouteHandler(baseLogger);
