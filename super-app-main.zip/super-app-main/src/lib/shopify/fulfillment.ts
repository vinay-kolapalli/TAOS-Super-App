import { convertShopifyIdToGid, createShopifyClient } from "@/lib/shopify";
import { graphql } from "gql.tada";

export async function getOrderFulfillmentDetails(orderId: string) {
  const shopify = createShopifyClient();
  const response = await shopify.query(
    graphql(`
      query getOrderFulfillmentDetails($orderId: ID!) {
        order(id: $orderId) {
          fulfillments(first: 1) {
            id
          }
          fulfillmentOrders(first: 5) {
            edges {
              node {
                id
                status
              }
            }
          }
          tags
        }
      }
    `),
    { orderId }
  );

  if (response.error || !response.data?.order)
    throw new Error(response.error?.message ?? "Order fulfillment details not found");

  return response.data.order;
}

interface CreateFulfillmentInput {
  fulfillmentOrderId: string;
  fulfillmentOrderLineItems: { id: string; quantity: number }[];
  notifyCustomer: boolean;
  trackingInfo: {
    company: string;
    number: string;
    url: string;
  };
}

export async function createFulfillment(input: CreateFulfillmentInput) {
  const shopify = createShopifyClient();
  const response = await shopify.mutation(
    graphql(`
      mutation CreateFulfillment($fulfillment: FulfillmentInput!) {
        fulfillmentCreate(fulfillment: $fulfillment) {
          fulfillment {
            id
          }
          userErrors {
            message
          }
        }
      }
    `),
    {
      fulfillment: {
        lineItemsByFulfillmentOrder: [
          { fulfillmentOrderId: input.fulfillmentOrderId, fulfillmentOrderLineItems: input.fulfillmentOrderLineItems },
        ],
        notifyCustomer: input.notifyCustomer,
        trackingInfo: {
          company: input.trackingInfo.company,
          number: input.trackingInfo.number,
          url: input.trackingInfo.url,
        },
      },
    }
  );

  if (
    response.error ||
    !response.data?.fulfillmentCreate?.fulfillment ||
    response.data.fulfillmentCreate.userErrors.length > 0
  )
    throw new Error(response.error?.message ?? "Unable to create fulfillment");
  return response.data.fulfillmentCreate.fulfillment;
}

export async function cancelFulfillment(fulfillmentId: string) {
  const shopify = createShopifyClient();
  const response = await shopify.mutation(
    graphql(`
      mutation fulfillmentCancel($id: ID!) {
        fulfillmentCancel(id: $id) {
          fulfillment {
            id
            status
          }
          userErrors {
            message
          }
        }
      }
    `),
    {
      id: fulfillmentId,
    }
  );
  if (
    response.error ||
    !response.data?.fulfillmentCancel?.fulfillment ||
    response.data.fulfillmentCancel.userErrors.length > 0
  )
    throw new Error(response.error?.message ?? "Unable to cancel fulfillment");
  return response.data.fulfillmentCancel.fulfillment;
}

export async function moveFulfillmentOrder(orderId: string, newLocationId: number) {
  const shopify = createShopifyClient();

  // First, fetch the fulfillment orders for this order
  const orderResponse = await shopify.query(
    graphql(`
      query GetOrderFulfillmentOrders($id: ID!) {
        order(id: $id) {
          fulfillmentOrders(first: 10) {
            nodes {
              id
              assignedLocation {
                location {
                  id
                }
              }
            }
          }
        }
      }
    `),
    {
      id: orderId,
    }
  );

  if (orderResponse.error || !orderResponse.data?.order?.fulfillmentOrders?.nodes) {
    throw new Error(orderResponse.error?.message ?? "Fulfillment orders not found");
  }

  const fulfillmentOrders = orderResponse.data.order.fulfillmentOrders.nodes;

  // Move each fulfillment order
  for (const fulfillmentOrder of fulfillmentOrders) {
    if (fulfillmentOrder.assignedLocation?.location?.id === convertShopifyIdToGid(newLocationId, "Location")) {
      continue;
    }

    const moveResponse = await shopify.mutation(
      graphql(`
        mutation fulfillmentOrderMove($id: ID!, $newLocationId: ID!) {
          fulfillmentOrderMove(id: $id, newLocationId: $newLocationId) {
            movedFulfillmentOrder {
              id
              status
            }
            userErrors {
              field
              message
            }
          }
        }
      `),
      {
        id: fulfillmentOrder.id,
        newLocationId: convertShopifyIdToGid(newLocationId, "Location"),
      }
    );

    if (
      moveResponse.error ||
      !moveResponse.data?.fulfillmentOrderMove?.movedFulfillmentOrder ||
      moveResponse.data.fulfillmentOrderMove.userErrors.length > 0
    ) {
      throw new Error(moveResponse.error?.message ?? "Unable to move fulfillment order");
    }
  }

  return { success: true };
}
