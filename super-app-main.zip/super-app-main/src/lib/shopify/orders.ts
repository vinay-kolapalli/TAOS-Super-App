import { convertShopifyIdToNumber, createShopifyClient } from "@/lib/shopify";
import {
  GetOrdersInputSchema,
  GetOrdersOutputSchema,
  GetShippingOrdersInputSchema,
  GetShippingOrdersOutputSchema,
} from "@/router/store/orders/schema";
import { OrderStatus } from "@/types/order";
import { graphql } from "gql.tada";

export const SORT_KEYS = [
  "PROCESSED_AT",
  "CREATED_AT",
  "FULFILLMENT_STATUS",
  "UPDATED_AT",
  "TOTAL_PRICE",
  "ORDER_NUMBER",
] as const;

export async function getShopifyOrders(options: GetOrdersInputSchema): Promise<GetOrdersOutputSchema["data"]> {
  const shopify = createShopifyClient();
  let queries = [];

  // Search
  options.search && queries.push(options.search);

  // Status
  options.status &&
    options.status !== "cancelled" &&
    options.status !== "refunded" &&
    queries.push(`tag:'status:${options.status}'`);
  options.status === "cancelled" && queries.push(`status:cancelled`);
  options.status === "refunded" && queries.push(`financial_status:refunded OR financial_status:partially_refunded`);

  // Include
  options.include && options.include.length > 0 && queries.push(`${options.include.join(" OR ")}`);

  // Warehouses
  options.warehouses &&
    options.warehouses.length > 0 &&
    queries.push(options.warehouses.map((warehouse) => `tag:'warehouse:${warehouse}'`).join(" OR "));

  const query = queries.join(" ");

  const sortOption = options.sortBy as (typeof SORT_KEYS)[number];
  const sortKey = SORT_KEYS.includes(sortOption) ? sortOption : null;

  const { data, error } = await shopify.query(
    graphql(`
      query GetOrders(
        $first: Int
        $last: Int
        $after: String
        $before: String
        $query: String
        $sortKey: OrderSortKeys
        $reverse: Boolean
      ) {
        orders(
          first: $first
          last: $last
          after: $after
          before: $before
          query: $query
          sortKey: $sortKey
          reverse: $reverse
        ) {
          nodes {
            id
            name
            createdAt
            updatedAt
            fullyPaid
            displayFinancialStatus
            note
            email
            tags
            billingAddress {
              firstName
              lastName
              company
              address1
              address2
              city
              province
              provinceCode
              zip
              country
              phone
            }
            shippingAddress {
              firstName
              lastName
              company
              address1
              address2
              city
              province
              provinceCode
              zip
              country
              phone
            }
            metafields(first: 25) {
              nodes {
                key
                value
              }
            }
            transactions {
              gateway
              formattedGateway
              paymentId
              amountSet {
                shopMoney {
                  amount
                  currencyCode
                }
              }
            }
            discountCodes
            currentSubtotalPriceSet {
              shopMoney {
                amount
              }
            }
            currentTotalTaxSet {
              shopMoney {
                amount
              }
            }
            currentTotalDiscountsSet {
              shopMoney {
                amount
              }
            }
            currentShippingPriceSet {
              shopMoney {
                amount
              }
            }
            currentTotalPriceSet {
              shopMoney {
                amount
              }
            }
            shippingLine {
              title
            }
            lineItems(first: 100) {
              nodes {
                id
                name
                quantity
                sku
                originalUnitPriceSet {
                  shopMoney {
                    amount
                  }
                }
                product {
                  id
                  onlineStorePreviewUrl
                  tags
                }
                variant {
                  id
                }
                image {
                  url
                }
                taxLines {
                  priceSet {
                    shopMoney {
                      amount
                    }
                  }
                }
                originalUnitPriceSet {
                  shopMoney {
                    amount
                  }
                }
              }
            }
            fulfillments(first: 1) {
              trackingInfo(first: 1) {
                company
                number
                url
              }
            }
          }
          pageInfo {
            startCursor
            endCursor
            hasNextPage
            hasPreviousPage
          }
        }
      }
    `),
    {
      sortKey,
      reverse: options.sort === "desc",
      query,
      first: options.before ? undefined : (options.perPage ?? 25),
      after: options.after ? options.after : undefined,
      before: options.before ? options.before : undefined,
      last: options.before && !options.after ? (options.perPage ?? 25) : undefined,
    }
  );

  if (error) {
    throw new Error(`Failed to fetch orders: ${error.message}`);
  }

  const orders = data?.orders.nodes.map((order) => {
    const statusTags = order.tags.filter((tag) => tag.startsWith("status:"));
    const tagStatus = statusTags.length > 0 ? (statusTags[0].split(":")[1] as OrderStatus) : "pending";
    const status = (options.status ?? tagStatus) as OrderStatus;

    const warehouseTags = order.tags.filter((tag) => tag.startsWith("warehouse:"));
    let warehouse = warehouseTags.length > 0 ? Number(warehouseTags[0].split(":")[1]) : null;

    const metafields = order.metafields.nodes.reduce(
      (acc, metafield) => {
        acc[metafield.key] = metafield.value;
        return acc;
      },
      {} as Record<string, string>
    );

    return {
      id: convertShopifyIdToNumber(order.id),
      number: Number(order.name),
      createdAt: new Date(order.createdAt as string).toISOString(),
      modifiedAt: new Date(order.updatedAt as string).toISOString(),
      status,
      warehouse,
      tags: order.tags,
      isPaid: order.fullyPaid
        ? order.fullyPaid
        : Number(order.transactions[0]?.amountSet.shopMoney.amount ?? 0) > 0 ||
          order.displayFinancialStatus === "PARTIALLY_REFUNDED",
      billing: {
        firstName: order.billingAddress?.firstName ?? "",
        lastName: order.billingAddress?.lastName ?? "",
        company: order.billingAddress?.company ?? "",
        address1: order.billingAddress?.address1 ?? "",
        address2: order.billingAddress?.address2 ?? "",
        city: order.billingAddress?.city ?? "",
        state: order.billingAddress?.province ?? "",
        stateCode: order.billingAddress?.provinceCode ?? "",
        country: order.billingAddress?.country ?? "",
        postcode: Number(order.billingAddress?.zip),
        phone: Number((order.billingAddress?.phone ?? "").slice(-10)),
        email: order.email ?? "",
      },
      shipping: {
        firstName: order.shippingAddress?.firstName ?? "",
        lastName: order.shippingAddress?.lastName ?? "",
        company: order.shippingAddress?.company ?? "",
        address1: order.shippingAddress?.address1 ?? "",
        address2: order.shippingAddress?.address2 ?? "",
        city: order.shippingAddress?.city ?? "",
        state: order.shippingAddress?.province ?? "",
        stateCode: order.shippingAddress?.provinceCode ?? "",
        postcode: Number(order.shippingAddress?.zip),
        country: order.shippingAddress?.country ?? "",
        phone: Number((order.shippingAddress?.phone ?? order.billingAddress?.phone ?? "").slice(-10)),
        email: order.email ?? "",
      },
      payment: order.transactions[0]
        ? {
            amount: Number(order.transactions[0].amountSet.shopMoney.amount),
            currency: order.transactions[0].amountSet.shopMoney.currencyCode ?? "",
            method: order.transactions[0].formattedGateway ?? "",
            methodTitle: order.transactions[0].gateway ?? "",
            transactionId: order.transactions[0].paymentId ?? "",
          }
        : null,
      lineItems: order.lineItems.nodes.map((item) => ({
        id: convertShopifyIdToNumber(item.id),
        productId: convertShopifyIdToNumber(item.product?.id ?? ""),
        variantId: convertShopifyIdToNumber(item.variant?.id ?? ""),
        name: item.name,
        quantity: item.quantity,
        tags: item.product?.tags ?? [],
        price: Number(item.originalUnitPriceSet.shopMoney.amount),
        sku: item.sku ?? "",
        url: (item.product?.onlineStorePreviewUrl ?? "") as string,
        image: (item.image?.url ?? "") as string,
        tax: Number(
          item.taxLines.reduce((total, taxLine) => total + Number(taxLine.priceSet.shopMoney.amount), 0).toFixed(2)
        ),
        total: Number(item.originalUnitPriceSet.shopMoney.amount) * item.quantity,
      })),
      tracking: order.fulfillments?.[0]?.trackingInfo?.[0]?.number
        ? {
            trackingNumber: order.fulfillments?.[0]?.trackingInfo?.[0]?.number ?? "",
            courierName: order.fulfillments?.[0]?.trackingInfo?.[0]?.company ?? "",
            courierId: metafields.taos_courier_id ?? "",
            shippedAt: metafields.taos_shipped_at ?? "",
            box: metafields.taos_box_type ?? "",
            weight: Number(metafields.taos_weight ?? 0),
            packedBy: metafields.taos_packed_by ?? "",
            scannedBy: metafields.taos_scanned_by ?? "",
          }
        : null,
      calculations: {
        discount: Number(order.currentTotalDiscountsSet.shopMoney.amount),
        shipping: Number(order.currentShippingPriceSet.shopMoney.amount),
        tax: Number(order.currentTotalTaxSet.shopMoney.amount),
        total: Number(order.currentTotalPriceSet.shopMoney.amount),
        subtotal: Number(order.currentSubtotalPriceSet.shopMoney.amount),
      },
      coupons: order.discountCodes,
      metadata: {
        rewardPointsGranted: 0,
        rewardPointsRedeemed: 0,
        note: order.note ?? "",
      },
      shippingMethod: order.shippingLine?.title ?? "Unknown",
    };
  });

  return {
    orders: orders ?? [],
    hasNextPage: data?.orders.pageInfo.hasNextPage ?? false,
    hasPreviousPage: data?.orders.pageInfo.hasPreviousPage ?? false,
    endCursor: data?.orders.pageInfo.endCursor,
    startCursor: data?.orders.pageInfo.startCursor,
  };
}

interface WarehouseReport {
  lineItems: {
    name: string;
    quantity: number;
    sku: string | null;
  }[];
}

export async function getShopifyOrdersForWarehouseReport(options: {
  warehouses: number[];
  from: string;
  to: string;
}): Promise<WarehouseReport[]> {
  const shopify = createShopifyClient();
  const queries = [];
  queries.push(options.warehouses.map((warehouse) => `tag:'warehouse:${warehouse}'`).join(" OR "));
  queries.push(`created_at:>=${options.from} AND created_at:<=${options.to}`);

  const query = queries.join(" AND ");

  async function fetchOrdersRecursively(cursor?: string): Promise<WarehouseReport[]> {
    const { data, error } = await shopify.query(
      graphql(`
        query GetOrdersForWarehouseReport($first: Int, $query: String, $after: String) {
          orders(first: $first, query: $query, after: $after) {
            nodes {
              lineItems(first: 100) {
                nodes {
                  name
                  quantity
                  sku
                }
              }
            }
            pageInfo {
              endCursor
              hasNextPage
            }
          }
        }
      `),
      {
        query: query,
        first: 250,
        after: cursor,
      }
    );

    if (error) {
      throw new Error(`Failed to fetch warehouse report orders: ${error.message}`);
    }

    const ordersData = data?.orders?.nodes
      ? data.orders.nodes.map((order) => ({
          lineItems: order.lineItems.nodes,
        }))
      : [];

    if (data?.orders.pageInfo.hasNextPage && data.orders.pageInfo.endCursor) {
      const nextPageOrders = await fetchOrdersRecursively(data.orders.pageInfo.endCursor);
      return [...ordersData, ...nextPageOrders];
    }

    return ordersData;
  }

  return await fetchOrdersRecursively();
}

export async function getShopifyOrdersForShipping(
  options: GetShippingOrdersInputSchema
): Promise<GetShippingOrdersOutputSchema["data"]> {
  const shopify = createShopifyClient();
  let queries = [];

  // Status
  options.status &&
    options.status !== "cancelled" &&
    options.status !== "refunded" &&
    queries.push(`tag:'status:${options.status}'`);
  options.status === "cancelled" && queries.push(`status:cancelled`);
  options.status === "refunded" && queries.push(`financial_status:refunded OR financial_status:partially_refunded`);

  // Warehouses
  options.warehouses &&
    options.warehouses.length > 0 &&
    queries.push(options.warehouses.map((warehouse) => `tag:'warehouse:${warehouse}'`).join(" OR "));

  const query = queries.join(" ");

  const { data, error } = await shopify.query(
    graphql(`
      query GetOrders(
        $first: Int
        $last: Int
        $after: String
        $before: String
        $query: String
        $sortKey: OrderSortKeys
        $reverse: Boolean
      ) {
        orders(
          first: $first
          last: $last
          after: $after
          before: $before
          query: $query
          sortKey: $sortKey
          reverse: $reverse
        ) {
          nodes {
            id
            name
            createdAt
            updatedAt
            fullyPaid
            displayFinancialStatus
            tags
            email
            billingAddress {
              phone
            }
            shippingAddress {
              firstName
              lastName
              company
              address1
              address2
              city
              province
              provinceCode
              zip
              country
              phone
            }
            shippingLine {
              title
            }
            transactions {
              gateway
              formattedGateway
              paymentId
              amountSet {
                shopMoney {
                  amount
                  currencyCode
                }
              }
            }
            lineItems(first: 100) {
              nodes {
                id
                name
                quantity
                sku
                product {
                  id
                }
                originalUnitPriceSet {
                  shopMoney {
                    amount
                  }
                }
              }
            }
            currentSubtotalPriceSet {
              shopMoney {
                amount
              }
            }
            currentTotalTaxSet {
              shopMoney {
                amount
              }
            }
            currentTotalDiscountsSet {
              shopMoney {
                amount
              }
            }
            currentShippingPriceSet {
              shopMoney {
                amount
              }
            }
            currentTotalPriceSet {
              shopMoney {
                amount
              }
            }
          }
          pageInfo {
            startCursor
            endCursor
            hasNextPage
            hasPreviousPage
          }
        }
      }
    `),
    {
      query,
      first: options.before ? undefined : (options.perPage ?? 25),
      after: options.after ? options.after : undefined,
      before: options.before ? options.before : undefined,
      last: options.before && !options.after ? (options.perPage ?? 25) : undefined,
    }
  );

  if (error) {
    throw new Error(`Failed to fetch shipping orders: ${error.message}`);
  }

  const orders = data?.orders.nodes.map((order) => {
    const statusTags = order.tags.filter((tag) => tag.startsWith("status:"));
    const tagStatus = statusTags.length > 0 ? (statusTags[0].split(":")[1] as OrderStatus) : "pending";
    const status = (options.status ?? tagStatus) as OrderStatus;

    return {
      id: convertShopifyIdToNumber(order.id),
      number: Number(order.name),
      createdAt: new Date(order.createdAt as string).toISOString(),
      modifiedAt: new Date(order.updatedAt as string).toISOString(),
      status,
      isPaid: order.fullyPaid
        ? order.fullyPaid
        : Number(order.transactions[0]?.amountSet.shopMoney.amount ?? 0) > 0 ||
          order.displayFinancialStatus === "PARTIALLY_REFUNDED",
      shipping: {
        firstName: order.shippingAddress?.firstName ?? "",
        lastName: order.shippingAddress?.lastName ?? "",
        company: order.shippingAddress?.company ?? "",
        address1: order.shippingAddress?.address1 ?? "",
        address2: order.shippingAddress?.address2 ?? "",
        city: order.shippingAddress?.city ?? "",
        state: order.shippingAddress?.province ?? "",
        stateCode: order.shippingAddress?.provinceCode ?? "",
        postcode: Number(order.shippingAddress?.zip),
        country: order.shippingAddress?.country ?? "",
        phone: Number((order.shippingAddress?.phone ?? order.billingAddress?.phone ?? "").slice(-10)),
        email: order.email ?? "",
      },
      lineItems: order.lineItems.nodes.map((item) => ({
        id: convertShopifyIdToNumber(item.id),
        productId: convertShopifyIdToNumber(item.product?.id ?? ""),
        name: item.name,
        quantity: item.quantity,
        sku: item.sku ?? "",
        price: Number(item.originalUnitPriceSet.shopMoney.amount),
      })),
      shippingMethod: order.shippingLine?.title ?? "Unknown",
      calculations: {
        discount: Number(order.currentTotalDiscountsSet.shopMoney.amount),
        shipping: Number(order.currentShippingPriceSet.shopMoney.amount),
        tax: Number(order.currentTotalTaxSet.shopMoney.amount),
        total: Number(order.currentTotalPriceSet.shopMoney.amount),
        subtotal: Number(order.currentSubtotalPriceSet.shopMoney.amount),
      },
    };
  });

  return {
    orders: orders ?? [],
    hasNextPage: data?.orders.pageInfo.hasNextPage ?? false,
    hasPreviousPage: data?.orders.pageInfo.hasPreviousPage ?? false,
    endCursor: data?.orders.pageInfo.endCursor,
    startCursor: data?.orders.pageInfo.startCursor,
  };
}

export async function getOrderCount(query?: string) {
  const shopify = createShopifyClient();

  const orderCount = await shopify.query(
    graphql(`
      query OrdersCount($query: String) {
        ordersCount(limit: 10000, query: $query) {
          count
        }
      }
    `),
    {
      query,
    }
  );

  if (orderCount.error) {
    throw new Error(`Failed to get order count: ${orderCount.error.message}`);
  }

  return orderCount.data?.ordersCount?.count ?? 0;
}

interface UpdateOrderInput {
  id: string;
  tags?: string[];
  shippingAddress?: {
    firstName?: string;
    lastName?: string;
    company?: string;
    address1?: string;
    address2?: string;
    city?: string;
    province?: string;
    provinceCode?: string;
    zip?: string;
    phone?: string;
  };
  metafields?: {
    key: string;
    value: string;
    namespace?: string;
    type: string;
  }[];
}

export async function updateOrder(input: UpdateOrderInput) {
  const shopify = createShopifyClient();
  const response = await shopify.mutation(
    graphql(`
      mutation UpdateOrder($input: OrderInput!) {
        orderUpdate(input: $input) {
          order {
            id
          }
          userErrors {
            message
          }
        }
      }
    `),
    {
      input,
    }
  );

  if (response.error) {
    throw new Error(`Failed to update order: ${response.error.message}`);
  }

  if (!response.data?.orderUpdate?.order) {
    throw new Error("Order update failed - no order returned");
  }

  if (response.data.orderUpdate.userErrors.length > 0) {
    const errorMessages = response.data.orderUpdate.userErrors.map((error) => error.message).join(", ");
    throw new Error(`Order update failed: ${errorMessages}`);
  }

  return response.data.orderUpdate.order;
}
