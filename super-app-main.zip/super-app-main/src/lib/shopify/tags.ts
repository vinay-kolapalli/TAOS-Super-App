import { createShopifyClient } from "@/lib/shopify";
import { graphql } from "gql.tada";

export async function addTagsToOrder(id: string, tags: string[]) {
  const shopify = createShopifyClient();
  const response = await shopify.mutation(
    graphql(`
      mutation addTags($id: ID!, $tags: [String!]!) {
        tagsAdd(id: $id, tags: $tags) {
          node {
            id
          }
          userErrors {
            message
          }
        }
      }
    `),
    {
      id,
      tags,
    }
  );

  if (response.error) {
    throw new Error(`Unable to add tags to order: ${response.error.message}`);
  }

  if (!response.data?.tagsAdd?.node) {
    throw new Error("Unable to add tags to order");
  }

  if (response.data.tagsAdd.userErrors.length > 0) {
    const errorMessages = response.data.tagsAdd.userErrors.map((error) => error.message).join(", ");
    throw new Error(`Unable to add tags to order: ${errorMessages}`);
  }

  return response.data.tagsAdd.node;
}
