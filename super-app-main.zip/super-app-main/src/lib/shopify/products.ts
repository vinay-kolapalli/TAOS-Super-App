import { convertShopifyIdToNumber, createShopifyClient } from "@/lib/shopify";
import { graphql } from "gql.tada";

interface GetProductsProps {
  limit: number;
  after?: string | null;
}

export async function getProducts({ limit, after }: GetProductsProps) {
  const shopify = createShopifyClient();

  const { data, error } = await shopify.query(
    graphql(`
      query getProducts($first: Int!, $cursor: String) {
        products(first: $first, after: $cursor) {
          nodes {
            id
            title
            media(first: 1) {
              nodes {
                preview {
                  image {
                    url
                  }
                }
              }
            }
            onlineStoreUrl
          }
          pageInfo {
            hasNextPage
            endCursor
          }
        }
      }
    `),
    {
      first: limit,
      cursor: after,
    }
  );

  if (error) {
    throw new Error("Unable to fetch products from store");
  }

  const products =
    data?.products?.nodes?.map((product) => ({
      id: convertShopifyIdToNumber(product.id),
      name: product.title,
      url: (product.onlineStoreUrl as string) ?? "",
      image: product.media?.nodes?.[0]?.preview?.image?.url
        ? String(product.media?.nodes?.[0]?.preview?.image?.url)
        : "/images/placeholder.png",
    })) ?? [];

  return {
    products,
    hasNextPage: data?.products?.pageInfo?.hasNextPage ?? false,
    endCursor: data?.products?.pageInfo?.endCursor,
  };
}
