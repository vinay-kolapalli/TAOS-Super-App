import { Client, cacheExchange, fetchExchange } from "@urql/core";

export function createShopifyClient() {
  const requestUrl = new URL(process.env.NEXT_PUBLIC_STORE_URL);
  requestUrl.pathname = "/admin/api/2025-07/graphql.json";

  return new Client({
    url: String(requestUrl),
    exchanges: [cacheExchange, fetchExchange],
    preferGetMethod: false,
    fetchOptions: () => {
      return {
        headers: {
          "X-Shopify-Access-Token": process.env.SHOPIFY_ACCESS_TOKEN,
        },
      };
    },
  });
}

export function convertShopifyIdToNumber(id: string) {
  return Number(id.split("/").pop());
}

export function convertShopifyIdToGid(id: number, type: "Order" | "FulfillmentOrder" | "Product" | "Location") {
  return `gid://shopify/${type}/${id}`;
}
