import { Zones } from "@/data/shipping";
import {
  CalculateShipwayRatePayload,
  calculateShipwayRatePayloadSchema,
  calculateShipwayRateResponseSchema,
  checkPincodeServiceabilityResponseSchema,
  CreateShipwayOrderPayload,
  createShipwayOrderPayloadSchema,
  createShipwayOrderResponseSchema,
} from "@/schema/shipping/shipway";
import axios, { AxiosError } from "axios";
import { logger } from "../logging/server";
import { tryCatch } from "../try-catch";

function getShipwayToken() {
  return btoa(`${process.env.SHIPWAY_USERNAME}:${process.env.SHIPWAY_PASSWORD}`);
}

export async function checkShipwayPincodeServiceability(pincode: number) {
  const token = getShipwayToken();
  logger.info("[checkShipwayPincodeServiceability] payload", { input: pincode });

  const response = await tryCatch(
    axios.get("https://app.shipway.com/api/pincodeserviceable", {
      params: {
        pincode,
      },
      headers: {
        Authorization: `Basic ${token}`,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[checkShipwayPincodeServiceability] axiosError", { fetchError: axiosError });
    logger.error("[checkShipwayPincodeServiceability] axiosError.response?.data", {
      response: axiosError.response?.data,
    });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = checkPincodeServiceabilityResponseSchema.safeParse(response.data.data);
  logger.info("[checkShipwayPincodeServiceability] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  if (!parsedResponse.data.success) {
    throw new Error(parsedResponse.data.error || "Unknown error");
  }

  return parsedResponse.data;
}

export async function calculateShipwayRate(payload: CalculateShipwayRatePayload) {
  const parsedPayload = calculateShipwayRatePayloadSchema.parse(payload);
  const token = getShipwayToken();

  logger.info("[calculateShipwayRate] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.get("https://app.shipway.com/api/getshipwaycarrierrates", {
      params: parsedPayload,
      headers: {
        Authorization: `Basic ${token}`,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[calculateShipwayRate] axiosError", { fetchError: axiosError });
    logger.error("[calculateShipwayRate] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = calculateShipwayRateResponseSchema.safeParse(response.data.data);
  logger.info("[calculateShipwayRate] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  if (!parsedResponse.data.success) {
    throw new Error("Failed to calculate rate");
  }

  return parsedResponse.data;
}

export async function createShipwayOrder(payload: CreateShipwayOrderPayload) {
  const parsedPayload = createShipwayOrderPayloadSchema.parse(payload);
  const token = getShipwayToken();

  logger.info("[createShipwayOrder] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.post("https://app.shipway.com/api/v2orders", parsedPayload, {
      headers: {
        Authorization: `Basic ${token}`,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[createShipwayOrder] axiosError", { fetchError: axiosError });
    logger.error("[createShipwayOrder] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = createShipwayOrderResponseSchema.safeParse(response.data.data);
  logger.info("[createShipwayOrder] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  if (!parsedResponse.data.success) {
    throw new Error(parsedResponse.data.message || "Unknown error");
  }

  if (parsedResponse.data.awb_response.error?.[0]) {
    throw new Error(parsedResponse.data.awb_response.error?.[0]);
  }

  return parsedResponse.data;
}

export function getShipwayZoneName(zone: number): Zones {
  switch (zone) {
    case 1:
      return "local";
    case 2:
      return "regional";
    case 3:
      return "metro";
    case 4:
      return "north-east";
    case 5:
      return "rest-of-india";
    default:
      return "rest-of-india";
  }
}

export const shipwayCourierIds = {
  amazon_shipping_surface_500gm: 19339,
  amazon_shipping_surface_1kg: 9157,
  amazon_shipping_surface_2kg: 9158,
  amazon_shipping_surface_10kg: 79781,
  amazon_shipping_surface_5kg: 9159,
  delhivery_surface_500gm: 80165,
  delhivery_surface_10kg: 7666,
  delhivery_surface_1kg: 10065,
  delhivery_surface_2kg: 80977,
  delhivery_surface_5kg: 7613,
  dtdc_500gm: 79221,
  ekart_500gm: 71468,
  ekart_1kg: 80275,
  bluedart_surface_500gm: 81769,
} as const;
