import { Zones } from "@/data/shipping";
import {
  CalculateIThinkLogisticsRatePayload,
  calculateIThinkLogisticsRatePayloadSchema,
  calculateIThinkLogisticsRateResponseSchema,
  CreateIThinkLogisticsOrderPayload,
  createIThinkLogisticsOrderPayloadSchema,
  createIThinkLogisticsOrderResponseSchema,
  printIThinkLogisticsShippingLabelResponseSchema,
} from "@/schema/shipping/ithink-logistics";
import axios, { AxiosError } from "axios";
import { logger } from "../logging/server";
import { tryCatch } from "../try-catch";

export async function checkIThinkLogisticsPincodeServiceability(pincode: number) {
  logger.info("[checkIThinkLogisticsPincodeServiceability] payload", { input: pincode });

  const response = await tryCatch(
    axios.post("https://my.ithinklogistics.com/api_v3/pincode/check.json", {
      data: {
        pincode,
        access_token: process.env.ITHINK_LOGISTICS_ACCESS_TOKEN,
        secret_key: process.env.ITHINK_LOGISTICS_SECRET_TOKEN,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[checkIThinkLogisticsPincodeServiceability] axiosError", { fetchError: axiosError });
    logger.error("[checkIThinkLogisticsPincodeServiceability] axiosError.response?.data", {
      response: axiosError.response?.data,
    });
    throw new Error(axiosError.message || "Unknown error");
  }

  // Unable to parse the response because of the nested structure
  // const parsedResponse = checkIThinkLogisticsPincodeServiceabilityResponseSchema.safeParse(response.data.data);
  logger.info("[checkIThinkLogisticsPincodeServiceability] response", { response: response.data.data });

  // if (!parsedResponse.success) {
  //   throw new Error("Invalid response");
  // }

  if (response.data.data.status !== "success") {
    throw new Error("Failed to check pincode serviceability");
  }

  return response.data.data;
}

export async function calculateIThinkLogisticsRate(payload: CalculateIThinkLogisticsRatePayload) {
  const parsedPayload = calculateIThinkLogisticsRatePayloadSchema.parse(payload);
  logger.info("[calculateIThinkLogisticsRate] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.post("https://my.ithinklogistics.com/api_v3/rate/check.json", {
      data: {
        ...parsedPayload,
        access_token: process.env.ITHINK_LOGISTICS_ACCESS_TOKEN,
        secret_key: process.env.ITHINK_LOGISTICS_SECRET_TOKEN,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[calculateIThinkLogisticsRate] axiosError", { fetchError: axiosError });
    logger.error("[calculateIThinkLogisticsRate] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = calculateIThinkLogisticsRateResponseSchema.safeParse(response.data.data);
  logger.info("[calculateIThinkLogisticsRate] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  if (parsedResponse.data.status !== "success") {
    throw new Error("Failed to calculate rate");
  }

  return parsedResponse.data;
}

export async function createIThinkLogisticsOrder(payload: CreateIThinkLogisticsOrderPayload) {
  const parsedPayload = createIThinkLogisticsOrderPayloadSchema.parse(payload);
  logger.info("[createIThinkLogisticsOrder] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.post("https://my.ithinklogistics.com/api_v3/order/add.json", {
      data: {
        ...parsedPayload,
        access_token: process.env.ITHINK_LOGISTICS_ACCESS_TOKEN,
        secret_key: process.env.ITHINK_LOGISTICS_SECRET_TOKEN,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[createIThinkLogisticsOrder] axiosError", { fetchError: axiosError });
    logger.error("[createIThinkLogisticsOrder] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = createIThinkLogisticsOrderResponseSchema.safeParse(response.data.data);
  logger.info("[createIThinkLogisticsOrder] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  const courierData = parsedResponse.data.data?.["1"];

  if (parsedResponse.data.status !== "success") {
    throw new Error(parsedResponse.data.html_message || courierData?.remark || "Unknown error");
  }

  if (!courierData?.waybill) {
    throw new Error(parsedResponse.data?.html_message || courierData?.remark || "Tracking number not found");
  }

  return {
    ...parsedResponse.data,
    data: courierData,
  };
}

export async function printIThinkLogisticsShippingLabel(trackingNumber: string) {
  logger.info("[printIThinkLogisticsShippingLabel] payload", { input: trackingNumber });

  const response = await tryCatch(
    axios.post("https://my.ithinklogistics.com/api_v3/shipping/label.json", {
      data: {
        awb_numbers: trackingNumber,
        page_size: "A6",
        access_token: process.env.ITHINK_LOGISTICS_ACCESS_TOKEN,
        secret_key: process.env.ITHINK_LOGISTICS_SECRET_TOKEN,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[printIThinkLogisticsShippingLabel] axiosError", { fetchError: axiosError });
    logger.error("[printIThinkLogisticsShippingLabel] axiosError.response?.data", {
      response: axiosError.response?.data,
    });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = printIThinkLogisticsShippingLabelResponseSchema.safeParse(response.data.data);
  logger.info("[printIThinkLogisticsShippingLabel] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}

export function getIThinkLogisticsZoneName(zone: string): Zones {
  switch (zone) {
    case "A":
      return "local";
    case "B":
      return "regional";
    case "C":
      return "metro";
    case "D":
      return "rest-of-india";
    case "E":
      return "north-east";
    default:
      return "rest-of-india";
  }
}
