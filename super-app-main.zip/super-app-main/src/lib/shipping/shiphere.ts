import {
  CreateShiphereOrderPayload,
  createShiphereOrderPayloadSchema,
  createShiphereOrderResponseSchema,
  shiphereErrorSchema,
} from "@/schema/shipping/shiphere";
import axios, { AxiosError } from "axios";
import { logger } from "../logging/server";
import { tryCatch } from "../try-catch";

export async function createShiphereOrder(payload: CreateShiphereOrderPayload) {
  const parsedPayload = createShiphereOrderPayloadSchema.parse(payload);
  logger.info("[createShiphereOrder] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.post("https://api.shiphere.in/create/shipment", parsedPayload, {
      headers: {
        "x-shiphere-token": process.env.SHIPHERE_API_KEY,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    const parsedError = shiphereErrorSchema.safeParse(axiosError.response?.data);
    logger.error("[createShiphereOrder] axiosError", { fetchError: axiosError });
    logger.error("[createShiphereOrder] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(parsedError.data?.error || parsedError.data?.message || axiosError.message || "Unknown error");
  }

  const parsedResponse = createShiphereOrderResponseSchema.safeParse(response.data.data);
  logger.info("[createShiphereOrder] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}

export const shiphereCourierIds = {
  delhivery_one_500g: 1020,
  delhivery_one_1kg: 1025,
  delhivery_one_2kg: 1030,
  delhivery_one_3kg: 1035,
  delhivery_one_4kg: 1040,
  delhivery_one_5kg: 1045,
  amazon_shipping_surface_500gm: 2010,
  amazon_shipping_surface_1kg: 2015,
  amazon_shipping_surface_2kg: 2020,
  amazon_shipping_surface_3kg: 2025,
  amazon_shipping_surface_4kg: 2030,
  amazon_shipping_surface_5kg: 2035,
  ekart_500g: 4010,
  ekart_1kg: 4015,
  ekart_2kg: 4020,
  ekart_3kg: 4025,
  ekart_4kg: 4030,
  ekart_5kg: 4035,
} as const;
