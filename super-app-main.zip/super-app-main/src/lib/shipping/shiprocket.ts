import { Zones } from "@/data/shipping";
import {
  assignAWBToOrderPayloadSchema,
  assignAWBToOrderResponseSchema,
  CheckShiprocketPincodeServiceabilityPayload,
  checkShiprocketPincodeServiceabilityPayloadSchema,
  checkShiprocketPincodeServiceabilityResponseSchema,
  CreateShiprocketOrderPayload,
  createShiprocketOrderPayloadSchema,
  createShiprocketOrderResponseSchema,
  createShiprocketTokenResponseSchema,
  generateLabelPayloadSchema,
  generateLabelResponseSchema,
  shiprocketErrorSchema,
} from "@/schema/shipping/shiprocket";
import axios, { AxiosError } from "axios";
import { unstable_cache } from "next/cache";
import { logger } from "../logging/server";
import { tryCatch } from "../try-catch";

export async function createShiprocketToken() {
  const response = await tryCatch(
    axios.post("https://apiv2.shiprocket.in/v1/external/auth/login", {
      email: process.env.SHIPROCKET_EMAIL,
      password: process.env.SHIPROCKET_PASSWORD,
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    const parsedError = shiprocketErrorSchema.safeParse(axiosError.response?.data);
    logger.error("[createShiprocketToken] parsedError", { parsedError });
    logger.error("[createShiprocketToken] axiosError", { fetchError: axiosError });
    logger.error("[createShiprocketToken] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(parsedError.success ? parsedError.data.message : axiosError.message || "Unknown error");
  }

  const parsedResponse = createShiprocketTokenResponseSchema.safeParse(response.data.data);
  logger.info("[createShiprocketToken] parsedResponse", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Missing token in response");
  }

  return parsedResponse.data.token;
}

const createShiprocketTokenCache = unstable_cache(createShiprocketToken, ["shiprocket-access-token"], {
  tags: ["api-access-token"],
  revalidate: 604800, // 1 Week
});

export async function checkShiprocketPincodeServiceability(payload: CheckShiprocketPincodeServiceabilityPayload) {
  const parsedPayload = checkShiprocketPincodeServiceabilityPayloadSchema.parse(payload);
  const token = await createShiprocketTokenCache();

  logger.info("[checkShiprocketPincodeServiceability] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.get("https://apiv2.shiprocket.in/v1/external/courier/serviceability/", {
      params: parsedPayload,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    const parsedError = shiprocketErrorSchema.safeParse(axiosError.response?.data);
    logger.error("[checkShiprocketPincodeServiceability] axiosError", { fetchError: axiosError });
    logger.error("[checkShiprocketPincodeServiceability] axiosError.response?.data", {
      response: axiosError.response?.data,
    });
    throw new Error(parsedError.success ? parsedError.data.message : axiosError.message || "Unknown error");
  }

  const parsedResponse = checkShiprocketPincodeServiceabilityResponseSchema.safeParse(response.data.data);
  logger.info("[checkShiprocketPincodeServiceability] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}

export async function createShiprocketOrder(payload: CreateShiprocketOrderPayload) {
  const token = await createShiprocketTokenCache();
  const parsedPayload = createShiprocketOrderPayloadSchema.parse(payload);

  logger.info("[createShiprocketOrder] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.post("https://apiv2.shiprocket.in/v1/external/orders/create/adhoc", parsedPayload, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    const parsedError = shiprocketErrorSchema.safeParse(axiosError.response?.data);
    logger.error("[createShiprocketOrder] axiosError", { fetchError: axiosError });
    logger.error("[createShiprocketOrder] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(parsedError.success ? parsedError.data.message : axiosError.message || "Unknown error");
  }

  const parsedResponse = createShiprocketOrderResponseSchema.safeParse(response.data.data);
  logger.info("[createShiprocketOrder] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}

export async function assignAWBToOrder(shipmentId: number, courierId?: number, status?: string) {
  const token = await createShiprocketTokenCache();
  const parsedPayload = assignAWBToOrderPayloadSchema.parse({
    shipment_id: shipmentId,
    courier_id: courierId,
    status,
  });
  logger.info("[assignAWBToOrder] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.post("https://apiv2.shiprocket.in/v1/external/courier/assign/awb", parsedPayload, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    const parsedError = shiprocketErrorSchema.safeParse(axiosError.response?.data);
    logger.error("[assignAWBToOrder] axiosError", { fetchError: axiosError });
    logger.error("[assignAWBToOrder] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(parsedError.success ? parsedError.data.message : axiosError.message || "Unknown error");
  }

  const parsedResponse = assignAWBToOrderResponseSchema.safeParse(response.data.data);
  logger.info("[assignAWBToOrder] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.data?.awb_assign_status) {
    throw new Error(response.data.data.response.data.awb_assign_error);
  }

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}

export async function generateLabel(shipmentIds: number[]) {
  const token = await createShiprocketTokenCache();
  const parsedPayload = generateLabelPayloadSchema.parse({
    shipment_id: shipmentIds,
  });
  logger.info("[generateLabel] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.post("https://apiv2.shiprocket.in/v1/external/courier/generate/label", parsedPayload, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    const parsedError = shiprocketErrorSchema.safeParse(axiosError.response?.data);
    logger.error("[generateLabel] axiosError", { fetchError: axiosError });
    logger.error("[generateLabel] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(parsedError.success ? parsedError.data.message : axiosError.message || "Unknown error");
  }

  const parsedResponse = generateLabelResponseSchema.safeParse(response.data.data);
  logger.info("[generateLabel] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}

export function getShiprocketZoneName(zone: string): Zones {
  switch (zone) {
    case "z_a":
      return "local";
    case "z_b":
      return "regional";
    case "z_c":
      return "metro";
    case "z_d":
      return "rest-of-india";
    case "z_e":
      return "north-east";
    default:
      return "rest-of-india";
  }
}

export const shiprocketCourierIds = {
  blue_dart: 1,
  amazon_brands: 233,
  amazon_shipping_5kg: 4,
  dtdc_surface: 6,
  delhivery: 10,
  ecom_express_surface: 14,
  dtdc_5kg: 18,
  ecom_express_surface_2kg: 19,
  xpressbees_1kg: 23,
  xpressbees_2kg: 24,
  xpressbees_5kg: 25,
  amazon_shipping_1kg: 29,
  amazon_shipping_2kg: 32,
  xpressbees: 33,
  aramex_international: 35,
  delhivery_surface_5kg: 39,
  delhivery_surface: 43,
  ecom_express_reverse: 45,
  shadowfax_reverse: 46,
  ekart_logistics: 48,
  xpressbees_surface: 51,
  ekart_logistics_surface: 54,
  blue_dart_surface: 55,
  shadowfax_surface: 58,
  ecom_premium_and_ros: 60,
  delhivery_reverse: 61,
  delhivery_500g_savex_a: 64,
  delhivery_500g_savex_s: 65,
  ecom_exp_savex_a: 66,
  ecom_ros_savex_a: 67,
  kerry_indev_express_surface: 69,
  self_delivery: 71,
  bluedart_savex_a: 72,
  srf_standard_500gm: 75,
  delhivery_5kg_savex_s: 76,
  delhivery_10kg_savex_s: 77,
  delhivery_20kg_savex_s: 78,
  srf_standard_2kg: 79,
  srf_standard: 81,
  dtdc_2kg: 82,
  delhivery_500g_savex_rvp: 83,
  delhivery_500g_savex_rvp_qc: 84,
  standard: 85,
  express: 86,
  delhivery_5kg_savex_rvp_s: 87,
  delhivery_10kg_savex_rvp_s: 88,
  delhivery_20kg_savex_rvp_s: 89,
  standard_500gm: 90,
  standard_2kg: 91,
  standard_5kg: 92,
  standard_10kg: 93,
  standard_20kg: 94,
  shadowfax_local: 95,
  dunzo_local: 97,
  srf_standard_5kg: 98,
  ecom_express_ros_reverse: 99,
  delhivery_surface_10kg: 100,
  delhivery_surface_20kg: 101,
  borzo: 106,
  borzo_5kg: 107,
  srf_standard_10kg: 114,
  shadowfax_savex: 115,
  srf_standard_20kg: 116,
  srf_express: 117,
  bluedart_savex_exchange: 118,
  identify_plus_sdd_lite: 119,
  identify_plus_sdd_standard: 120,
  xpressbees_reverse: 125,
  bluedart_savex_tdd: 126,
  ekart_10kg: 130,
  delhivery_reverse_5kg: 138,
  srx_premium: 140,
  srf_rush: 141,
  amazon_surface_500gm_prepaid: 142,
  xpressbees_reverse_2kg: 144,
  xpressbees_reverse_5kg: 145,
  kerry_indev_2kg_surface: 146,
  xpressbees_reverse_1kg: 150,
  kerry_indev_express: 154,
  xpressbees_10kg: 159,
  ekart_2kg: 170,
  ekart_5kg: 171,
  amazon_shipping_10kg: 181,
  amazon_shipping_20kg: 182,
  amazon_surface_500gm_cod: 195,
  dtdc_500gms: 196,
  dtdc_express: 235,
  srx_priority: 240,
  wholemark: 313,
  bluedart_ce_savex: 501,
  sm_shadowfax_surface_3kg: 524,
  shadowfax_ds: 777,
  india_post_surface: 396,
} as const;
