import {
  amazonErrorResponseSchema,
  CreateAmazonOrderPayload,
  createAmazonOrderPayloadSchema,
  createAmazonOrderResponseSchema,
  createAmazonTokenResponseSchema,
  GenerateAmazonLabelPayload,
  generateAmazonLabelPayloadSchema,
  generateAmazonLabelResponseSchema,
} from "@/schema/shipping/amazon";
import axios, { AxiosError } from "axios";
import { unstable_cache } from "next/cache";
import { logger } from "../logging/server";
import { tryCatch } from "../try-catch";

export async function createAmazonToken() {
  const response = await tryCatch(
    axios.post("https://api.amazon.com/auth/o2/token", {
      grant_type: "refresh_token",
      refresh_token: process.env.AMAZON_SHIPPING_REFRESH_TOKEN,
      client_id: process.env.AMAZON_SHIPPING_CLIENT_ID,
      client_secret: process.env.AMAZON_SHIPPING_CLIENT_SECRET,
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    const parsedError = amazonErrorResponseSchema.safeParse(axiosError.response?.data);
    logger.error("[createAmazonToken] parsedError", { parsedError });
    logger.error("[createAmazonToken] axiosError", { fetchError: axiosError });
    logger.error("[createAmazonToken] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(parsedError.success ? parsedError.data.errors[0].message : axiosError.message || "Unknown error");
  }

  const parsedResponse = createAmazonTokenResponseSchema.safeParse(response.data.data);
  logger.info("[createAmazonToken] parsedResponse", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Missing token in response");
  }

  return parsedResponse.data.access_token;
}

const createAmazonTokenCache = unstable_cache(createAmazonToken, ["amazon-access-token"], {
  tags: ["api-access-token"],
  revalidate: 3000, // 50 Minutes
});

export async function createAmazonOrder(payload: CreateAmazonOrderPayload) {
  const parsedPayload = createAmazonOrderPayloadSchema.parse(payload);
  logger.info("[createAmazonOrder] payload", { input: parsedPayload });

  const token = await createAmazonTokenCache();

  const response = await tryCatch(
    axios.post("https://sellingpartnerapi-eu.amazon.com/shipping/v2/shipments/rates", parsedPayload, {
      headers: {
        "x-amz-access-token": token,
        "x-amzn-shipping-business-id": "AmazonShipping_IN",
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    const parsedError = amazonErrorResponseSchema.safeParse(axiosError.response?.data);
    logger.error("[createAmazonOrder] axiosError", { fetchError: axiosError });
    logger.error("[createAmazonOrder] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(parsedError.success ? parsedError.data.errors[0].message : axiosError.message || "Unknown error");
  }

  const parsedResponse = createAmazonOrderResponseSchema.safeParse(response.data.data.payload);
  logger.info("[createAmazonOrder] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}

export async function generateAmazonLabel(payload: GenerateAmazonLabelPayload) {
  const parsedPayload = generateAmazonLabelPayloadSchema.parse(payload);
  logger.info("[generateAmazonLabel] payload", { input: parsedPayload });

  const token = await createAmazonTokenCache();

  const response = await tryCatch(
    axios.post("https://sellingpartnerapi-eu.amazon.com/shipping/v2/shipments", parsedPayload, {
      headers: {
        "x-amz-access-token": token,
        "x-amzn-shipping-business-id": "AmazonShipping_IN",
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    const parsedError = amazonErrorResponseSchema.safeParse(axiosError.response?.data);
    logger.error("[generateAmazonLabel] axiosError", { fetchError: axiosError });
    logger.error("[generateAmazonLabel] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(parsedError.success ? parsedError.data.errors[0].message : axiosError.message || "Unknown error");
  }

  const parsedResponse = generateAmazonLabelResponseSchema.safeParse(response.data.data.payload);
  logger.info("[generateAmazonLabel] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}
