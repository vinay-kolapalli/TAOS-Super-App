import { Zones } from "@/data/shipping";
import {
  CalculateDelhiveryRatePayload,
  calculateDelhiveryRatePayloadSchema,
  calculateDelhiveryRateResponseSchema,
  checkDelhiveryPincodeServiceabilityResponseSchema,
  CreateDelhiveryOrderPayload,
  createDelhiveryOrderPayloadSchema,
  createDelhiveryOrderResponseSchema,
  printDelhiveryShippingLabelResponseSchema,
} from "@/schema/shipping/delhivery";
import axios, { AxiosError } from "axios";
import { logger } from "../logging/server";
import { tryCatch } from "../try-catch";

export async function checkDelhiveryPincodeServiceability(pincode: number) {
  logger.info("[checkDelhiveryPincodeServiceability] payload", { input: pincode });

  const response = await tryCatch(
    axios.get("https://track.delhivery.com/c/api/pin-codes/json/", {
      headers: {
        Authorization: `Token ${process.env.DELHIVERY_API_KEY}`,
      },
      params: {
        filter_codes: pincode,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[checkDelhiveryPincodeServiceability] axiosError", { fetchError: axiosError });
    logger.error("[checkDelhiveryPincodeServiceability] axiosError.response?.data", {
      response: axiosError.response?.data,
    });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = checkDelhiveryPincodeServiceabilityResponseSchema.safeParse(response.data.data);
  logger.info("[checkDelhiveryPincodeServiceability] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}

export async function calculateDelhiveryRate(payload: CalculateDelhiveryRatePayload) {
  const parsedPayload = calculateDelhiveryRatePayloadSchema.parse(payload);
  logger.info("[calculateDelhiveryRate] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.get("https://track.delhivery.com/api/kinko/v1/invoice/charges/.json", {
      headers: {
        Authorization: `Token ${process.env.DELHIVERY_API_KEY}`,
      },
      params: parsedPayload,
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[calculateDelhiveryRate] axiosError", { fetchError: axiosError });
    logger.error("[calculateDelhiveryRate] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = calculateDelhiveryRateResponseSchema.safeParse(response.data.data);
  logger.info("[calculateDelhiveryRate] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  if (response.data.data?.error) {
    throw new Error(response.data.data.error || "Unknown error");
  }

  return parsedResponse.data;
}

export async function createDelhiveryOrder(payload: CreateDelhiveryOrderPayload) {
  const parsedPayload = createDelhiveryOrderPayloadSchema.parse(payload);
  logger.info("[createDelhiveryOrder] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.post("https://track.delhivery.com/api/cmu/create.json", `format=json&data=${JSON.stringify(parsedPayload)}`, {
      headers: {
        Authorization: `Token ${process.env.DELHIVERY_API_KEY}`,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[createDelhiveryOrder] axiosError", { fetchError: axiosError });
    logger.error("[createDelhiveryOrder] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = createDelhiveryOrderResponseSchema.safeParse(response.data.data);
  logger.info("[createDelhiveryOrder] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  if (!parsedResponse.data.success) {
    throw new Error(parsedResponse.data.rmk || "Unknown error");
  }

  if (!parsedResponse.data.packages?.[0]?.waybill) {
    throw new Error(parsedResponse.data?.rmk || "Tracking number not found");
  }

  return parsedResponse.data;
}

export async function printDelhiveryShippingLabel(trackingNumber: string) {
  logger.info("[printDelhiveryShippingLabel] payload", { input: trackingNumber });

  const response = await tryCatch(
    axios.get("https://track.delhivery.com/api/p/packing_slip", {
      params: {
        wbns: trackingNumber,
        pdf: true,
        pdf_size: "4R",
      },
      headers: {
        Authorization: `Token ${process.env.DELHIVERY_API_KEY}`,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[printDelhiveryShippingLabel] axiosError", { fetchError: axiosError });
    logger.error("[printDelhiveryShippingLabel] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(axiosError.message || "Unknown error");
  }

  const parsedResponse = printDelhiveryShippingLabelResponseSchema.safeParse(response.data.data);
  logger.info("[printDelhiveryShippingLabel] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  return parsedResponse.data;
}

export function getDelhiveryZoneName(zone: string): Zones {
  switch (zone) {
    case "A":
      return "local";
    case "B":
      return "regional";
    case "C":
      return "metro";
    case "D":
      return "rest-of-india";
    case "E":
      return "north-east";
    case "F":
      return "rest-of-india";
    default:
      return "rest-of-india";
  }
}
