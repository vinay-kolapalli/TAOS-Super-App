import {
  CreateFshipOrderPayload,
  createFshipOrderPayloadSchema,
  createFshipOrderResponseSchema,
  registerFshipPickupResponseSchema,
} from "@/schema/shipping/fship";
import axios, { AxiosError } from "axios";
import { logger } from "../logging/server";
import { tryCatch } from "../try-catch";

export async function createFshipOrder(payload: CreateFshipOrderPayload) {
  const parsedPayload = createFshipOrderPayloadSchema.parse(payload);
  logger.info("[createFshipOrder] payload", { input: parsedPayload });

  const response = await tryCatch(
    axios.post("https://capi.fship.in/api/createforwardorder", parsedPayload, {
      headers: {
        signature: process.env.FSHIP_API_KEY,
      },
    })
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[createFshipOrder] axiosError", { fetchError: axiosError });
    logger.error("[createFshipOrder] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(axiosError.message ?? "Unknown error");
  }

  const parsedResponse = createFshipOrderResponseSchema.safeParse(response.data.data);
  logger.info("[createFshipOrder] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  if (!parsedResponse.data.status) {
    throw new Error(parsedResponse.data.response ?? "Unknown error");
  }

  if (!parsedResponse.data.waybill) {
    throw new Error(parsedResponse.data?.response ?? "Tracking number not found");
  }

  return parsedResponse.data;
}

export async function registerFshipPickup(waybill: string) {
  logger.info("[registerFshipPickup] payload", { input: waybill });

  const response = await tryCatch(
    axios.post(
      "https://capi.fship.in/api/registerpickup",
      {
        waybills: [waybill],
      },
      {
        headers: {
          signature: process.env.FSHIP_API_KEY,
        },
      }
    )
  );

  if (response.error) {
    const axiosError = response.error as AxiosError;
    logger.error("[registerFshipPickup] axiosError", { fetchError: axiosError });
    logger.error("[registerFshipPickup] axiosError.response?.data", { response: axiosError.response?.data });
    throw new Error(axiosError.message ?? "Unknown error");
  }

  const parsedResponse = registerFshipPickupResponseSchema.safeParse(response.data.data);
  logger.info("[registerFshipPickup] response", { parsedResponse, response: response.data.data });

  if (!parsedResponse.success) {
    throw new Error("Invalid response");
  }

  if (!parsedResponse.data.status) {
    throw new Error(parsedResponse.data.response ?? "Unknown error");
  }

  return parsedResponse.data.apipickuporderids[0];
}

export const fshipCourierIds = {
  delhivery: 65,
  amazon_india: 64,
} as const;
