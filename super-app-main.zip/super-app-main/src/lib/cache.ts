import toast from "react-hot-toast";
import { orpc } from "./orpc/client";

export async function purgeCache() {
  toast.promise(orpc.cache.clearCache(), {
    loading: "Clearing cache...",
    success: "Cache cleared",
    error: "Unable to clear cache",
  });
}
