import BWLogoImg from "@/assets/brand/bw-logo.png";
import { Order } from "@/types/order";
import { generateBarcode } from "@/utils/barcode";
import { generateQRCode } from "@/utils/qr";
import { format } from "date-fns";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { robotoBoldFont, robotoNormalFont } from "./jspdf-fonts";

interface ProductTableConfig {
  title: string;
  items: Order["lineItems"];
  showBlackBox: boolean;
}

// --- Main Function ---
export async function generateInvoices(orders: Order[]): Promise<Buffer> {
  const fontFamily = "Roboto";
  const fontSize = 10;
  const selectedColor = "#545d66";

  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });
  doc.addFileToVFS("Roboto.ttf", robotoNormalFont);
  doc.addFileToVFS("Roboto-bold.ttf", robotoBoldFont);
  doc.addFont("Roboto.ttf", "Roboto", "normal");
  doc.addFont("Roboto-bold.ttf", "Roboto", "bold");
  doc.setFont(fontFamily);
  doc.setFontSize(fontSize);
  doc.setTextColor(selectedColor);

  for (let pageIndex = 0; pageIndex < orders.length; pageIndex++) {
    const order = orders[pageIndex];
    const hasDamagedCoupon = order.coupons.some((coupon) => coupon.toLowerCase().startsWith("dam"));
    const hasMissingCoupon = order.coupons.some((coupon) => coupon.toLowerCase().startsWith("mis"));
    const hasGiftWrapProduct = order.lineItems.some((item) => item.name.toLowerCase().includes("gift wrap"));
    const hasShortAddress = (order.shipping.address1 + order.shipping.address2).replaceAll(" ", "").length < 30;

    if (pageIndex > 0) doc.addPage();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 6;
    let y = margin;

    let shippingMethod = order.shippingMethod;
    const lowerCaseShippingMethod = shippingMethod.toLowerCase();
    const hideShippingMethod = lowerCaseShippingMethod.includes("normal") && !hasGiftWrapProduct;

    if (hasGiftWrapProduct) {
      shippingMethod += " + Gift Wrap";
    }

    let freeItems = "";
    // if (order.calculations.total >= 199 && order.calculations.total < 299) {
    //   freeItems = "Free 1 Growbag";
    // } else if (order.calculations.total >= 299 && order.calculations.total < 499) {
    //   freeItems = "Free 2 Growbags";
    // } else if (order.calculations.total >= 499 && order.calculations.total < 999) {
    //   freeItems = "Free 4 Growbags";
    // } else if (order.calculations.total >= 999) {
    //   freeItems = "Free 6 Growbags + 1 Bamboo Toothbrush";
    // }

    // Function to check if there's enough space on the current page and add a new page if needed
    function checkAndAddPage(requiredSpace: number) {
      // Get the current page height and calculate remaining space
      const currentY = y;
      const remainingSpace = pageHeight - margin - currentY;

      // If there's not enough space, add a new page
      if (remainingSpace < requiredSpace) {
        doc.addPage();
        y = margin;
        return true; // Indicates a page was added
      }
      return false; // No page was added
    }

    // Helper function to render product table
    function renderProductTable(config: ProductTableConfig, y: number): number {
      if (config.items.length === 0) return y;

      checkAndAddPage(20);
      doc.setFont(fontFamily, "bold");
      doc.setFontSize(11);
      doc.text(config.title, margin, y);
      doc.setFont(fontFamily, "normal");
      doc.setFontSize(fontSize);
      y += 2; // Reduced from 4 to 2

      const tableHeaders = ["", "S.No", "Product", "SKU", "Qty", "Price", "Tax", "Total"];
      const columnStyles = {
        0: { cellWidth: 8 }, // Black box column
        1: { cellWidth: 12 }, // Serial No
        2: { cellWidth: 95 }, // Product name
        3: { cellWidth: 23 }, // Product name
        4: { cellWidth: 10 }, // Qty
        5: { cellWidth: 19 }, // Price
        6: { cellWidth: 14 }, // Tax
        7: { cellWidth: 19 }, // Total
      };

      const tableBody = config.items.map((item, index) => [
        " ", // Black box placeholder
        index + 1, // Serial No placeholder
        item.name,
        item.sku,
        item.quantity,
        "₹" + item.price,
        "₹" + item.tax,
        "₹" + item.total,
      ]);

      autoTable(doc, {
        head: [tableHeaders],
        body: tableBody,
        startY: y,
        theme: "grid",
        headStyles: {
          fillColor: [244, 244, 244],
          textColor: 0,
          fontSize: 10,
          font: fontFamily,
        },
        bodyStyles: { fontSize: 10, font: fontFamily },
        columnStyles: columnStyles,
        didDrawCell: (data) => {
          if (data.column.index === 0 && data.section === "body" && config.showBlackBox) {
            const boxX = data.cell.x + 2;
            const boxY = data.cell.y + 1;
            doc.setFillColor("#000000");
            doc.rect(boxX, boxY, 6, 6, "F");
          }
        },
        margin: { left: margin, right: margin },
        styles: { cellPadding: 2 },
        pageBreak: "auto",
        rowPageBreak: "auto",
        tableWidth: "auto",
      });
      // @ts-expect-error Property 'lastAutoTable' does not exist on type 'jsPDF' but exists in the js autoTable library.
      return doc.lastAutoTable.finalY + 5;
    }

    // --- HEADER: Logo, From Address, Invoice Info, QR Code ---
    checkAndAddPage(70);
    // Logo
    const logoWidth = 20;
    const logoHeight = 20;
    doc.addImage(BWLogoImg.src, "PNG", margin, y, logoWidth, logoHeight);
    // From Address
    const fromAddressLines = [
      "The Affordable Organic Store",
      "7-4-53/1, Vani Nagar, Balanagar, Hyderabad",
      "Telangana - 500011",
      "info@theaffordableorganicstore.com",
      "040 6658 8313",
      "GSTIN: 36BAXPG9210J1Z9",
    ];
    fromAddressLines.forEach((line, i) => {
      doc.setFontSize(11);
      doc.text(line, margin, y + logoHeight + 7 + i * 5);
    });
    doc.setFontSize(fontSize);

    // Invoice Info and QR Code (right)
    const infoX = pageWidth - margin - 65;
    // Invoice info background
    doc.setFillColor(244, 244, 244);
    doc.rect(infoX, y, 65, 14, "F");
    doc.text(`INVOICE: ${order.number}`, infoX + 2, y + 5);
    doc.text(`ORDER ID: ${order.id}`, infoX + 2, y + 11);
    // Inline QR code logic
    const qrDataUrl = await generateQRCode(String(order.number));
    doc.addImage(qrDataUrl, "PNG", infoX, y + 14, 25, 25);
    // QR instructions below QR
    const orderDate = order.createdAt ? format(new Date(order.createdAt), "dd/MMM/yyyy") : "";
    ["Scan the QR code to learn how to", "use our seeds or visit", "https://bit.ly/38L8Koz"].forEach((line, i) => {
      doc.text(line, infoX, y + 43 + i * 5);
    });
    doc.setFontSize(11);
    doc.setFont(fontFamily, "bold");
    doc.text(`Order Date: ${orderDate}`, infoX, y + 60);

    // --- CUSTOMER NAME & DIVIDER ---
    y += 60;
    checkAndAddPage(10);
    const shipping = order.shipping || {};
    const customerName = [shipping.firstName, shipping.lastName].filter(Boolean).join(" ");
    doc.text(`Customer: ${customerName}`, margin, y);
    doc.setFontSize(fontSize);
    doc.setFont(fontFamily, "normal");
    y += 3;
    doc.setDrawColor(180);
    doc.line(margin, y, pageWidth - margin, y);

    // --- PRODUCT TABLES ---
    y += 5;

    // Separate items into different categories
    const plantItems = order.lineItems
      .filter((item) => item.tags.some((tag) => tag.toLowerCase() === "plant"))
      .sort((a, b) => a.name.localeCompare(b.name));

    const miniatureItems = order.lineItems
      .filter((item) => item.tags.some((tag) => tag.toLowerCase() === "miniature"))
      .sort((a, b) => a.name.localeCompare(b.name));

    const buildingBlockItems = order.lineItems
      .filter((item) => item.tags.some((tag) => tag.toLowerCase() === "building block"))
      .sort((a, b) => a.name.localeCompare(b.name));

    const otherItems = order.lineItems
      .filter((item) => !item.tags.some((tag) => ["plant", "miniature", "building block"].includes(tag.toLowerCase())))
      .sort((a, b) => a.name.localeCompare(b.name));

    // Render tables for each category
    const productTables: ProductTableConfig[] = [
      { title: "Plants", items: plantItems, showBlackBox: true },
      { title: "Miniatures", items: miniatureItems, showBlackBox: false },
      { title: "Building Blocks", items: buildingBlockItems, showBlackBox: false },
      { title: "Other Products", items: otherItems, showBlackBox: false },
    ];

    productTables.forEach((tableConfig) => {
      y = renderProductTable(tableConfig, y);
    });

    // --- TOTALS SECTION ---
    checkAndAddPage(30);
    const totals = [
      ["Subtotal:", "₹" + order.calculations.subtotal],
      ["Discount:", "₹" + order.calculations.discount],
      ["Shipping:", "₹" + order.calculations.shipping],
    ];
    totals.forEach(([label, value], i) => {
      doc.text(String(label), pageWidth - margin - 45, y + i * 6);
      doc.text(String(value), pageWidth - margin - 15, y + i * 6);
    });

    // Split note into lines that fit within available width
    const maxWidth = pageWidth - margin - 50; // Leave space for totals
    const noteLines = doc.splitTextToSize(order.metadata.note ? `Note: ${order.metadata.note}` : "", maxWidth);

    // Draw each line of the note
    doc.setFontSize(9);
    noteLines.forEach((line: string, i: number) => {
      doc.text(line, margin, y + i * 4);
    });
    y += Math.max(totals.length, noteLines.length) * 6;

    // Total box
    doc.setFillColor(244, 244, 244);
    doc.rect(margin, y, pageWidth - margin * 2, 8, "F");
    doc.text(freeItems, margin + 5, y + 5);
    doc.setFont(fontFamily, "bold");
    doc.setFontSize(12);
    doc.text(`Total: ₹${order.calculations.total}`, pageWidth - margin - 30, y + 5);
    doc.setFont(fontFamily, "normal");
    doc.setFontSize(fontSize);
    y += 10;

    // --- THANK YOU & WEBSITE (GRAY LINES) ---
    checkAndAddPage(20);
    const thankHeight = 16;
    doc.setDrawColor(180);
    doc.setLineWidth(0.2);
    doc.line(margin, y, pageWidth - margin, y);
    doc.line(margin, y + thankHeight, pageWidth - margin, y + thankHeight);
    doc.setFontSize(11);
    doc.text("Thank you!", margin + (pageWidth - margin * 2) / 2, y + 6, {
      align: "center",
    });
    doc.text("www.theaffordableorganicstore.com", margin + (pageWidth - margin * 2) / 2, y + 12, { align: "center" });
    doc.setFontSize(fontSize);
    y += thankHeight + 7;

    // --- SHIPPING ADDRESS & BARCODE ---
    checkAndAddPage(50);
    doc.setFont(fontFamily, "bold");
    doc.setFontSize(12);
    doc.text(`Shipping Address ${hasShortAddress ? "(Short)" : ""}`, margin, y);
    doc.setFont(fontFamily, "normal");
    doc.setFontSize(15);
    const shippingLines = [
      `${order.shipping.firstName} ${order.shipping.lastName}`,
      order.shipping.company,
      order.shipping.address1,
      order.shipping.address2,
      [order.shipping.city, order.shipping.postcode].filter(Boolean).join(", "),
      [order.shipping.state, "India"].filter(Boolean).join(", "),
      order.shipping.phone ? `Phone: ${order.shipping.phone}` : undefined,
    ].filter(Boolean);

    // Calculate max width for address (leave space for barcode)
    const barcodeWidth = 40;
    const addressMaxWidth = pageWidth - margin * 15;
    let addressY = y + 7;

    // Use a text splitting approach that works better with page breaks
    shippingLines.forEach((line) => {
      if (!line) return;
      const wrapped = doc.splitTextToSize(line, addressMaxWidth);
      wrapped.forEach((wline: string) => {
        checkAndAddPage(6);
        doc.text(wline, margin, addressY);
        addressY += 6;
      });
    });
    if (!hideShippingMethod) {
      doc.setFont(fontFamily, "normal");
      doc.text("Shipping method: ", margin, addressY);
      const methodWidth = doc.getTextWidth("Shipping method: ");
      if (shippingMethod.toLowerCase().includes("parcel") || shippingMethod.toLowerCase().includes("gift")) {
        doc.setFont(fontFamily, "bold");
      }
      doc.text(shippingMethod, margin + methodWidth, addressY);
      addressY += 6;
      doc.setFont(fontFamily, "normal");
    }
    doc.setFontSize(fontSize);

    // Barcode (right)
    const barcodeX = pageWidth - margin - barcodeWidth;
    const barcodeY = y;
    const barcodeDataUrl = await generateBarcode(String(order.number), {
      height: 30,
      includeText: false,
    });
    doc.addImage(barcodeDataUrl, "PNG", barcodeX, barcodeY, barcodeWidth, 10);
    doc.text(`Order: ${order.number}`, barcodeX, barcodeY + 15);
    doc.text(
      `Type: ${hasDamagedCoupon ? "Damaged" : hasMissingCoupon ? "Missing" : "Normal"}`,
      barcodeX,
      barcodeY + 20
    );
    // Coupons
    order.coupons.forEach((coupon, i) => {
      doc.text(`Coupon ${i + 1}: ${coupon}`, barcodeX, barcodeY + 25 + i * 5);
    });
    y = Math.max(addressY, barcodeY + 20) + 10;
  }

  return Buffer.from(doc.output("arraybuffer"));
}
