import jsPDF from "jspdf";
import { Order } from "../types/order";
import { generateBarcode } from "../utils/barcode";
import { generateQRCode } from "../utils/qr";

// Static configuration for packing slip
const PACKING_SLIP_CONFIG = {
  offerText: "OFFER RS 100 OFF",
  offerInstructions: [
    "Write a review on our Instagram posts and get Rs 50 off on your next order",
    "Send the screenshot to us",
    "Rate us on Google and get an additional Rs 50 off on your next order",
  ],
  instagramUrl: "https://bit.ly/3NjmARP",
  googleReviewUrl: "https://bit.ly/3NHjcl3",
  storeInfo: {
    name: "The Affordable Organic Store",
    addressLine1: "7-4-53/1, Vani Nagar,",
    addressLine2: "Balanagar, Hyderabad Telangana-500011",
    phone: "040 6658 8313",
  },
};

export async function generatePackingSlips(orders: Order[]): Promise<Buffer> {
  // Create a new PDF document (A5 size)
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a5",
  });

  // Process each order
  for (let i = 0; i < orders.length; i++) {
    const order = orders[i];

    // Add a new page for each order after the first one
    if (i > 0) {
      doc.addPage();
    }

    // Get page dimensions and set margins
    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 5;
    const maxWidth = 65;

    // --- SHIPPING ADDRESS SECTION ---
    // Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text("Shipping Address", margin, margin + 5);

    // Address content
    doc.setFont("helvetica", "normal");
    doc.setFontSize(16);

    // Format shipping address as a single text block for simpler rendering
    const shippingAddressText = [
      `${order.shipping.firstName} ${order.shipping.lastName}`,
      order.shipping.address1,
      order.shipping.address2,
      `${order.shipping.city} ${order.shipping.state} ${order.shipping.postcode}`,
      String(order.shipping.phone),
    ].join("\n");

    // Split text to fit within maxWidth and render
    const shippingLines = doc.splitTextToSize(shippingAddressText, maxWidth);
    doc.text(shippingLines, margin, margin + 13);

    // --- FROM ADDRESS SECTION ---
    // Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(15);
    doc.text("From Address", pageWidth - margin - maxWidth, margin + 5);

    // Address content
    doc.setFont("helvetica", "normal");
    doc.setFontSize(15);

    // Format from address as a single text block
    const fromAddressText = [
      PACKING_SLIP_CONFIG.storeInfo.name,
      PACKING_SLIP_CONFIG.storeInfo.addressLine1,
      PACKING_SLIP_CONFIG.storeInfo.addressLine2,
      PACKING_SLIP_CONFIG.storeInfo.phone,
    ].join("\n");

    // Split text to fit within maxWidth and render
    const fromLines = doc.splitTextToSize(fromAddressText, maxWidth);
    doc.text(fromLines, pageWidth - margin - maxWidth, margin + 13);

    // --- BARCODE SECTION ---
    // Generate barcode for order number
    const barcodeDataUrl = generateBarcode(String(order.number), {
      height: 50,
      includeText: false,
    });

    // Add barcode image - adjust position to account for larger address text
    doc.addImage(barcodeDataUrl, "PNG", pageWidth - margin - maxWidth, margin + 47, maxWidth, 18);

    // Add order number text below barcode
    doc.setFont("helvetica", "bold");
    doc.setFontSize(14);
    doc.text(`Order No: ${order.number}`, pageWidth - margin - maxWidth + maxWidth / 2, margin + 72, {
      align: "center",
    });

    // --- OFFER SECTION ---
    const offerY = margin + 85;

    // Offer title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(100, 100, 100);
    doc.text(PACKING_SLIP_CONFIG.offerText, pageWidth / 2, offerY, {
      align: "center",
    });

    // Offer instructions
    doc.setFont("helvetica", "normal");
    doc.setFontSize(13);

    let y = offerY + 12;

    // Render each instruction with proper numbering
    PACKING_SLIP_CONFIG.offerInstructions.forEach((instruction, index) => {
      const text = `${index + 1}. ${instruction}`;
      const lines = doc.splitTextToSize(text, pageWidth - margin * 2);
      doc.text(lines, margin, y);
      y += lines.length * 6;
    });

    // --- QR CODE SECTION ---
    // Calculate position for QR codes
    const qrSize = 35;
    const qrY = margin + 130;

    // Generate QR codes
    const instagramQRUrl = await generateQRCode(PACKING_SLIP_CONFIG.instagramUrl);
    const googleQRUrl = await generateQRCode(PACKING_SLIP_CONFIG.googleReviewUrl);

    // Instagram QR code
    doc.setFont("helvetica", "normal");
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text("Instagram", pageWidth / 4, qrY - 3, { align: "center" });
    doc.addImage(instagramQRUrl, "PNG", pageWidth / 4 - qrSize / 2, qrY, qrSize, qrSize);

    // Google QR code
    doc.text("Google", (pageWidth * 3) / 4, qrY - 3, { align: "center" });
    doc.addImage(googleQRUrl, "PNG", (pageWidth * 3) / 4 - qrSize / 2, qrY, qrSize, qrSize);
  }

  // Return the PDF as a buffer
  return Buffer.from(doc.output("arraybuffer"));
}
