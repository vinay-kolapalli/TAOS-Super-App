import axios from "axios";
import { headers } from "next/headers";
import "server-only";
import { z } from "zod";

export const sendMailOptionsSchema = z.object({
  to: z.string(),
  subject: z.string(),
  text: z.string().optional(),
  html: z.string().optional(),
  attachments: z
    .array(
      z.object({
        filename: z.string(),
        content: z.string(),
        contentType: z.string(),
      })
    )
    .optional(),
});

export type SendMailOptions = z.infer<typeof sendMailOptionsSchema>;

export async function sendMail(options: SendMailOptions) {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const nodemailer = await import("nodemailer");
    const parsedOptions = sendMailOptionsSchema.parse(options);
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: 587,
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD,
      },
    });

    // Send the email
    await transporter.sendMail({
      from: process.env.SMTP_FROM,
      ...parsedOptions,
    });
  }
}

export async function sendMailApi(options: SendMailOptions) {
  const headerList = await headers();
  await axios.post(String(new URL("/api/mail", process.env.VERCEL_URL ?? process.env.BETTER_AUTH_URL)), options, {
    headers: Object.fromEntries(headerList.entries()),
  });
}
