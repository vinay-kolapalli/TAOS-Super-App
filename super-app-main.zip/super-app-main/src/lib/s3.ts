import { PutObjectCommand, S3Client } from "@aws-sdk/client-s3";

export const CLOUDFLARE_R2_BUCKET_NAME = "taos-super-app";

const S3 = new S3Client({
  region: "auto",
  endpoint: `https://${process.env.CLOUDFLARE_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: process.env.CLOUDFLARE_R2_KEY_ID,
    secretAccessKey: process.env.CLOUDFLARE_R2_SECRET_KEY,
  },
});

export async function uploadFile({
  file,
  key,
  contentType,
  expires,
}: {
  file: File | string | Buffer;
  key: string;
  contentType: string;
  expires?: number;
}) {
  const command = new PutObjectCommand({
    Bucket: CLOUDFLARE_R2_BUCKET_NAME,
    Key: key,
    Body: file,
    ContentType: contentType,
    Expires: expires ? new Date(Date.now() + expires * 1000) : undefined,
  });

  await S3.send(command);
  return getSignedUrl(key);
}

export function getSignedUrl(key: string, expires?: number) {
  if (key.startsWith(process.env.NEXT_PUBLIC_CLOUDFLARE_R2_ENDPOINT || "")) {
    return key;
  }

  return `${process.env.NEXT_PUBLIC_CLOUDFLARE_R2_ENDPOINT}${key.startsWith("/") ? key : `/${key}`}`;
}
