import { AxiosError } from "axios";

export interface ErrorResponse {
  message: string;
  status: number;
  data?: any;
  _parsed?: boolean;
}

export function parseError(error: unknown): ErrorResponse {
  // Return early if already parsed
  if (error instanceof AxiosError && error.response?.data._parsed) {
    return error.response.data;
  }

  const baseResponse = {
    _parsed: true,
    status: 500,
    message: "An unknown error occurred",
  };

  if (error instanceof AxiosError) {
    return {
      ...baseResponse,
      message: error.response?.data?.message || error?.message,
      status: error.response?.status || 500,
      data: error.response?.data,
    };
  }

  if (error instanceof Error) {
    return {
      ...baseResponse,
      message: error.message,
    };
  }

  if (typeof error === "string") {
    return {
      ...baseResponse,
      message: error,
    };
  }

  return baseResponse;
}
