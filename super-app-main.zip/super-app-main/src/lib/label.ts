import { generateBarcode } from "@/utils/barcode";
import { generateQRCode } from "@/utils/qr";
import jsPDF from "jspdf";

interface QRCodeProductLabelData {
  orderNumber?: number;
  productName: string;
  value: string;
}

interface BarcodeProductLabelData {
  productName: string;
  value: string;
}

export async function generateQRProductLabels(dataArray: QRCodeProductLabelData[]): Promise<Buffer> {
  const doc = new jsPDF({
    orientation: "landscape",
    unit: "mm",
    format: [35, 35],
  });

  const margin = 5 / 3.78;
  const textQrGap = 3;

  for (let i = 0; i < dataArray.length; i++) {
    const data = dataArray[i];

    if (i > 0) {
      doc.addPage();
    }

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    doc.setFontSize(7);
    const textLines = doc.splitTextToSize(data.productName, pageWidth - margin * 2.5);
    const textHeight = textLines.length * (doc.getTextDimensions("Text").h * 1.2);

    doc.setFontSize(8);
    const orderNumberHeight = data.orderNumber ? doc.getTextDimensions("Text").h * 1.5 : 0;

    const totalTextHeight = textHeight + orderNumberHeight + textQrGap * 2;
    const qrSize = Math.min(pageWidth - margin * 2, pageHeight - margin * 2 - totalTextHeight * 0.7);

    const qrCodeData = await generateQRCode(data.value);
    const qrX = (pageWidth - qrSize) / 2;
    const qrY = margin;

    doc.addImage(qrCodeData, "PNG", qrX, qrY, qrSize, qrSize);

    doc.setFontSize(8);
    const textY = qrY + qrSize + textQrGap;
    doc.text(textLines, pageWidth / 2, textY, { align: "center" });

    if (data.orderNumber) {
      const orderY = textY + textHeight + textQrGap * 0.5;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.text(String(data.orderNumber), pageWidth / 2, orderY, {
        align: "center",
      });
      doc.setFont("helvetica", "normal");
    }
  }

  return Buffer.from(doc.output("arraybuffer"));
}

export async function generateBarcodeProductLabels(dataArray: BarcodeProductLabelData[]): Promise<Buffer> {
  const doc = new jsPDF({
    orientation: "landscape",
    unit: "mm",
    format: [45, 35], // 4.5 x 3.5 cm
  });

  const margin = 1.5; // 1.5mm padding

  for (let i = 0; i < dataArray.length; i++) {
    const data = dataArray[i];

    if (i > 0) {
      doc.addPage();
    }

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    const barcodePng = generateBarcode(data.value, {
      includeText: true,
    });

    doc.setFontSize(6);
    const textLines = doc.splitTextToSize(data.productName, pageWidth - margin * 2);
    const lineHeight = doc.getTextDimensions("Text").h * 1.1;
    const textHeight = textLines.length * lineHeight;

    doc.text(textLines, pageWidth / 2, margin + lineHeight, {
      align: "center",
    });

    const barcodeHeight = pageHeight - (margin * 2 + textHeight + 1);
    const barcodeWidth = pageWidth - margin * 2;
    const barcodeX = margin;
    const barcodeY = margin + textHeight + 1;

    doc.addImage(barcodePng, "PNG", barcodeX, barcodeY, barcodeWidth, barcodeHeight);
  }

  return Buffer.from(doc.output("arraybuffer"));
}

interface QRLabelOptions {
  includeText?: boolean;
  styleOptions?: {
    widthInches?: number;
    heightInches?: number;
    margin?: number;
  };
}

export async function generateQRLabels(dataArray: string[], options?: QRLabelOptions): Promise<Buffer> {
  // Convert inches to mm (1 inch = 25.4 mm)
  const widthMm = (options?.styleOptions?.widthInches || 1.5) * 25.4;
  const heightMm = (options?.styleOptions?.heightInches || 1.5) * 25.4;

  const doc = new jsPDF({
    orientation: "landscape",
    unit: "mm",
    format: [widthMm, heightMm],
  });

  const margin = options?.styleOptions?.margin || 2;

  for (let i = 0; i < dataArray.length; i++) {
    const value = dataArray[i];

    if (i > 0) {
      doc.addPage();
    }

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    // Calculate QR code size based on available space
    const qrSize = Math.max(
      10,
      Math.min(pageWidth - margin * 2, pageHeight - (options?.includeText ? margin * 4 : margin * 2))
    );

    // Generate and place QR code with default options (no custom styling for simplicity)
    const qrCodeData = await generateQRCode(value);
    const qrX = (pageWidth - qrSize) / 2;
    const qrY = margin;

    doc.addImage(qrCodeData, "PNG", qrX, qrY, qrSize, qrSize);

    // Add text if includeText option is true
    if (options?.includeText) {
      doc.setFontSize(widthMm / 3.5);
      const textLines = doc.splitTextToSize(value, pageWidth - margin * 2);
      const textY = qrY + qrSize + margin;
      doc.text(textLines, pageWidth / 2, textY, { align: "center" });
    }
  }

  return Buffer.from(doc.output("arraybuffer"));
}

interface BarcodeLabelOptions {
  includeText?: boolean;
  styleOptions?: {
    widthInches?: number;
    heightInches?: number;
    margin?: number;
  };
}

export async function generateBarcodeLabels(dataArray: string[], options?: BarcodeLabelOptions): Promise<Buffer> {
  // Convert inches to mm (1 inch = 25.4 mm)
  const widthMm = (options?.styleOptions?.widthInches || 2) * 25.4;
  const heightMm = (options?.styleOptions?.heightInches || 1) * 25.4;

  const doc = new jsPDF({
    orientation: "landscape",
    unit: "mm",
    format: [widthMm, heightMm],
  });

  const margin = options?.styleOptions?.margin || 2; // 2mm padding

  for (let i = 0; i < dataArray.length; i++) {
    const data = dataArray[i];

    if (i > 0) {
      doc.addPage();
    }

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    // Calculate dimensions - text is now included in barcode image
    const barcodeHeight = Math.max(10, pageHeight - margin * 2);
    const barcodeWidth = Math.max(10, pageWidth - margin * 2);
    const barcodeX = margin;
    const barcodeY = margin;

    // Generate barcode with simple default options
    const barcodeOptions = {
      includeText: options?.includeText ?? true,
    };
    const barcodePng = generateBarcode(data, barcodeOptions);

    // Add barcode image (text is already included in the barcode)
    doc.addImage(barcodePng, "PNG", barcodeX, barcodeY, barcodeWidth, barcodeHeight);
  }

  return Buffer.from(doc.output("arraybuffer"));
}
