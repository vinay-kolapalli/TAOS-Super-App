import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function escapeCSVField(value: string | number | undefined): string {
  if (value === undefined) return '""';
  return `"${String(value).replace(/"/g, '""')}"`;
}
