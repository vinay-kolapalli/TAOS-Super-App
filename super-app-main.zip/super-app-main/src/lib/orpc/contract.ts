import { oc as orpcContract } from "@orpc/contract";
import z from "zod";

interface Meta {
  permission?: string[];
}

export const oc = orpcContract.$meta<Meta>({});

export function createOutputSchema<T extends z.ZodTypeAny>(
  dataType: T
): z.ZodObject<{
  message: z.ZodString;
  data: T;
}>;
export function createOutputSchema(): z.ZodObject<{
  message: z.ZodString;
  data: z.ZodOptional<z.ZodUndefined>;
}>;
export function createOutputSchema<T extends z.ZodTypeAny>(dataType?: T) {
  if (dataType) {
    return z.object({
      message: z.string(),
      data: dataType,
    });
  } else {
    return z.object({
      message: z.string(),
      data: z.undefined().optional(),
    });
  }
}
