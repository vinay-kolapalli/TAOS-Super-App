import { ORPCError, os } from "@orpc/server";
import { getSession } from "../auth";
import { parseError } from "../error";
import { logger } from "../logging/server";

interface AuthMiddlewareMeta {
  permission?: string[];
}

export const authMiddleware = os.$meta<AuthMiddlewareMeta>({}).middleware(async ({ next, procedure, path }) => {
  const rpcPath = path.join("/");
  const session = await getSession();
  if (!session) {
    throw new ORPCError("UNAUTHORIZED", {
      message: "Unauthorized",
    });
  }

  const metadata = procedure["~orpc"].meta;

  if (
    metadata?.permission &&
    metadata.permission.length > 0 &&
    session.user.role !== "admin" &&
    !metadata.permission.some((requiredPermission) => session.user.permissions?.includes(requiredPermission))
  ) {
    throw new ORPCError("FORBIDDEN", { message: "You are not authorized to perform this action" });
  }

  logger.info(`[ORPC][${rpcPath}] Auth`, {
    session: session.session,
    user: session.user,
  });

  const result = await next({
    context: {
      session: session.session,
      user: session.user,
    },
  });

  return result;
});

export const logMiddleware = os.$meta<AuthMiddlewareMeta>({}).middleware(async ({ next, procedure, path }, input) => {
  const rpcPath = path.join("/");
  try {
    logger.info(`[ORPC][${rpcPath}] Input`, {
      input,
      data: { metadata: procedure["~orpc"].meta },
    });

    const result = await next();

    logger.info(`[ORPC][${rpcPath}] Output`, {
      response: result.output,
    });

    return result;
  } catch (error) {
    logger.error(`[ORPC][${rpcPath}] Error`, {
      error,
      parsedError: parseError(error),
    });

    if (error instanceof Error && !(error instanceof ORPCError)) {
      throw new ORPCError("INTERNAL_SERVER_ERROR", { message: error.message });
    }

    throw error;
  }
});
