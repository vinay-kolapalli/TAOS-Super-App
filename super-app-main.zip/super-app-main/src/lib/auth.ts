import { Permission } from "@/data/permissions";
import { db } from "@/db";
import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { nextCookies } from "better-auth/next-js";
import { admin, magicLink } from "better-auth/plugins";
import { headers } from "next/headers";
import { logger } from "./logging/server";
import { sendMail } from "./mail";

export const auth = betterAuth({
  plugins: [
    nextCookies(),
    admin(),
    magicLink({
      disableSignUp: true,
      expiresIn: 10 * 60,
      sendMagicLink: async ({ email, url }) => {
        await sendMail({
          to: email,
          subject: `TAOS Super App - Login link`,
          text: `Click the following link to log in: ${url}`,
          html: `
              <div>
                <h1>Login to your account</h1>
                <p>Click the button below to log in:</p>
                <a href="${url}" style="display: inline-block; padding: 8px 40px; background-color: black; color: white; text-decoration: none; border-radius: 8px;">
                  Login
                </a>
                <p>If the button doesn't work, copy and paste this link into your browser:</p>
                <p>${url}</p>
                <p>This link will expire in 10 minutes.</p>
              </div>
            `,
        });
      },
    }),
  ],
  trustedOrigins: [
    process.env.BETTER_AUTH_URL,
    ...(process.env.VERCEL_URL ? [`https://${process.env.VERCEL_URL}`] : []),
  ],
  database: drizzleAdapter(db, {
    provider: "pg",
  }),
  advanced: {
    database: {
      generateId: false,
    },
  },
  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      disableSignUp: true,
    },
  },
  user: {
    modelName: "users",
    additionalFields: {
      permissions: {
        type: "string[]",
        required: true,
        defaultValue: [],
      },
      primaryWarehouse: {
        type: "number",
        required: true,
      },
      otherWarehouses: {
        type: "number[]",
        required: true,
        defaultValue: [],
      },
    },
  },
  session: {
    modelName: "sessions",
  },
  account: {
    modelName: "accounts",
  },
  verification: {
    modelName: "verifications",
  },
  logger: {
    disabled: false,
    level: "error",
    log: (level, message, ...args) => {
      logger[level](message, ...args);
    },
  },
});

export async function getSession() {
  const headerList = await headers();
  const session = await auth.api.getSession({
    headers: headerList,
  });
  return session;
}

export async function isUserAllowed(permission: Permission) {
  const session = await getSession();
  // If the user is not logged in, return false
  if (!session) {
    throw new Error("Unauthorized");
  }
  // If the user is an admin, return true
  if (session?.user.role === "admin") {
    return { isAllowed: true, session };
  }
  // If the user has the permission, return true
  if (session.user.permissions?.includes(permission)) {
    return { isAllowed: true, session };
  }
  // If the user does not have the permission, return false
  return { isAllowed: false, session };
}

export async function isUserAdmin() {
  const session = await getSession();
  return { isAllowed: session?.user.role === "admin", session };
}
