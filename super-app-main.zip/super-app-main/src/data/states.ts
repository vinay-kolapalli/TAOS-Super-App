export interface StateInfo {
  name: string;
  tin: string;
  stateCode: string;
}

export const statesByCode: Record<string, StateInfo> = {
  AP: { name: "Andhra Pradesh", tin: "37", stateCode: "AP" },
  AR: { name: "Arunachal Pradesh", tin: "12", stateCode: "AR" },
  AS: { name: "Assam", tin: "18", stateCode: "AS" },
  BR: { name: "Bihar", tin: "10", stateCode: "BR" },
  CG: { name: "Chattisgarh", tin: "22", stateCode: "CG" },
  DL: { name: "Delhi", tin: "07", stateCode: "DL" },
  GA: { name: "Goa", tin: "30", stateCode: "GA" },
  GJ: { name: "Gujarat", tin: "24", stateCode: "GJ" },
  HR: { name: "Haryana", tin: "06", stateCode: "HR" },
  HP: { name: "Himachal Pradesh", tin: "02", stateCode: "HP" },
  JK: { name: "Jammu and Kashmir", tin: "01", stateCode: "JK" },
  JH: { name: "Jharkhand", tin: "20", stateCode: "JH" },
  KA: { name: "Karnataka", tin: "29", stateCode: "KA" },
  KL: { name: "Kerala", tin: "32", stateCode: "KL" },
  LD: { name: "Lakshadweep Islands", tin: "31", stateCode: "LD" },
  MP: { name: "Madhya Pradesh", tin: "23", stateCode: "MP" },
  MH: { name: "Maharashtra", tin: "27", stateCode: "MH" },
  MN: { name: "Manipur", tin: "14", stateCode: "MN" },
  ML: { name: "Meghalaya", tin: "17", stateCode: "ML" },
  MZ: { name: "Mizoram", tin: "15", stateCode: "MZ" },
  NL: { name: "Nagaland", tin: "13", stateCode: "NL" },
  OD: { name: "Odisha", tin: "21", stateCode: "OD" },
  PY: { name: "Pondicherry", tin: "34", stateCode: "PY" },
  PB: { name: "Punjab", tin: "03", stateCode: "PB" },
  RJ: { name: "Rajasthan", tin: "08", stateCode: "RJ" },
  SK: { name: "Sikkim", tin: "11", stateCode: "SK" },
  TN: { name: "Tamil Nadu", tin: "33", stateCode: "TN" },
  TS: { name: "Telangana", tin: "36", stateCode: "TS" },
  TR: { name: "Tripura", tin: "16", stateCode: "TR" },
  UP: { name: "Uttar Pradesh", tin: "09", stateCode: "UP" },
  UK: { name: "Uttarakhand", tin: "05", stateCode: "UK" },
  WB: { name: "West Bengal", tin: "19", stateCode: "WB" },
  AN: { name: "Andaman and Nicobar Islands", tin: "35", stateCode: "AN" },
  CH: { name: "Chandigarh", tin: "04", stateCode: "CH" },
  DN: {
    name: "Dadra & Nagar Haveli and Daman & Diu",
    tin: "26",
    stateCode: "DN",
  },
  LA: { name: "Ladakh", tin: "38", stateCode: "LA" },
  OT: { name: "Other Territory", tin: "97", stateCode: "OT" },
};

export const statesList = Object.values(statesByCode);
