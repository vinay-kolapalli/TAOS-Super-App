import {
  IconCode,
  IconFile,
  IconFileSpreadsheet,
  IconFileText,
  IconFileZip,
  IconMusic,
  IconPhoto,
  IconVideo,
} from "@tabler/icons-react";

export const FILE_ICONS = {
  image: IconPhoto,
  document: IconFileText,
  spreadsheet: IconFileSpreadsheet,
  archive: IconFileZip,
  video: IconVideo,
  audio: IconMusic,
  code: IconCode,
  default: IconFile,
} as const;

export const FILE_EXTENSIONS = {
  image: ["jpg", "jpeg", "png", "gif", "webp", "svg"],
  pdf: ["pdf"],
  document: ["doc", "docx", "txt", "rtf"],
  spreadsheet: ["xls", "xlsx", "csv"],
  archive: ["zip", "rar", "7z", "tar", "gz"],
  video: ["mp4", "avi", "mov", "mkv", "webm"],
  audio: ["mp3", "wav", "flac", "ogg"],
  code: ["js", "ts", "jsx", "tsx", "html", "css", "json", "xml", "py", "java", "cpp", "c"],
};

export type FileType = keyof typeof FILE_ICONS;
