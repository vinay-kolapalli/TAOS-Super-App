export const orderFlowStatusOptions = [
  {
    label: "Plants picked",
    value: "plants_picked",
  },
  {
    label: "Others picked",
    value: "others_picked",
  },
  {
    label: "Reviewed",
    value: "reviewed",
  },
  {
    label: "Courier checked",
    value: "courier_checked",
  },
  {
    label: "Packed",
    value: "packed",
  },
];

export const orderFlowStatus = {
  plantsPicked: "plants_picked",
  othersPicked: "others_picked",
  reviewed: "reviewed",
  courierChecked: "courier_checked",
  packed: "packed",
};
