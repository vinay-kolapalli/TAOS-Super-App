import { SelectOption } from "@/types/general";

export const vendorUnits = ["pcs", "kg", "bags", "grams", "packets"] as const;
export type VendorUnit = (typeof vendorUnits)[number];

export const vendorUnitOptions: SelectOption<VendorUnit>[] = [
  {
    label: "Pcs",
    value: "pcs",
  },
  {
    label: "Kg",
    value: "kg",
  },
  {
    label: "Bags",
    value: "bags",
  },
  {
    label: "Grams",
    value: "grams",
  },
  {
    label: "Packets",
    value: "packets",
  },
];
