import { SelectOption } from "@/types/general";

export type Zones = "local" | "regional" | "metro" | "rest-of-india" | "north-east";
export const zones = ["local", "regional", "metro", "rest-of-india", "north-east"] as const;

export const zoneOptions: SelectOption<Zones>[] = [
  {
    value: "local",
    label: "Local",
  },
  {
    value: "regional",
    label: "Regional",
  },
  {
    value: "metro",
    label: "Metro",
  },
  {
    value: "rest-of-india",
    label: "Rest of India",
  },
  {
    value: "north-east",
    label: "North East",
  },
];

export const courierServices = ["surface", "air"] as const;
export type CourierServices = (typeof courierServices)[number];

export const courierServicesOptions: SelectOption<CourierServices>[] = [
  {
    label: "Surface",
    value: "surface",
  },
  {
    label: "Air",
    value: "air",
  },
];

export const weightTypes = ["dead_weight", "volumetric_weight"] as const;
export type WeightTypes = (typeof weightTypes)[number];

export const weightTypesOptions: SelectOption<WeightTypes>[] = [
  {
    label: "Dead Weight",
    value: "dead_weight",
  },
  {
    label: "Volumetric Weight",
    value: "volumetric_weight",
  },
];

export const courierServiceabilityCheck = ["pincode", "platform", "always_available"] as const;
export type CourierServiceabilityCheck = (typeof courierServiceabilityCheck)[number];

export const courierPlatforms = [
  "shipway",
  "shiprocket",
  "shiphere",
  "delhivery",
  "fship",
  "ithink-logistics",
  "amazon",
] as const;
export type CourierPlatforms = (typeof courierPlatforms)[number];

export const courierPlatformsOptions: SelectOption<CourierPlatforms>[] = [
  {
    label: "Shipway",
    value: "shipway",
  },
  {
    label: "Shiprocket",
    value: "shiprocket",
  },
  {
    label: "Shiphere",
    value: "shiphere",
  },
  {
    label: "Delhivery",
    value: "delhivery",
  },
  {
    label: "Fship",
    value: "fship",
  },
  {
    label: "iThinkLogistics",
    value: "ithink-logistics",
  },
  {
    label: "Amazon",
    value: "amazon",
  },
];

export const rateConditions = ["state", "city", "pincode", "weight", "box", "shipping_method", "warehouse"] as const;
export type RateConditions = (typeof rateConditions)[number];

export const rateConditionOperators = ["equals", "not_equals", "less_than", "greater_than"] as const;
export type RateConditionOperators = (typeof rateConditionOperators)[number];
