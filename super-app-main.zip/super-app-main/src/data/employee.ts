export interface Employee {
  name: string;
  id: number;
}

export const employeesArray: Employee[] = [
  { name: "Akshaya", id: 10001 },
  { name: "Anitha", id: 10002 },
  { name: "Annapurna", id: 10003 },
  { name: "Jashmine", id: 10006 },
  { name: "Krishnaveni", id: 10008 },
  { name: "Latha", id: 10010 },
  { name: "Latha 2", id: 10011 },
  { name: "Padma", id: 10014 },
  { name: "Preethi", id: 10015 },
  { name: "Pushpa", id: 10016 },
  { name: "Ratna", id: 10017 },
  { name: "Suneeta", id: 10022 },
  { name: "Tirupathi", id: 10023 },
  { name: "Fouziya", id: 10024 },
  { name: "Bhavani", id: 10025 },
  { name: "Mitesh", id: 10026 },
  { name: "Santosh", id: 10027 },
  { name: "Faraha", id: 10028 },
];

export const employees = new Map<number, Employee>(
  employeesArray.map((employee) => [employee.id, employee]),
);
