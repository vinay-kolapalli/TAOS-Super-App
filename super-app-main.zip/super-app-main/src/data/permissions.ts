export const permissionsList = {
  orders: {
    read: "orders:read",
    write: "orders:write",
  },
  orderFlow: {
    read: "order-flow:read",
    write: "order-flow:write",
  },
  orderPacking: {
    read: "order-packing:read",
    write: "order-packing:write",
  },
  orderPicking: {
    read: "order-picking:read",
    write: "order-picking:write",
  },
  reviewDesk: {
    read: "review-desk:read",
    write: "review-desk:write",
  },
  courierChecker: {
    read: "courier-checker:read",
    write: "courier-checker:write",
  },
  pincodes: {
    read: "pincodes:read",
    write: "pincodes:write",
  },
  zones: {
    read: "zones:read",
    write: "zones:write",
  },
  users: {
    read: "users:read",
    write: "users:write",
  },
  vendors: {
    read: "vendors:read",
    write: "vendors:write",
  },
  vendorInquiries: {
    read: "vendor-inquiries:read",
    write: "vendor-inquiries:write",
  },
  vendorReports: {
    read: "vendor-reports:read",
  },
  products: {
    read: "products:read",
    write: "products:write",
  },
  seedsBundlingRecords: {
    read: "record-seeds-bundling-records:read",
    write: "record-seeds-bundling-records:write",
  },
  damagedProductsRecords: {
    read: "damaged-products-records:read",
    write: "damaged-products-records:write",
  },
  recoveredProductsRecords: {
    read: "recovered-products-records:read",
    write: "recovered-products-records:write",
  },
  offlineSalesRecords: {
    read: "offline-sales-records:read",
    write: "offline-sales-records:write",
  },
  inboundInventoryRecords: {
    read: "inbound-inventory-records:read",
    write: "inbound-inventory-records:write",
  },
  warehouses: {
    read: "warehouses:read",
    write: "warehouses:write",
  },
  couriers: {
    read: "couriers:read",
    write: "couriers:write",
  },
  boxes: {
    read: "boxes:read",
    write: "boxes:write",
  },
  rates: {
    read: "rates:read",
    write: "rates:write",
  },
} as const;

export const permissions = Object.values(permissionsList).flatMap((group) => Object.values(group));
export type Permission = (typeof permissions)[number];

export const rolesList = {
  admin: "admin",
  user: "user",
} as const;

export const roles = [rolesList.admin, rolesList.user] as const;
export type Role = (typeof roles)[number];
