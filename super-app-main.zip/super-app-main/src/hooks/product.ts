import { orpc } from "@/lib/orpc/client";
import { useQuery } from "@tanstack/react-query";

export function useStoreProducts() {
  return useQuery({
    queryKey: ["products"],
    queryFn: async () => {
      const { data } = await orpc.store.products.list({});
      return data;
    },
  });
}

export function useProducts() {
  return useQuery({
    queryKey: ["super-app-products"],
    queryFn: async () => {
      const { data } = await orpc.products.list();
      return data;
    },
  });
}
