import { orpc } from "@/lib/orpc/client";
import { CourierServiceData } from "@/types/shipping";
import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";

interface Props {
  pincode: number | undefined;
}

export function useCourierService({ pincode }: Props) {
  const { data: zoneDetails, isFetching: isZoneDetailsLoading } = useQuery({
    queryKey: ["zone-details", pincode],
    queryFn: async () => {
      const { data } = await orpc.zones.check({ pincode: pincode! });
      return data;
    },
    enabled: !!pincode,
  });

  const { data: serviceableCouriers, isFetching: isServiceableCouriersLoading } = useQuery({
    queryKey: ["serviceable-couriers", pincode],
    queryFn: async () => {
      const { data } = await orpc.pincodes.serviceability.check({ pincode: pincode! });
      return data;
    },
    enabled: !!pincode,
  });

  const courierData = useMemo(() => findAvailableCouriers(), [serviceableCouriers, zoneDetails]);

  function findAvailableCouriers(): CourierServiceData[] {
    if (!serviceableCouriers || !zoneDetails) return [];
    const platformCouriers = serviceableCouriers.couriers.filter((courier) => courier.platform);
    const otherCouriers = serviceableCouriers.couriers.filter((courier) => !courier.platform);

    const platformCourierData = platformCouriers.map((courier) => ({
      ...courier,
      zone: zoneDetails.platforms.find((p) => p.id === courier.platform)?.zone,
    }));
    const otherCourierData = otherCouriers.map((courier) => ({
      ...courier,
      zone: zoneDetails.couriers.find((c) => c.id === courier.id)?.zone,
    }));

    const result = [...platformCourierData, ...otherCourierData];

    return result.filter((r) => r.zone) as CourierServiceData[];
  }

  return {
    isLoading: isServiceableCouriersLoading || isZoneDetailsLoading,
    courierData,
  };
}
