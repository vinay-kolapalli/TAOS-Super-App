import { orpc } from "@/lib/orpc/client";
import { useQuery } from "@tanstack/react-query";
import { useUser } from "./user";

export function useWarehouses() {
  return useQuery({
    queryKey: ["warehouses"],
    queryFn: async () => {
      const { data } = await orpc.warehouses.options({});
      return data;
    },
  });
}

export function useUserWarehouse() {
  const user = useUser();
  return useQuery({
    queryKey: ["warehouse"],
    queryFn: async () => {
      const { data } = await orpc.warehouses.options({ ids: [user.data?.primaryWarehouse!] });
      return data[0];
    },
    enabled: !!user.data?.primaryWarehouse,
  });
}

export function useUserWarehouses() {
  const user = useUser();
  return useQuery({
    queryKey: ["warehouse"],
    queryFn: async () => {
      const { data } = await orpc.warehouses.options({
        ids: [user.data?.primaryWarehouse!, ...(user.data?.otherWarehouses || [])],
      });
      return data;
    },
    enabled: !!user.data?.primaryWarehouse,
  });
}
