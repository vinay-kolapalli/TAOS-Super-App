import { orpc } from "@/lib/orpc/client";
import { useQuery } from "@tanstack/react-query";

export default function usePincodeReport(pincode?: number | null) {
  return useQuery({
    queryKey: ["pincode-report", pincode],
    queryFn: async () => {
      const { data } = await orpc.orders.shipments.report({
        pincode: pincode!,
      });
      return data;
    },
    enabled: !!pincode,
    throwOnError: false,
  });
}
