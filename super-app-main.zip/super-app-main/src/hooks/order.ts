import { orpc } from "@/lib/orpc/client";
import { fetchOrders, FetchOrdersProps } from "@/utils/orders";
import { useQuery } from "@tanstack/react-query";

export function useOrders({ enabled = true, ...props }: FetchOrdersProps) {
  return useQuery({
    queryKey: [
      "fetch-orders",
      props.after,
      props.before,
      props.perPage,
      props.status,
      props.include,
      props.fetchAllPages,
      props.search,
      props.sort,
      props.sortBy,
      props.warehouses,
    ],
    queryFn: async () => {
      const data = await fetchOrders(props);
      return data;
    },
    enabled,
    gcTime: 0,
  });
}

export function useOrdersCount({ warehouses, enabled = true }: { warehouses?: number[] | null; enabled?: boolean }) {
  return useQuery({
    queryKey: ["fetch-orders-count", warehouses],
    queryFn: async () => {
      const data = await orpc.store.orders.count({ warehouses: warehouses ?? undefined });
      return data.data;
    },
    enabled,
    gcTime: 0,
  });
}
