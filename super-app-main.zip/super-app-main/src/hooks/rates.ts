"use client";
import { orpc } from "@/lib/orpc/client";
import { CalculateRateInputSchema } from "@/router/rates/calculate/schema";
import { useQuery } from "@tanstack/react-query";
import { useDebounce } from "@uidotdev/usehooks";

export function useRateCalculation(request: Partial<CalculateRateInputSchema>) {
  const debouncedValues = useDebounce(request, 500);
  const hasRequiredData = Boolean(
    debouncedValues.pincode &&
      debouncedValues.weight &&
      debouncedValues.box &&
      debouncedValues.couriers?.length &&
      debouncedValues.state &&
      debouncedValues.city &&
      debouncedValues.shippingMethod
  );

  return useQuery({
    queryKey: ["calculate-rates", debouncedValues],
    queryFn: async () => {
      const { data } = await orpc.rates.calculate(debouncedValues as CalculateRateInputSchema);
      return data ?? [];
    },
    enabled: hasRequiredData,
    gcTime: 0,
  });
}
