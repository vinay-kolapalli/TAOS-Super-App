import { User } from "@/db/types";
import { authClient } from "@/lib/auth.client";
import { useQuery } from "@tanstack/react-query";

export function useUser() {
  return useQuery({
    queryKey: ["user"],
    queryFn: async () => {
      const response = await authClient.getSession();
      if (!response?.data?.user) {
        throw new Error("Unauthorized");
      }
      return response.data.user as User;
    },
  });
}
