import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { upsertCourierInputSchema, upsertCourierOutputSchema } from "./schema";

const upsertCourier = oc
  .meta({ permission: [permissionsList.couriers.write] })
  .input(upsertCourierInputSchema)
  .output(upsertCourierOutputSchema);

export const contract = {
  create: upsertCourier,
  update: upsertCourier,
};
