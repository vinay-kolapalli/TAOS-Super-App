import { courierServiceabilityCheck, courierServices } from "@/data/shipping";
import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export const upsertCourierInputSchema = z
  .object({
    id: z
      .string()
      .min(1, "Courier ID is required")
      .regex(/^[a-z0-9-]+$/, "Only lowercase letters, numbers, and hyphens allowed"),
    name: z.string().min(1, "Courier name is required"),
    image: z.string().min(1, "Courier logo is required"),
    isActive: z.boolean(),
    services: z.array(z.enum(courierServices)).min(1, "At least one service is required"),
    serviceabilityCheck: z.array(z.enum(courierServiceabilityCheck)),
  })
  .superRefine((data, ctx) => {
    if (data.serviceabilityCheck.includes("always_available") && data.serviceabilityCheck.includes("pincode")) {
      ctx.addIssue({
        code: "custom",
        message: "Cannot select both 'always available' and 'pincode' options together",
        path: ["serviceabilityCheck"],
      });
    }
  });
export type UpsertCourierInputSchema = z.infer<typeof upsertCourierInputSchema>;

export const upsertCourierOutputSchema = createOutputSchema();
export type UpsertCourierOutputSchema = z.infer<typeof upsertCourierOutputSchema>;
