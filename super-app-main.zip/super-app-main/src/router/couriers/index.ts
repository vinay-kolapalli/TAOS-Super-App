import { db } from "@/db";
import { couriers } from "@/db/schema/shipping";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { implement, ORPCError } from "@orpc/server";
import { eq } from "drizzle-orm";
import { contract } from "./contract";

const os = implement(contract);

const createCourier = os.create.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(db.insert(couriers).values(input));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to create courier" }),
    });
  }
  return { message: "Courier created" };
});

const updateCourier = os.update.use(authMiddleware).handler(async ({ input }) => {
  const { id, ...rest } = input;

  const { error } = await tryCatch(db.update(couriers).set(rest).where(eq(couriers.id, id)));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to update courier" }),
    });
  }

  return { message: "Courier updated" };
});

export const router = {
  create: createCourier,
  update: updateCourier,
};
