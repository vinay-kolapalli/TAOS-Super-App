import { logMiddleware } from "@/lib/orpc/middleware";
import { os } from "@orpc/server";
import * as boxes from "./boxes";
import * as cache from "./cache";
import * as couriers from "./couriers";
import * as files from "./files";
import * as orders from "./orders";
import * as pincodes from "./pincodes";
import * as products from "./products";
import * as rates from "./rates";
import * as records from "./records";
import * as shipping from "./shipping";
import * as store from "./store";
import * as users from "./users";
import * as vendors from "./vendors";
import * as warehouses from "./warehouses";
import * as zones from "./zones";

export const router = os.use(logMiddleware).router({
  boxes: boxes.router,
  products: products.router,
  zones: zones.router,
  shipping: shipping.router,
  warehouses: warehouses.router,
  vendors: vendors.router,
  records: records.router,
  users: users.router,
  orders: orders.router,
  rates: rates.router,
  pincodes: pincodes.router,
  couriers: couriers.router,
  files: files.router,
  cache: cache.router,
  store: store.router,
});
