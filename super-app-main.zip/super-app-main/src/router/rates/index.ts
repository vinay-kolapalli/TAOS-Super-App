import { db } from "@/db";
import { rateConditions, rates, rateSlabs } from "@/db/schema/rates";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { implement, ORPCError } from "@orpc/server";
import { eq } from "drizzle-orm";
import * as calculateRateRouter from "./calculate";
import { contract } from "./contract";

const os = implement(contract);

const updateRate = os.update.use(authMiddleware).handler(async ({ input }) => {
  const slabsToInsert = input.slabs.map((slab) => ({
    rate: input.rateId,
    slabName: slab.slabName,
    isActive: slab.isActive,
    platformId: slab.platformId,
    minWeight: slab.minWeight,
    maxWeight: slab.maxWeight,
    additionalUnit: slab.additionalUnit,
    additionalMaxWeight: slab.additionalMaxWeight,
    localBaseRate: slab.localBaseRate,
    localAdditionalRate: slab.localAdditionalRate,
    regionalBaseRate: slab.regionalBaseRate,
    regionalAdditionalRate: slab.regionalAdditionalRate,
    metroBaseRate: slab.metroBaseRate,
    metroAdditionalRate: slab.metroAdditionalRate,
    restOfIndiaBaseRate: slab.restOfIndiaBaseRate,
    restOfIndiaAdditionalRate: slab.restOfIndiaAdditionalRate,
    northEastBaseRate: slab.northEastBaseRate,
    northEastAdditionalRate: slab.northEastAdditionalRate,
  }));

  const { error } = await tryCatch(
    db.transaction(async (tx) => {
      // 1. Update the rate configuration
      await tx
        .update(rates)
        .set({
          courier: input.rate.courier,
          service: input.rate.service,
          displayName: input.rate.displayName,
          description: input.rate.description,
          platform: input.rate.platform === "none" ? null : input.rate.platform,
          weightType: input.rate.weightType,
          isActive: input.rate.isActive,
          updatedAt: new Date(),
        })
        .where(eq(rates.id, input.rateId));

      // 2. Update rate slabs
      // Delete existing slabs
      await tx.delete(rateSlabs).where(eq(rateSlabs.rate, input.rateId));

      // Insert new/updated slabs
      if (input.slabs.length > 0) {
        await tx.insert(rateSlabs).values(slabsToInsert);
      }

      // 3. Update rate conditions
      // Delete existing conditions
      await tx.delete(rateConditions).where(eq(rateConditions.rate, input.rateId));

      // Insert new/updated conditions
      if (input.conditions.length > 0) {
        const conditionsToInsert = input.conditions.map((condition) => ({
          rate: input.rateId,
          name: condition.name,
          values: condition.values,
          operator: condition.operator as any,
          type: condition.type as any,
        }));

        await tx.insert(rateConditions).values(conditionsToInsert);
      }
    })
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to update rate" }),
    });
  }

  return { message: "Rate updated" };
});

const deleteRate = os.delete.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(db.delete(rates).where(eq(rates.id, input.id)));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to delete rate" }),
    });
  }

  return { message: "Rate deleted" };
});

export const router = {
  update: updateRate,
  delete: deleteRate,
  calculate: calculateRateRouter.router.calculate,
};
