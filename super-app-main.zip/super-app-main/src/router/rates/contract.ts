import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { deleteRateInputSchema, deleteRateOutputSchema, updateRateInputSchema, updateRateOutputSchema } from "./schema";

const updateRate = oc
  .meta({
    permission: [permissionsList.rates.write],
  })
  .input(updateRateInputSchema)
  .output(updateRateOutputSchema);

const deleteRate = oc
  .meta({
    permission: [permissionsList.rates.write],
  })
  .input(deleteRateInputSchema)
  .output(deleteRateOutputSchema);

export const contract = {
  update: updateRate,
  delete: deleteRate,
};
