import { courierPlatforms, courierServices, weightTypes } from "@/data/shipping";
import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export const updateRateInputSchema = z.object({
  rateId: z.string(),
  rate: z.object({
    courier: z.string().min(1, "Courier is required"),
    service: z.enum(courierServices),
    displayName: z.string().min(1, "Display name is required"),
    description: z.string(),
    weightType: z.enum(weightTypes),
    isActive: z.boolean(),
    platform: z
      .enum([...courierPlatforms, "none"])
      .nullable()
      .optional(),
  }),
  slabs: z.array(
    z.object({
      id: z.string(),
      slabName: z.string(),
      isActive: z.boolean(),
      platformId: z.string().nullable().optional(),
      minWeight: z.number(),
      maxWeight: z.number(),
      additionalUnit: z.number(),
      additionalMaxWeight: z.number(),
      localBaseRate: z.number(),
      localAdditionalRate: z.number(),
      regionalBaseRate: z.number(),
      regionalAdditionalRate: z.number(),
      metroBaseRate: z.number(),
      metroAdditionalRate: z.number(),
      restOfIndiaBaseRate: z.number(),
      restOfIndiaAdditionalRate: z.number(),
      northEastBaseRate: z.number(),
      northEastAdditionalRate: z.number(),
    })
  ),
  conditions: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      values: z.array(z.string()),
      operator: z.string(),
      type: z.string(),
    })
  ),
});
export type UpdateRateInputSchema = z.infer<typeof updateRateInputSchema>;

export const updateRateOutputSchema = createOutputSchema();
export type UpdateRateOutputSchema = z.infer<typeof updateRateOutputSchema>;

export const deleteRateInputSchema = z.object({
  id: z.string(),
});
export type DeleteRateInputSchema = z.infer<typeof deleteRateInputSchema>;

export const deleteRateOutputSchema = createOutputSchema();
export type DeleteRateOutputSchema = z.infer<typeof deleteRateOutputSchema>;
