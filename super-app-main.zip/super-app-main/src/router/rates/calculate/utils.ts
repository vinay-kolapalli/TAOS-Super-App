import { db } from "@/db";
import { Rate, RateCondition, RateSlab } from "@/db/types";
import { logger } from "@/lib/logging/server";
import Fuse from "fuse.js";
import { CalculateRateInputSchema, CalculateRateOutputSchema } from "./schema";

type OutputSchema = CalculateRateOutputSchema["data"];

interface RateCalculationContext {
  state: string;
  city: string;
  warehouse: number;
  box: string;
  shippingMethod: string;
  pincode: number;
  weight: number;
  volumetricWeight: number;
}

type Courier = CalculateRateInputSchema["couriers"][number];

export function getLowestRatesOnly(rates: OutputSchema): OutputSchema {
  // Group rates by courier + platform + platformId combination
  const rateGroups = new Map<string, OutputSchema>();

  for (const rate of rates) {
    const groupKey = `${rate.courier.id}|${rate.courier.platform || ""}`;

    if (!rateGroups.has(groupKey)) {
      rateGroups.set(groupKey, []);
    }
    rateGroups.get(groupKey)!.push(rate);
  }

  // For each group, keep only the rate with the lowest cost
  const lowestRates: OutputSchema = [];

  for (const [groupKey, groupRates] of rateGroups.entries()) {
    const lowestRate = groupRates.reduce((min, current) => (current.rate < min.rate ? current : min));
    lowestRates.push(lowestRate);
  }

  return lowestRates;
}

export async function calculateRatesForCouriers({
  requestedCouriers,
  context,
}: {
  requestedCouriers: Courier[];
  context: RateCalculationContext;
}) {
  const courierIds = requestedCouriers.map((courier) => courier.id);

  // Get all rate configurations for requested couriers
  const configurations = await db.query.rates.findMany({
    where: (fields, operators) =>
      operators.and(operators.eq(fields.isActive, true), operators.inArray(fields.courier, courierIds)),
    limit: 2000,
  });

  if (configurations.length === 0) {
    return [];
  }

  // Batch fetch all conditions and slabs for relevant configurations
  const configIds = configurations.map((config) => config.id);
  const [allConditions, allSlabs] = await Promise.all([
    db.query.rateConditions.findMany({
      where: (fields, operators) => operators.inArray(fields.rate, configIds),
      limit: 2000,
    }),
    db.query.rateSlabs.findMany({
      where: (fields, operators) =>
        operators.and(operators.inArray(fields.rate, configIds), operators.eq(fields.isActive, true)),
      orderBy: (fields, operators) => [operators.asc(fields.minWeight)],
      limit: 2000,
    }),
  ]);

  logger.info("calculateRatesForCouriers", { data: { configurations, allConditions, allSlabs } });

  // Group conditions and slabs by rate configuration ID
  const conditionsByConfig = new Map<string, RateCondition[]>();
  const slabsByConfig = new Map<string, RateSlab[]>();

  allConditions.forEach((condition) => {
    if (!conditionsByConfig.has(condition.rate)) {
      conditionsByConfig.set(condition.rate, []);
    }
    conditionsByConfig.get(condition.rate)!.push(condition);
  });

  allSlabs.forEach((slab) => {
    if (!slabsByConfig.has(slab.rate)) {
      slabsByConfig.set(slab.rate, []);
    }
    slabsByConfig.get(slab.rate)!.push(slab);
  });

  const calculatedRates: OutputSchema = [];
  const processedCombinations = new Set<string>();

  // Process configurations concurrently
  const configPromises = configurations.map(async (config) => {
    const configConditions = conditionsByConfig.get(config.id) || [];
    const configSlabs = slabsByConfig.get(config.id) || [];

    return processRateConfiguration({
      config,
      requestedCouriers,
      context,
      processedCombinations,
      conditions: configConditions,
      slabs: configSlabs,
    });
  });

  const configResults = await Promise.all(configPromises);

  for (const configRates of configResults) {
    calculatedRates.push(...configRates);
  }

  return calculatedRates;
}

export async function processRateConfiguration({
  config,
  requestedCouriers,
  context,
  processedCombinations,
  conditions,
  slabs,
}: {
  config: Rate;
  requestedCouriers: Courier[];
  context: RateCalculationContext;
  processedCombinations: Set<string>;
  conditions: RateCondition[];
  slabs: RateSlab[];
}) {
  // Find ALL matching couriers from the request
  const matchingCouriers = requestedCouriers.filter((c) => c.id === config.courier);
  if (matchingCouriers.length === 0) return [];

  // Check if configuration conditions are met
  const conditionsMet = await evaluateConditions(conditions, context);
  if (!conditionsMet) return [];

  const rates: OutputSchema = [];

  // Process each matching courier separately
  for (const requestedCourier of matchingCouriers) {
    const courierRate = processCourierRate({
      config,
      requestedCourier,
      slabs,
      context,
      processedCombinations,
    });

    if (courierRate) {
      rates.push(courierRate);
    }
  }

  return rates;
}

export function processCourierRate({
  config,
  requestedCourier,
  slabs,
  context,
  processedCombinations,
}: {
  config: Rate;
  requestedCourier: Courier;
  slabs: RateSlab[];
  context: RateCalculationContext;
  processedCombinations: Set<string>;
}): OutputSchema[number] | null {
  // Check if the platform matches (if specified)
  if (requestedCourier.platform && config.platform !== requestedCourier.platform) {
    return null;
  }

  // Check if the service type matches the requested courier's service
  if (config.service !== requestedCourier.service) {
    return null;
  }

  // Determine which weight to use based on the rate configuration's weight type
  const weightToUse =
    config.weightType === "volumetric_weight" ? Math.max(context.weight, context.volumetricWeight) : context.weight;

  // Find the appropriate slab for the weight and platform
  const applicableSlab = findApplicableSlab(slabs, weightToUse, requestedCourier.platformId);
  if (!applicableSlab) return null;

  // Check for duplicate combinations
  const uniqueKey = `${config.id}|${config.platform || ""}|${applicableSlab.platformId || ""}|${requestedCourier.zone}`;

  if (processedCombinations.has(uniqueKey)) {
    return null;
  }

  processedCombinations.add(uniqueKey);

  // Calculate the rate
  const calculatedRate = calculateSlabRate(applicableSlab, weightToUse, requestedCourier.zone);

  return {
    id: config.id,
    displayName: config.displayName,
    slab: applicableSlab.slabName,
    rate: calculatedRate.totalRate,
    zone: requestedCourier.zone,
    courier: {
      id: requestedCourier.id,
      name: requestedCourier.name,
      service: config.service,
      platform: config.platform || undefined,
      platformId: applicableSlab.platformId || undefined,
    },
    breakdown: {
      baseRate: calculatedRate.baseRate,
      additionalCharges: calculatedRate.additionalCharges,
      totalWeight: weightToUse,
      slabMatched: applicableSlab.slabName,
    },
  };
}

export async function evaluateConditions(
  conditions: RateCondition[],
  context: RateCalculationContext
): Promise<boolean> {
  if (conditions.length === 0) return true; // No conditions = applies to all

  for (const condition of conditions) {
    const { type, values, operator } = condition;

    if (!Array.isArray(values) || values.length === 0) continue;

    let conditionMet = false;

    switch (type) {
      case "state":
        conditionMet = evaluateConditionWithOperator(context.state, values, operator);
        break;
      case "city":
        conditionMet = evaluateConditionWithOperator(context.city, values, operator);
        break;
      case "warehouse":
        conditionMet = evaluateConditionWithOperator(String(context.warehouse), values, operator);
        break;
      case "box":
        conditionMet = evaluateConditionWithOperator(context.box, values, operator);
        break;
      case "shipping_method":
        conditionMet = evaluateConditionWithOperator(context.shippingMethod, values, operator);
        break;
      case "pincode":
        conditionMet = evaluateConditionWithOperator(String(context.pincode), values, operator);
        break;
      case "weight":
        conditionMet = evaluateConditionWithOperator(String(context.weight), values, operator);
        break;
      default:
        conditionMet = true; // Unknown condition type, assume it passes
    }

    if (!conditionMet) return false;
  }

  return true;
}

export function evaluateConditionWithOperator(
  value: string | number,
  conditionValues: string[],
  operator: string
): boolean {
  const stringValue = value.toString().toLowerCase(); // Convert to lowercase for case-insensitive comparison
  const lowerCaseConditionValues = conditionValues.map((cv) => cv.toLowerCase()); // Convert condition values to lowercase

  switch (operator) {
    case "equals":
      return lowerCaseConditionValues.includes(stringValue);
    case "not_equals":
      return !lowerCaseConditionValues.includes(stringValue);
    case "less_than":
      const ltValue = parseFloat(stringValue);
      return conditionValues.some((cv) => ltValue < parseFloat(cv));
    case "greater_than":
      const gtValue = parseFloat(stringValue);
      return conditionValues.some((cv) => gtValue > parseFloat(cv));
    default:
      return true; // Unknown operator, assume it passes
  }
}

export function findApplicableSlab(slabs: RateSlab[], weight: number, platformId?: string): RateSlab | null {
  // Sort slabs by minWeight to ensure we check them in the correct order
  const sortedSlabs = [...slabs].sort((a, b) => a.minWeight - b.minWeight);

  // Find the exact slab that the weight falls into - strict matching only
  for (const slab of sortedSlabs) {
    // Check platformId match - allow slabs without platformId if platform matches
    if (platformId && slab.platformId && slab.platformId !== platformId) {
      continue;
    }

    // If weight is within the slab range (minWeight <= weight <= maxWeight)
    // Handle case where maxWeight is 0 (meaning unlimited) by treating it as Infinity
    const effectiveMaxWeight = slab.maxWeight === 0 ? Infinity : slab.maxWeight;

    // For slabs with additionalUnit > 0, they can handle weights beyond maxWeight
    // but only up to the additionalMaxWeight absolute limit
    const canExtendBeyondMax = slab.additionalUnit > 0;
    const maxAllowedWeight = canExtendBeyondMax ? slab.additionalMaxWeight : effectiveMaxWeight;
    const weightInRange =
      weight >= slab.minWeight &&
      (weight <= effectiveMaxWeight || (canExtendBeyondMax && weight > slab.maxWeight && weight <= maxAllowedWeight));

    if (weightInRange) {
      return slab;
    }
  }

  // No applicable slab found - return null to exclude this rate configuration
  return null;
}

export function getZoneRates(slab: RateSlab, zone: string): { baseRate: number; additionalRate: number } {
  switch (zone) {
    case "local":
      return { baseRate: slab.localBaseRate, additionalRate: slab.localAdditionalRate };
    case "regional":
      return { baseRate: slab.regionalBaseRate, additionalRate: slab.regionalAdditionalRate };
    case "metro":
      return { baseRate: slab.metroBaseRate, additionalRate: slab.metroAdditionalRate };
    case "rest-of-india":
      return { baseRate: slab.restOfIndiaBaseRate, additionalRate: slab.restOfIndiaAdditionalRate };
    case "north-east":
      return { baseRate: slab.northEastBaseRate, additionalRate: slab.northEastAdditionalRate };
    default:
      logger.warn(`Unknown zone: ${zone}, defaulting to rest-of-india rates`);
      return { baseRate: slab.restOfIndiaBaseRate, additionalRate: slab.restOfIndiaAdditionalRate };
  }
}

export function calculateSlabRate(slab: RateSlab, weight: number, zone: string) {
  // Get zone-specific rates from the slab
  const { baseRate, additionalRate } = getZoneRates(slab, zone);

  // Validate inputs
  if (baseRate === 0 || isNaN(baseRate) || weight < 0 || isNaN(weight)) {
    return {
      baseRate: 0,
      additionalCharges: 0,
      totalRate: 0,
    };
  }

  let additionalCharges = 0;

  // Calculate additional charges based on slab configuration
  // For "Upto X" slabs, typically the base rate covers the full range, additional charges shouldn't apply
  // unless specifically configured differently
  if (slab.additionalUnit > 0 && weight > slab.maxWeight && additionalRate > 0) {
    // Weight exceeds base capacity - calculate additional charges
    const excessWeight = weight - slab.maxWeight;
    const additionalUnits = Math.ceil(excessWeight / slab.additionalUnit);
    additionalCharges = additionalUnits * additionalRate;
  }

  const totalRate = baseRate + additionalCharges;

  return {
    baseRate,
    additionalCharges,
    totalRate,
  };
}

export function customRateSort(a: OutputSchema[number], b: OutputSchema[number]): number {
  const aIsIndiaPost = isIndiaPost(a.courier.id);
  const bIsIndiaPost = isIndiaPost(b.courier.id);

  // India Post always goes to bottom
  if (aIsIndiaPost && !bIsIndiaPost) return 1;
  if (!aIsIndiaPost && bIsIndiaPost) return -1;

  // Sort by rate (low to high)
  return a.rate - b.rate;
}

const indiaPostFuse = new Fuse(["india post"], { threshold: 0.3 });

export function isIndiaPost(courierId: string): boolean {
  return indiaPostFuse.search(courierId).length > 0;
}
