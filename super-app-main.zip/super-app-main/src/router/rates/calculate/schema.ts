import { CourierPlatforms, CourierServices, Zones } from "@/data/shipping";
import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export const calculateRateInputSchema = z.object({
  pincode: z.number(),
  weight: z.number(),
  box: z.string(),
  couriers: z
    .array(
      z.object({
        id: z.string(),
        name: z.string(),
        platform: z.string().optional(),
        platformId: z.string().optional(),
        service: z.string() as z.ZodType<CourierServices>,
        zone: z.string() as z.ZodType<Zones>,
      })
    )
    .min(1),
  state: z.string(),
  city: z.string(),
  shippingMethod: z.string(),
});
export type CalculateRateInputSchema = z.infer<typeof calculateRateInputSchema>;

export const calculateRateOutputSchema = createOutputSchema(
  z.array(
    z.object({
      id: z.string(),
      key: z.string().optional(),
      displayName: z.string(),
      slab: z.string(),
      rate: z.number(),
      zone: z.string() as z.ZodType<Zones>,
      courier: z.object({
        id: z.string(),
        name: z.string(),
        service: z.string() as z.ZodType<CourierServices>,
        platform: z.string().optional() as z.ZodType<CourierPlatforms | undefined>,
        platformId: z.string().optional(),
      }),
      breakdown: z.object({
        baseRate: z.number(),
        additionalCharges: z.number(),
        totalWeight: z.number(),
        slabMatched: z.string(),
      }),
    })
  )
);
export type CalculateRateOutputSchema = z.infer<typeof calculateRateOutputSchema>;
