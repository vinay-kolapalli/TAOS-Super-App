import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { calculateRateInputSchema, calculateRateOutputSchema } from "./schema";

const calculateRate = oc
  .meta({
    permission: [permissionsList.rates.read, permissionsList.courierChecker.read],
  })
  .input(calculateRateInputSchema)
  .output(calculateRateOutputSchema);

export const contract = {
  calculate: calculateRate,
};
