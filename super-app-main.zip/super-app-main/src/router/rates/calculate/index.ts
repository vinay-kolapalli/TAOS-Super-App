import { db } from "@/db";
import { logger } from "@/lib/logging/server";
import { authMiddleware } from "@/lib/orpc/middleware";
import { implement, ORPCError } from "@orpc/server";
import { nanoid } from "nanoid";
import { contract } from "./contract";
import { calculateRatesForCouriers, customRateSort, getLowestRatesOnly } from "./utils";

const os = implement(contract);

const calculateRate = os.calculate.use(authMiddleware).handler(async ({ input, context }) => {
  const { pincode, weight, box, couriers: requestedCouriers, state, city, shippingMethod } = input;

  const [warehouse, boxData] = await Promise.all([
    db.query.warehouses.findFirst({
      columns: { id: true, availableCouriers: true, availablePlatforms: true },
      where: (fields, operators) => operators.eq(fields.id, context.user.primaryWarehouse),
    }),
    db.query.boxes.findFirst({
      columns: { volumetricWeight: true },
      where: (fields, operators) => operators.eq(fields.id, box),
    }),
  ]);

  if (!boxData || !warehouse) {
    logger.error("Failed to fetch warehouse or box", {
      data: { box: boxData, warehouse },
    });
    throw new ORPCError("BAD_REQUEST", { message: "Invalid warehouse or box selection" });
  }

  logger.info("Warehouse and box data", {
    data: { box: boxData, warehouse },
  });

  const allCalculatedRates = await calculateRatesForCouriers({
    requestedCouriers,
    context: {
      state,
      city,
      warehouse: warehouse.id,
      box,
      shippingMethod,
      pincode,
      weight,
      volumetricWeight: boxData.volumetricWeight,
    },
  });
  logger.info("Calculated rates", {
    data: allCalculatedRates,
  });

  // Keep only the lowest rate for each courier/platform combination
  const lowestRates = getLowestRatesOnly(allCalculatedRates);

  // Add nanoid keys for React rendering and sort rates
  // Create sets for faster lookups
  const availableCourierSet = new Set(warehouse.availableCouriers);
  const availablePlatformSet = new Set(warehouse.availablePlatforms);

  const finalRates = lowestRates
    .filter((rate) => availableCourierSet.has(rate.courier.id))
    .filter((rate) => (rate.courier.platform ? availablePlatformSet.has(rate.courier.platform) : true))
    .map((rate) => ({ ...rate, key: nanoid() }))
    .sort(customRateSort);

  return { message: "Rates calculated", data: finalRates };
});

export const router = {
  calculate: calculateRate,
};
