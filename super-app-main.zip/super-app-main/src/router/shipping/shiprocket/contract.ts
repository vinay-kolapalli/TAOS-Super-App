import { createShiprocketOrderPayloadSchema } from "@/schema/shipping/shiprocket";
import z from "zod";
import { shipOrder } from "../contract";

export const shipShiprocketOrder = shipOrder.input(
  createShiprocketOrderPayloadSchema.extend({
    courierId: z.number(),
  })
);

export const contract = {
  ship: shipShiprocketOrder,
};
