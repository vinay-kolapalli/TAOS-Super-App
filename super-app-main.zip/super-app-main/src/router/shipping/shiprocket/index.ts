import { getWarehouse } from "@/db/utils/warehouse";
import { authMiddleware } from "@/lib/orpc/middleware";
import { assignAWBToOrder, createShiprocketOrder, generateLabel } from "@/lib/shipping/shiprocket";
import { implement } from "@orpc/server";
import { contract } from "./contract";

const os = implement(contract);

const shipShiprocketOrder = os.ship.use(authMiddleware).handler(async ({ input, context, errors }) => {
  const warehouse = await getWarehouse(context.user.primaryWarehouse);
  if (!warehouse.metadata.shiprocketWarehouseId) {
    throw errors.WAREHOUSE_ID_NOT_FOUND();
  }

  if (!warehouse.availablePlatforms.includes("shiprocket")) {
    throw errors.PLATFORM_NOT_ENABLED();
  }

  const orderResponse = await createShiprocketOrder({
    ...input,
    pickup_location: warehouse.metadata.shiprocketWarehouseId,
  });
  const awbResponse = await assignAWBToOrder(orderResponse.shipment_id, input.courierId);
  const labelResponse = await generateLabel([orderResponse.shipment_id]);

  return {
    message: "Order shipped",
    data: {
      trackingNumber: awbResponse.response.data.awb_code,
      shippingLabel: labelResponse.label_url,
    },
  };
});

export const router = {
  ship: shipShiprocketOrder,
};
