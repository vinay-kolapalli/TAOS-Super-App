import * as amazon from "./amazon";
import * as delhivery from "./delhivery";
import * as fship from "./fship";
import * as iThinkLogistics from "./ithink-logistics";
import * as shiphere from "./shiphere";
import * as shiprocket from "./shiprocket";
import * as shipway from "./shipway";

export const router = {
  amazon: amazon.router,
  delhivery: delhivery.router,
  fship: fship.router,
  iThinkLogistics: iThinkLogistics.router,
  shiphere: shiphere.router,
  shiprocket: shiprocket.router,
  shipway: shipway.router,
};
