import { createFshipOrderPayloadSchema } from "@/schema/shipping/fship";
import { shipOrder } from "../contract";

export const shipFshipOrder = shipOrder.input(createFshipOrderPayloadSchema);

export const contract = {
  ship: shipFshipOrder,
};
