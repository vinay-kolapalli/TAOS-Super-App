import { getWarehouse } from "@/db/utils/warehouse";
import { authMiddleware } from "@/lib/orpc/middleware";
import { createFshipOrder, registerFshipPickup } from "@/lib/shipping/fship";
import { implement } from "@orpc/server";
import { contract } from "./contract";

const os = implement(contract);

const shipFshipOrder = os.ship.use(authMiddleware).handler(async ({ input, context, errors }) => {
  const warehouse = await getWarehouse(context.user.primaryWarehouse);
  if (!warehouse.metadata.fshipWarehouseId) {
    throw errors.WAREHOUSE_ID_NOT_FOUND();
  }

  if (!warehouse.availablePlatforms.includes("fship")) {
    throw errors.PLATFORM_NOT_ENABLED();
  }

  const orderResponse = await createFshipOrder({
    ...input,
    pick_Address_ID: Number(warehouse.metadata.fshipWarehouseId),
  });

  await registerFshipPickup(orderResponse.waybill);

  return {
    message: "Order shipped",
    data: {
      trackingNumber: orderResponse.waybill,
      shippingLabel: orderResponse.labelurl,
    },
  };
});

export const router = {
  ship: shipFshipOrder,
};
