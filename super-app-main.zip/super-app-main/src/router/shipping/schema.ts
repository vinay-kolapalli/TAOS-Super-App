import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export const shipOrderOutputSchema = createOutputSchema(
  z.object({
    trackingNumber: z.string().min(1, { error: "Invalid tracking number" }),
    shippingLabel: z.string().min(1, { error: "Invalid shipping label" }),
  })
);
