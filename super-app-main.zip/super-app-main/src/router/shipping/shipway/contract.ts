import { createShipwayOrderPayloadSchema } from "@/schema/shipping/shipway";
import { shipOrder } from "../contract";

export const shipShipwayOrder = shipOrder.input(createShipwayOrderPayloadSchema);

export const contract = {
  ship: shipShipwayOrder,
};
