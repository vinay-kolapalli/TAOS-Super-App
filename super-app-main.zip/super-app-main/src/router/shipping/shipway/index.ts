import { getWarehouse } from "@/db/utils/warehouse";
import { authMiddleware } from "@/lib/orpc/middleware";
import { createShipwayOrder } from "@/lib/shipping/shipway";
import { implement } from "@orpc/server";
import { contract } from "./contract";

const os = implement(contract);

const shipShipwayOrder = os.ship.use(authMiddleware).handler(async ({ input, context, errors }) => {
  const warehouse = await getWarehouse(context.user.primaryWarehouse);
  if (!warehouse.metadata.shipwayWarehouseId) {
    throw errors.WAREHOUSE_ID_NOT_FOUND();
  }

  if (!warehouse.availablePlatforms.includes("shipway")) {
    throw errors.PLATFORM_NOT_ENABLED();
  }

  const response = await createShipwayOrder({
    ...input,
    warehouse_id: Number(warehouse.metadata.shipwayWarehouseId),
    return_warehouse_id: Number(warehouse.metadata.shipwayWarehouseId),
    order_weight: (input.order_weight || 0) * 1000,
  });

  const trackingNumber = response.awb_response.AWB;
  const shippingLabel = response.awb_response.shipping_url;

  if (!trackingNumber) {
    throw errors.INVALID_TRACKING_NUMBER();
  }

  if (!shippingLabel) {
    throw errors.INVALID_SHIPPING_LABEL_URL();
  }

  return {
    message: "Order shipped",
    data: {
      trackingNumber,
      shippingLabel,
    },
  };
});

export const router = {
  ship: shipShipwayOrder,
};
