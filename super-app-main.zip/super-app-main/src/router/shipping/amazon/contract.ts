import { createAmazonOrderPayloadSchema } from "@/schema/shipping/amazon";
import { shipOrder } from "../contract";

export const shipAmazonOrder = shipOrder.input(createAmazonOrderPayloadSchema);

export const contract = {
  ship: shipAmazonOrder,
};
