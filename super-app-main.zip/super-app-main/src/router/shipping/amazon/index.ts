import { getWarehouse } from "@/db/utils/warehouse";
import { authMiddleware } from "@/lib/orpc/middleware";
import { createAmazonOrder, generateAmazonLabel } from "@/lib/shipping/amazon";
import { implement } from "@orpc/server";
import { contract } from "./contract";

const os = implement(contract);

const shipAmazonOrder = os.ship.use(authMiddleware).handler(async ({ input, context, errors }) => {
  const warehouse = await getWarehouse(context.user.primaryWarehouse);
  if (!warehouse.availablePlatforms.includes("amazon")) {
    throw errors.PLATFORM_NOT_ENABLED();
  }

  const createAmazonOrderResponse = await createAmazonOrder({
    ...input,
    shipFrom: {
      name: warehouse.name,
      addressLine1: warehouse.address1,
      addressLine2: warehouse.address2,
      city: warehouse.city,
      countryCode: warehouse.country,
      postalCode: String(warehouse.pincode),
      stateOrRegion: warehouse.state,
      phoneNumber: warehouse.phone,
    },
  });

  const generateLabelResponse = await generateAmazonLabel({
    rateId: createAmazonOrderResponse.rates[0].rateId,
    requestedDocumentSpecification: {
      format: "PDF",
      size: {
        length: 4,
        width: 6,
        unit: "INCH",
      },
      dpi: 300,
      pageLayout: "DEFAULT",
      requestedDocumentTypes: ["LABEL"],
      needFileJoining: false,
    },
    requestToken: createAmazonOrderResponse.requestToken,
  });

  const trackingNumber = String(generateLabelResponse.packageDocumentDetails[0].trackingId);
  const shippingLabel = generateLabelResponse.packageDocumentDetails[0].packageDocuments[0].contents;

  return {
    message: "Order shipped",
    data: {
      trackingNumber,
      shippingLabel: `data:application/pdf;base64,${shippingLabel}`,
    },
  };
});

export const router = {
  ship: shipAmazonOrder,
};
