import { getWarehouse } from "@/db/utils/warehouse";
import { authMiddleware } from "@/lib/orpc/middleware";
import { createDelhiveryOrder, printDelhiveryShippingLabel } from "@/lib/shipping/delhivery";
import { implement } from "@orpc/server";
import { contract } from "./contract";

const os = implement(contract);

const shipDelhiveryOrder = os.ship.use(authMiddleware).handler(async ({ input, context, errors }) => {
  const warehouse = await getWarehouse(context.user.primaryWarehouse);
  if (!warehouse.metadata.delhiveryWarehouseId) {
    throw errors.WAREHOUSE_ID_NOT_FOUND();
  }

  if (!warehouse.availablePlatforms.includes("delhivery")) {
    throw errors.PLATFORM_NOT_ENABLED();
  }

  const createOrderResponse = await createDelhiveryOrder({
    ...input,
    pickup_location: {
      name: warehouse.metadata.delhiveryWarehouseId,
    },
  });

  const trackingNumber = createOrderResponse.packages[0].waybill;
  if (!trackingNumber) {
    throw errors.INVALID_TRACKING_NUMBER();
  }

  const printLabelResponse = await printDelhiveryShippingLabel(trackingNumber);
  const shippingLabel = printLabelResponse.packages?.[0]?.pdf_download_link;
  if (!shippingLabel) {
    throw errors.INVALID_SHIPPING_LABEL_URL();
  }

  return {
    message: "Order shipped",
    data: {
      trackingNumber,
      shippingLabel,
    },
  };
});

export const router = {
  ship: shipDelhiveryOrder,
};
