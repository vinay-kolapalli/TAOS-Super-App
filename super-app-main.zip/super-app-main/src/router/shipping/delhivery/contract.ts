import { createDelhiveryOrderPayloadSchema } from "@/schema/shipping/delhivery";
import { shipOrder } from "../contract";

export const shipDelhiveryOrder = shipOrder.input(createDelhiveryOrderPayloadSchema);

export const contract = {
  ship: shipDelhiveryOrder,
};
