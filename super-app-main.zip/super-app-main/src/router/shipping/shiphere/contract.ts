import { createShiphereOrderPayloadSchema } from "@/schema/shipping/shiphere";
import { shipOrder } from "../contract";

export const shipShiphereOrder = shipOrder.input(createShiphereOrderPayloadSchema);

export const contract = {
  ship: shipShiphereOrder,
};
