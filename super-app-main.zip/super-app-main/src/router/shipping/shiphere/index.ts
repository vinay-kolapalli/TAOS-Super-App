import { getWarehouse } from "@/db/utils/warehouse";
import { authMiddleware } from "@/lib/orpc/middleware";
import { createShiphereOrder } from "@/lib/shipping/shiphere";
import { implement } from "@orpc/server";
import { contract } from "./contract";

const os = implement(contract);

const shipShiphereOrder = os.ship.use(authMiddleware).handler(async ({ input, context, errors }) => {
  const warehouse = await getWarehouse(context.user.primaryWarehouse);
  if (!warehouse.metadata.shiphereWarehouseId) {
    throw errors.WAREHOUSE_ID_NOT_FOUND();
  }

  if (!warehouse.availablePlatforms.includes("shiphere")) {
    throw errors.PLATFORM_NOT_ENABLED();
  }

  const response = await createShiphereOrder({
    ...input,
    warehouseId: warehouse.metadata.shiphereWarehouseId,
  });

  return {
    message: "Order shipped",
    data: {
      trackingNumber: response.awb,
      shippingLabel: response.labelUrl,
    },
  };
});

export const router = {
  ship: shipShiphereOrder,
};
