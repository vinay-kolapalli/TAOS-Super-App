import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { shipOrderOutputSchema } from "./schema";

export const shipOrder = oc
  .meta({
    permission: [permissionsList.courierChecker.write],
  })
  .errors({
    INTERNAL_SERVER_ERROR: {
      message: "Unable to process shipping request",
      status: 500,
    },
    WAREHOUSE_ID_NOT_FOUND: {
      message: "Warehouse not configured for shipping platform",
      status: 400,
    },
    PLATFORM_NOT_ENABLED: {
      message: "Shipping platform not enabled for warehouse",
      status: 400,
    },
    INVALID_TRACKING_NUMBER: {
      message: "Failed to generate tracking number",
      status: 500,
    },
    INVALID_SHIPPING_LABEL_URL: {
      message: "Failed to generate shipping label",
      status: 500,
    },
  })
  .output(shipOrderOutputSchema);

export const contract = {
  ship: shipOrder,
};
