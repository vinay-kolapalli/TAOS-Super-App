import { createIThinkLogisticsOrderPayloadSchema } from "@/schema/shipping/ithink-logistics";
import { shipOrder } from "../contract";

export const shipIThinkLogisticsOrder = shipOrder.input(createIThinkLogisticsOrderPayloadSchema);

export const contract = {
  ship: shipIThinkLogisticsOrder,
};
