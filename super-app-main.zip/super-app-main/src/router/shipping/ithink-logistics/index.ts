import { getWarehouse } from "@/db/utils/warehouse";
import { authMiddleware } from "@/lib/orpc/middleware";
import { createIThinkLogisticsOrder, printIThinkLogisticsShippingLabel } from "@/lib/shipping/ithink-logistics";
import { implement } from "@orpc/server";
import { contract } from "./contract";

const os = implement(contract);

const shipIThinkLogisticsOrder = os.ship.use(authMiddleware).handler(async ({ input, context, errors }) => {
  const warehouse = await getWarehouse(context.user.primaryWarehouse);
  if (!warehouse.metadata.iThinkLogisticsWarehouseId) {
    throw errors.WAREHOUSE_ID_NOT_FOUND();
  }

  if (!warehouse.availablePlatforms.includes("ithink-logistics")) {
    throw errors.PLATFORM_NOT_ENABLED();
  }

  const orderResponse = await createIThinkLogisticsOrder({
    ...input,
    pickup_address_id: Number(warehouse.metadata.iThinkLogisticsWarehouseId),
    shipments: input.shipments.map((shipment) => ({
      ...shipment,
      return_address_id: Number(warehouse.metadata.iThinkLogisticsWarehouseId),
    })),
  });

  const trackingNumber = String(orderResponse.data.waybill);
  const labelResponse = await printIThinkLogisticsShippingLabel(trackingNumber);

  return {
    message: "Order shipped",
    data: {
      trackingNumber,
      shippingLabel: labelResponse.file_name,
    },
  };
});

export const router = {
  ship: shipIThinkLogisticsOrder,
};
