import { db } from "@/db";
import { orderShipments } from "@/db/schema/courier-checker";
import { boxes } from "@/db/schema/shipping";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { ORPCError } from "@orpc/client";
import { implement } from "@orpc/server";
import { and, eq, gte, inArray, lte } from "drizzle-orm";
import { contract } from "./contract";

const os = implement(contract);

const createBox = os.create.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(db.insert(boxes).values(input));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, {
        uniqueConstraint: "Box ID already exists",
        fallback: "Unable to create box",
      }),
    });
  }
  return { message: "Box created" };
});

const updateBox = os.update.use(authMiddleware).handler(async ({ input }) => {
  const { id, ...rest } = input;

  const { error } = await tryCatch(db.update(boxes).set(rest).where(eq(boxes.id, id)));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, {
        uniqueConstraint: "Box ID already exists",
        fallback: "Unable to update box",
      }),
    });
  }

  return { message: "Box updated" };
});

const getBoxesReport = os.report.use(authMiddleware).handler(async ({ input, context }) => {
  const { from, to, warehouse } = input;
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses =
    warehouse && userWarehouses.includes(Number(warehouse)) ? [Number(warehouse)] : userWarehouses;

  if (!validWarehouses) {
    throw new ORPCError("FORBIDDEN", {
      message: "Access denied to warehouse",
    });
  }

  const shipments = await db.query.orderShipments.findMany({
    where: and(
      gte(orderShipments.createdAt, from),
      lte(orderShipments.createdAt, to),
      inArray(orderShipments.warehouse, validWarehouses)
    ),
  });

  const uniqueOrderNumbers = new Set<number>();
  const boxMap = new Map<string, { box: string; count: number }>();

  shipments.forEach((shipment) => {
    // Skip if we've already processed this order number
    if (uniqueOrderNumbers.has(shipment.orderNumber)) {
      return;
    }

    uniqueOrderNumbers.add(shipment.orderNumber);

    const box = shipment.box;
    const existing = boxMap.get(box);

    if (existing) {
      existing.count += 1;
    } else {
      boxMap.set(box, {
        box,
        count: 1,
      });
    }
  });

  const boxes = Array.from(boxMap.values());

  const csv = returnCsv(boxes);

  return { message: "Boxes exported", data: csv };
});

export const router = {
  create: createBox,
  update: updateBox,
  report: getBoxesReport,
};
