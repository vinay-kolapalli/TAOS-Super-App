import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import {
  getBoxesReportInputSchema,
  getBoxesReportOutputSchema,
  upsertBoxInputSchema,
  upsertBoxOutputSchema,
} from "./schema";

const upsertBox = oc
  .meta({ permission: [permissionsList.boxes.write] })
  .input(upsertBoxInputSchema)
  .output(upsertBoxOutputSchema);

const getBoxesReport = oc
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.boxes.read] })
  .input(getBoxesReportInputSchema)
  .output(getBoxesReportOutputSchema);

export const contract = {
  create: upsertBox,
  update: upsertBox,
  report: getBoxesReport,
};
