import { createOutputSchema } from "@/lib/orpc/contract";
import { getEndOfDay, getStartOfDay } from "@/utils/date";
import z from "zod";

export const upsertBoxInputSchema = z.object({
  id: z
    .string()
    .min(1, "Box ID is required")
    .regex(/^[a-z0-9-]+$/, "Only lowercase letters, numbers, and hyphens allowed"),
  name: z.string().min(1, "Box name is required"),
  isActive: z.boolean(),
  length: z.coerce.number<number>(),
  breadth: z.coerce.number<number>(),
  height: z.coerce.number<number>(),
  volumetricWeight: z.coerce.number<number>(),
});
export type UpsertBoxInputSchema = z.infer<typeof upsertBoxInputSchema>;

export const upsertBoxOutputSchema = createOutputSchema();
export type UpsertBoxOutputSchema = z.infer<typeof upsertBoxOutputSchema>;

export const getBoxesReportInputSchema = z.object({
  from: z.date().transform((val) => getStartOfDay(val)),
  to: z.date().transform((val) => getEndOfDay(val)),
  warehouse: z.number().optional(),
});
export type GetBoxesReportInputSchema = z.infer<typeof getBoxesReportInputSchema>;

export const getBoxesReportOutputSchema = createOutputSchema(z.string());
export type GetBoxesReportOutputSchema = z.infer<typeof getBoxesReportOutputSchema>;
