import { db } from "@/db";
import { authMiddleware } from "@/lib/orpc/middleware";
import { convertShopifyIdToGid } from "@/lib/shopify";
import { moveFulfillmentOrder } from "@/lib/shopify/fulfillment";
import {
  getShopifyOrders,
  getShopifyOrdersForShipping,
  getOrderCount as getStoreOrderCount,
  updateOrder as updateShopifyOrder,
} from "@/lib/shopify/orders";
import { tryCatch } from "@/lib/try-catch";
import { batchProcess } from "@/utils/batch";
import { implement, ORPCError } from "@orpc/server";
import { contract } from "./contract";

const os = implement(contract);

const getOrders = os.list.use(authMiddleware).handler(async ({ input, context }) => {
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses = input.warehouses ? input.warehouses : userWarehouses;

  const data = await getShopifyOrders({
    perPage: input.perPage,
    after: input.after,
    before: input.before,
    search: input.search ? String(input.search) : undefined,
    status: input.status,
    include: input.include,
    sort: input.sort,
    sortBy: input.sortBy,
    warehouses: validWarehouses,
  });

  return {
    message: "Orders retrieved",
    data: {
      orders: data.orders,
      hasNextPage: data.hasNextPage,
      hasPreviousPage: data.hasPreviousPage,
      endCursor: data.endCursor,
      startCursor: data.startCursor,
    },
  };
});

const getShippingOrders = os.listShipping.use(authMiddleware).handler(async ({ input, context }) => {
  const userWarehouses = [context.user.primaryWarehouse];
  const validWarehouses = input.warehouses ? input.warehouses : userWarehouses;

  const data = await getShopifyOrdersForShipping({
    perPage: input.perPage,
    after: input.after,
    before: input.before,
    status: input.status,
    warehouses: validWarehouses,
  });

  return {
    message: "Shipping orders retrieved",
    data: {
      orders: data.orders,
      hasNextPage: data.hasNextPage,
      hasPreviousPage: data.hasPreviousPage,
      endCursor: data.endCursor,
      startCursor: data.startCursor,
    },
  };
});

const getOrderCount = os.count.use(authMiddleware).handler(async ({ input, context }) => {
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses = input.warehouses ? input.warehouses : userWarehouses;

  const warehouseQuery = validWarehouses.map((warehouse) => `tag:'warehouse:${warehouse}'`).join(" OR ");

  const [
    all,
    onHold,
    processing,
    previewed,
    printed,
    shipped,
    cancelled,
    addressIssue,
    reship,
    reshipped,
    rto,
    refunded,
  ] = await Promise.all([
    getStoreOrderCount(warehouseQuery),
    getStoreOrderCount(`tag:'status:on-hold' ${warehouseQuery}`),
    getStoreOrderCount(`tag:'status:processing' ${warehouseQuery}`),
    getStoreOrderCount(`tag:'status:previewed' ${warehouseQuery}`),
    getStoreOrderCount(`tag:'status:printed' ${warehouseQuery}`),
    getStoreOrderCount(`tag:'status:shipped' ${warehouseQuery}`),
    getStoreOrderCount(`status:Cancelled ${warehouseQuery}`),
    getStoreOrderCount(`tag:'status:address-issue' ${warehouseQuery}`),
    getStoreOrderCount(`tag:'status:reship' ${warehouseQuery}`),
    getStoreOrderCount(`tag:'status:reshipped' ${warehouseQuery}`),
    getStoreOrderCount(`tag:'status:rto' ${warehouseQuery}`),
    getStoreOrderCount(`financial_status:refunded OR financial_status:partially_refunded ${warehouseQuery}`),
  ]);

  const data = {
    all,
    onHold,
    processing,
    previewed,
    printed,
    shipped,
    cancelled,
    addressIssue,
    reship,
    reshipped,
    rto,
    refunded,
  };

  return { message: "Order counts retrieved", data };
});

const updateOrder = os.update.use(authMiddleware).handler(async ({ input }) => {
  await batchProcess(input, 10, async (orderInput) => {
    const { error } = await tryCatch(
      updateShopifyOrder({
        id: orderInput.id,
        tags: orderInput.tags,
        shippingAddress: {
          firstName: orderInput.shipping?.firstName,
          lastName: orderInput.shipping?.lastName,
          address1: orderInput.shipping?.address1,
          address2: orderInput.shipping?.address2,
          city: orderInput.shipping?.city,
          company: orderInput.shipping?.company,
          phone: orderInput.shipping?.phone ? String(orderInput.shipping?.phone) : undefined,
          province: orderInput.shipping?.state,
          provinceCode: orderInput.shipping?.stateCode,
          zip: orderInput.shipping?.postcode ? String(orderInput.shipping?.postcode) : undefined,
        },
      })
    );

    if (error) {
      throw new ORPCError("INTERNAL_SERVER_ERROR", {
        message: `Failed to update order ${orderInput.id}: ${error.message}`,
      });
    }
  });

  return { message: "Orders updated successfully" };
});

const changeOrdersWarehouse = os.changeWarehouse.use(authMiddleware).handler(async ({ input }) => {
  const warehouse = await db.query.warehouses.findFirst({
    columns: {
      id: true,
      metadata: true,
    },
    where(fields, { eq }) {
      return eq(fields.id, input.warehouse);
    },
  });
  if (!warehouse?.metadata.storeId) {
    throw new ORPCError("BAD_REQUEST", {
      message: "Warehouse not found or missing store configuration",
    });
  }

  await batchProcess(input.orders, 10, async (order) => {
    const { error } = await tryCatch(
      moveFulfillmentOrder(convertShopifyIdToGid(order, "Order"), Number(warehouse.metadata.storeId))
    );

    if (error) {
      throw new ORPCError("INTERNAL_SERVER_ERROR", {
        message: `Failed to move order ${order} to warehouse: ${error.message || "Unknown error"}`,
      });
    }
  });

  return { message: "Orders moved to new warehouse successfully" };
});

export const router = {
  list: getOrders,
  listShipping: getShippingOrders,
  count: getOrderCount,
  update: updateOrder,
  changeWarehouse: changeOrdersWarehouse,
};
