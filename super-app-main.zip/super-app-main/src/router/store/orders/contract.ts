import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import {
  changeOrdersWarehouseInputSchema,
  changeOrdersWarehouseOutputSchema,
  getOrderCountInputSchema,
  getOrderCountOutputSchema,
  getOrdersInputSchema,
  getOrdersOutputSchema,
  getShippingOrdersInputSchema,
  getShippingOrdersOutputSchema,
  updateOrderInputSchema,
  updateOrderOutputSchema,
} from "./schema";

const getOrders = oc
  .meta({
    permission: [permissionsList.orders.read],
  })
  .input(getOrdersInputSchema)
  .output(getOrdersOutputSchema);

const getShippingOrders = oc
  .meta({
    permission: [permissionsList.orders.read, permissionsList.courierChecker.read, permissionsList.reviewDesk.read],
  })
  .input(getShippingOrdersInputSchema)
  .output(getShippingOrdersOutputSchema);

const getOrderCount = oc
  .meta({
    permission: [permissionsList.orders.read],
  })
  .input(getOrderCountInputSchema)
  .output(getOrderCountOutputSchema);

const updateOrder = oc
  .meta({ permission: [permissionsList.orders.write] })
  .input(updateOrderInputSchema)
  .output(updateOrderOutputSchema);

const changeOrdersWarehouse = oc
  .meta({ permission: [permissionsList.orders.write] })
  .input(changeOrdersWarehouseInputSchema)
  .output(changeOrdersWarehouseOutputSchema);

export const contract = {
  list: getOrders,
  listShipping: getShippingOrders,
  count: getOrderCount,
  update: updateOrder,
  changeWarehouse: changeOrdersWarehouse,
};
