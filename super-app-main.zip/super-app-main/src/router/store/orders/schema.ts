import { createOutputSchema } from "@/lib/orpc/contract";
import { convertShopifyIdToGid } from "@/lib/shopify";
import { addressSchema, orderSchema, shippingOrderSchema } from "@/types/order";
import z from "zod";

export const getOrdersInputSchema = z.object({
  perPage: z.number().default(25),
  after: z.string().optional(),
  before: z.string().optional(),
  search: z.union([z.string(), z.number()]).optional(),
  status: z.string().optional(),
  include: z.array(z.number()).optional(),
  sort: z.string().optional(),
  sortBy: z.string().optional(),
  warehouses: z.array(z.number()).optional(),
});
export type GetOrdersInputSchema = z.infer<typeof getOrdersInputSchema>;

export const getOrdersOutputSchema = createOutputSchema(
  z.object({
    orders: z.array(orderSchema),
    hasNextPage: z.boolean(),
    hasPreviousPage: z.boolean(),
    endCursor: z.string().optional().nullable(),
    startCursor: z.string().optional().nullable(),
  })
);
export type GetOrdersOutputSchema = z.infer<typeof getOrdersOutputSchema>;

export const getShippingOrdersInputSchema = z.object({
  perPage: z.number().default(25),
  after: z.string().optional(),
  before: z.string().optional(),
  status: z.string().optional(),
  warehouses: z.array(z.number()).optional(),
});
export type GetShippingOrdersInputSchema = z.infer<typeof getShippingOrdersInputSchema>;

export const getShippingOrdersOutputSchema = createOutputSchema(
  z.object({
    orders: z.array(shippingOrderSchema),
    hasNextPage: z.boolean(),
    hasPreviousPage: z.boolean(),
    endCursor: z.string().optional().nullable(),
    startCursor: z.string().optional().nullable(),
  })
);
export type GetShippingOrdersOutputSchema = z.infer<typeof getShippingOrdersOutputSchema>;

export const getOrderCountInputSchema = z.object({
  warehouses: z.array(z.number()).optional(),
});
export type GetOrderCountInputSchema = z.infer<typeof getOrderCountInputSchema>;

export const getOrderCountOutputSchema = createOutputSchema(
  z.object({
    all: z.number(),
    onHold: z.number(),
    processing: z.number(),
    previewed: z.number(),
    printed: z.number(),
    shipped: z.number(),
    cancelled: z.number(),
    addressIssue: z.number(),
    reship: z.number(),
    reshipped: z.number(),
    rto: z.number(),
    refunded: z.number(),
  })
);
export type GetOrderCountOutputSchema = z.infer<typeof getOrderCountOutputSchema>;

export const updateOrderInputSchema = z.array(
  z.object({
    id: z.number().transform((v) => convertShopifyIdToGid(v, "Order")),
    shipping: addressSchema.optional(),
    tags: z.array(z.string()).optional(),
  })
);
export type UpdateOrderInputSchema = z.infer<typeof updateOrderInputSchema>;

export const updateOrderOutputSchema = createOutputSchema();
export type UpdateOrderOutputSchema = z.infer<typeof updateOrderOutputSchema>;

export const changeOrdersWarehouseInputSchema = z.object({
  orders: z.array(z.number()),
  warehouse: z.number(),
});
export type ChangeOrdersWarehouseInputSchema = z.infer<typeof changeOrdersWarehouseInputSchema>;

export const changeOrdersWarehouseOutputSchema = createOutputSchema();
export type ChangeOrdersWarehouseOutputSchema = z.infer<typeof changeOrdersWarehouseOutputSchema>;
