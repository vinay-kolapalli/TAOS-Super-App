import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { getTaxReportInputSchema, getTaxReportOutputSchema } from "./schema";

const getTaxReport = oc
  .meta({ permission: [permissionsList.orders.read] })
  .input(getTaxReportInputSchema)
  .output(getTaxReportOutputSchema);

export const contract = {
  tax: getTaxReport,
};
