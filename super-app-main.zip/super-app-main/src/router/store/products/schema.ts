import { createOutputSchema } from "@/lib/orpc/contract";
import { getEndOfDay, getStartOfDay } from "@/utils/date";
import z from "zod";

export const getProductsOutputSchema = createOutputSchema(
  z.array(
    z.object({
      id: z.number(),
      name: z.string(),
      url: z.string(),
      image: z.string(),
    })
  )
);
export type GetProductsOutputSchema = z.infer<typeof getProductsOutputSchema>;

export const getProductsReportInputSchema = z.object({
  from: z.date().transform((val) => getStartOfDay(val)),
  to: z.date().transform((val) => getEndOfDay(val)),
  warehouse: z.number().optional(),
});
export type GetProductsReportInputSchema = z.infer<typeof getProductsReportInputSchema>;

export const getProductsReportOutputSchema = createOutputSchema(z.string());
export type GetProductsReportOutputSchema = z.infer<typeof getProductsReportOutputSchema>;
