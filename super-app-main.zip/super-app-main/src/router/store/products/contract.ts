import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { getProductsOutputSchema, getProductsReportInputSchema, getProductsReportOutputSchema } from "./schema";

const getProducts = oc.output(getProductsOutputSchema);

const getSalesReport = oc
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.products.read] })
  .input(getProductsReportInputSchema)
  .output(getProductsReportOutputSchema);

export const contract = {
  list: getProducts,
  report: getSalesReport,
};
