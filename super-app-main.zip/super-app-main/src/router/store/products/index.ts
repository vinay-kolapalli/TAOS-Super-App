import { authMiddleware } from "@/lib/orpc/middleware";
import { getShopifyOrdersForWarehouseReport } from "@/lib/shopify/orders";
import { getProducts } from "@/lib/shopify/products";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { implement, ORPCError } from "@orpc/server";
import { contract } from "./contract";

const os = implement(contract);

const listProducts = os.list.use(authMiddleware).handler(async ({ input }) => {
  let hasNextPage = true;
  let cursor: string | undefined | null;
  const allProducts = [];

  while (hasNextPage) {
    const { data, error } = await tryCatch(
      getProducts({
        limit: 250,
        after: cursor,
      })
    );

    if (error) {
      throw new ORPCError("INTERNAL_SERVER_ERROR", {
        message: "Unable to fetch products from store",
      });
    }

    allProducts.push(...data.products);
    hasNextPage = data.hasNextPage;
    cursor = data.endCursor;
  }

  return { message: "Products retrieved", data: allProducts };
});

const getSalesReport = os.report.use(authMiddleware).handler(async ({ input, context }) => {
  const { from, to, warehouse } = input;
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses =
    warehouse && userWarehouses.includes(Number(warehouse)) ? [Number(warehouse)] : userWarehouses;

  if (!validWarehouses) {
    throw new ORPCError("FORBIDDEN", {
      message: "Access denied to warehouse",
    });
  }

  const orders = await getShopifyOrdersForWarehouseReport({
    from: from.toISOString(),
    to: to.toISOString(),
    warehouses: validWarehouses,
  });

  const productMap = new Map<string, { product: string; quantity: number; sku: string | null }>();

  orders.forEach((order) => {
    order.lineItems.forEach((item) => {
      const key = item.sku || item.name;
      const existing = productMap.get(key);

      if (existing) {
        existing.quantity += item.quantity;
      } else {
        productMap.set(key, {
          product: item.name,
          quantity: item.quantity,
          sku: item.sku || "",
        });
      }
    });
  });

  const reportData = Array.from(productMap.values());
  const csv = returnCsv(reportData);

  return { message: "Export completed", data: csv };
});

export const router = {
  list: listProducts,
  report: getSalesReport,
};
