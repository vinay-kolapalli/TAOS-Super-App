import * as orders from "./orders";
import * as products from "./products";
import * as report from "./report";

export const router = {
  orders: orders.router,
  products: products.router,
  report: report.router,
};
