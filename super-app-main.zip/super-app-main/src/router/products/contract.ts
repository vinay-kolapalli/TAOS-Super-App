import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import {
  createProductInputSchema,
  createProductOutputSchema,
  deleteProductInputSchema,
  deleteProductOutputSchema,
  exportProductsInputSchema,
  exportProductsOutputSchema,
  getProductsOutputSchema,
  updateProductInputSchema,
  updateProductOutputSchema,
} from "./schema";

const getProducts = oc
  .meta({
    permission: [
      permissionsList.seedsBundlingRecords.write,
      permissionsList.offlineSalesRecords.write,
      permissionsList.damagedProductsRecords.write,
      permissionsList.inboundInventoryRecords.write,
      permissionsList.recoveredProductsRecords.write,
      permissionsList.vendors.write,
      permissionsList.vendorInquiries.write,
    ],
  })
  .output(getProductsOutputSchema);

const createProduct = oc
  .meta({
    permission: [permissionsList.products.write],
  })
  .input(createProductInputSchema)
  .output(createProductOutputSchema);

const updateProduct = oc
  .meta({
    permission: [permissionsList.products.write],
  })
  .input(updateProductInputSchema)
  .output(updateProductOutputSchema);

const deleteProduct = oc
  .meta({
    permission: [permissionsList.products.write],
  })
  .input(deleteProductInputSchema)
  .output(deleteProductOutputSchema);

const exportProducts = oc
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.products.read] })
  .input(exportProductsInputSchema)
  .output(exportProductsOutputSchema);

export const contract = {
  list: getProducts,
  create: createProduct,
  update: updateProduct,
  delete: deleteProduct,
  export: exportProducts,
};
