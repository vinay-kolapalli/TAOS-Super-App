import { db } from "@/db";
import { products } from "@/db/schema/products";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { fetchAllData } from "@/db/utils/fetch";
import { authMiddleware } from "@/lib/orpc/middleware";
import { getSignedUrl } from "@/lib/s3";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { formatDate } from "@/utils/date";
import { ORPCError } from "@orpc/client";
import { implement } from "@orpc/server";
import { and, eq, gt, gte, lte } from "drizzle-orm";
import { contract } from "./contract";

const os = implement(contract);

const listAllProducts = os.list.use(authMiddleware).handler(async () => {
  const { error, data } = await tryCatch(
    fetchAllData(undefined, (cursor) =>
      db.query.products.findMany({
        columns: {
          id: true,
          name: true,
          image: true,
          description: true,
          sku: true,
        },
        limit: 500,
        where: cursor ? gt(products.id, cursor) : undefined,
        orderBy(fields, operators) {
          return operators.asc(fields.id);
        },
      })
    )
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, {
        fallback: "Unable to retrieve products",
      }),
    });
  }

  return { message: "Products retrieved", data };
});

const createProduct = os.create.use(authMiddleware).handler(async ({ input, context }) => {
  const { error } = await tryCatch(
    db.insert(products).values({
      ...input,
      createdBy: context.user.id,
      updatedBy: context.user.id,
    })
  );
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, {
        fallback: "Unable to create product",
        uniqueConstraint: "A product with this SKU already exists",
      }),
    });
  }

  return { message: "Product created" };
});

const updateProduct = os.update.use(authMiddleware).handler(async ({ input, context }) => {
  const { id, ...rest } = input;
  const { error } = await tryCatch(
    db
      .update(products)
      .set({ ...rest, updatedAt: new Date(), updatedBy: context.user.id })
      .where(eq(products.id, id))
  );
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, {
        fallback: "Unable to update product",
        uniqueConstraint: "A product with this SKU already exists",
      }),
    });
  }

  return { message: "Product updated" };
});

const deleteProduct = os.delete.use(authMiddleware).handler(async ({ input }) => {
  const { id } = input;
  const { error } = await tryCatch(db.delete(products).where(eq(products.id, id)));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to delete product" }),
    });
  }

  return { message: "Product deleted" };
});

const exportProducts = os.export.use(authMiddleware).handler(async ({ input, context }) => {
  const response = await fetchAllData(undefined, async (cursor) => {
    return await db.query.products.findMany({
      with: {
        createdBy: {
          columns: {
            name: true,
          },
        },
        updatedBy: {
          columns: {
            name: true,
          },
        },
      },
      where: and(
        gte(products.createdAt, input.from),
        lte(products.createdAt, input.to),
        cursor ? gt(products.id, cursor) : undefined
      ),
      limit: 500,
      orderBy(fields, operators) {
        return operators.asc(fields.id);
      },
    });
  });

  const data = response.map((product) => ({
    ID: product.id,
    Created: formatDate(product.createdAt),
    Name: product.name,
    SKU: product.sku,
    Description: product.description,
    Image: product.image ? getSignedUrl(product.image) : "",
    "Created By": product.createdBy?.name || "",
    "Updated By": product.updatedBy?.name || "",
  }));

  const csv = returnCsv(data);

  return { message: "Export completed", data: csv };
});

export const router = {
  list: listAllProducts,
  create: createProduct,
  update: updateProduct,
  delete: deleteProduct,
  export: exportProducts,
};
