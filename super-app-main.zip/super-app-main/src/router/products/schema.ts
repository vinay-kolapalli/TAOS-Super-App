import { createOutputSchema } from "@/lib/orpc/contract";
import { getEndOfDay, getStartOfDay } from "@/utils/date";
import z from "zod";

export const getProductsOutputSchema = createOutputSchema(
  z.array(
    z.object({
      id: z.number(),
      name: z.string(),
      image: z.string().nullable(),
      description: z.string(),
      sku: z.string(),
    })
  )
);
export type GetProductsOutputSchema = z.infer<typeof getProductsOutputSchema>;

export const createProductInputSchema = z.object({
  name: z.string().min(1, "Product name is required"),
  description: z.string(),
  sku: z.string(),
  image: z.string().optional().nullable(),
});
export type CreateProductInputSchema = z.infer<typeof createProductInputSchema>;

export const createProductOutputSchema = createOutputSchema();
export type CreateProductOutputSchema = z.infer<typeof createProductOutputSchema>;

export const updateProductInputSchema = createProductInputSchema.extend({ id: z.number() });
export type UpdateProductInputSchema = z.infer<typeof updateProductInputSchema>;

export const updateProductOutputSchema = createOutputSchema();
export type UpdateProductOutputSchema = z.infer<typeof updateProductOutputSchema>;

export const deleteProductInputSchema = z.object({ id: z.number() });
export type DeleteProductInputSchema = z.infer<typeof deleteProductInputSchema>;

export const deleteProductOutputSchema = createOutputSchema();
export type DeleteProductOutputSchema = z.infer<typeof deleteProductOutputSchema>;

export const exportProductsInputSchema = z.object({
  from: z.date().transform((val) => getStartOfDay(val)),
  to: z.date().transform((val) => getEndOfDay(val)),
});
export type ExportProductsInputSchema = z.infer<typeof exportProductsInputSchema>;

export const exportProductsOutputSchema = createOutputSchema(z.string());
export type ExportProductsOutputSchema = z.infer<typeof exportProductsOutputSchema>;
