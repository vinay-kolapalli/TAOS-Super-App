import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export const uploadFileInputSchema = z.object({
  file: z.instanceof(File),
  folder: z.string(),
});
export type UploadFileInputSchema = z.infer<typeof uploadFileInputSchema>;

export const uploadFileOutputSchema = createOutputSchema(
  z.object({
    url: z.url(),
    path: z.string().min(1),
  })
);
export type UploadFileOutputSchema = z.infer<typeof uploadFileOutputSchema>;
