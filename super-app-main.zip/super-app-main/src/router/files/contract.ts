import { oc } from "@/lib/orpc/contract";
import { uploadFileInputSchema, uploadFileOutputSchema } from "./schema";

const uploadFile = oc.input(uploadFileInputSchema).output(uploadFileOutputSchema);

export const contract = {
  uploadFile,
};
