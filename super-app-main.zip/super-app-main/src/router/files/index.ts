import { authMiddleware } from "@/lib/orpc/middleware";
import { uploadFile as uploadFileToS3 } from "@/lib/s3";
import { tryCatch } from "@/lib/try-catch";
import { implement, ORPCError } from "@orpc/server";
import { nanoid } from "nanoid";
import { contract } from "./contract";

const os = implement(contract);

const uploadFile = os.uploadFile.use(authMiddleware).handler(async ({ input }) => {
  const { file, folder } = input;
  const fileName = file.name.split(".")[0];
  const fileExtension = file.name.split(".")[1];
  const key = `${folder}/${fileName}-${nanoid(5)}.${fileExtension}`;

  const buffer = Buffer.from(await file.arrayBuffer());
  const { data, error } = await tryCatch(uploadFileToS3({ file: buffer, key, contentType: file.type }));

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: "Failed to upload file",
    });
  }

  return { message: "File uploaded", data: { url: data, path: key } };
});

export const router = {
  upload: uploadFile,
};
