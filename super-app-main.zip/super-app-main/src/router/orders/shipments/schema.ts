import { CourierPlatforms, courierPlatforms, courierServices, zones } from "@/data/shipping";
import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export interface CourierData {
  totalShipments: number;
  deliveryTimes: number[];
  deliveredCount: number;
  rtoCount: number;
  otherStatusCount: number;
  totalRate: number;
  platformBookings: Record<string, number>;
}

const orderShipmentRate = z.object({
  id: z.string(),
  orderShipment: z.string(),
  courierService: z.enum(courierServices),
  priority: z.number(),
  platform: z.enum(courierPlatforms).nullable(),
  zone: z.enum(zones),
  rate: z.number(),
  courier: z.object({
    id: z.string(),
    name: z.string(),
    image: z.string(),
  }),
});

export const getOrderShipmentsInputSchema = z.object({
  orderNumber: z.number(),
});
export type GetOrderShipmentsInputSchema = z.infer<typeof getOrderShipmentsInputSchema>;

export const getOrderShipmentsOutputSchema = createOutputSchema(
  z.array(
    z.object({
      id: z.string(),
      createdAt: z.date(),
      orderNumber: z.number(),
      pincode: z.number(),
      weight: z.number(),
      packedBy: z.string(),
      scannedBy: z.string(),
      nonPriorityReason: z.string().nullable(),
      trackingNumber: z.string(),
      warehouse: z.object({
        id: z.number(),
        name: z.string(),
      }),
      box: z.object({
        id: z.string(),
        name: z.string(),
      }),
      rate: orderShipmentRate.optional(),
      rates: z.array(orderShipmentRate),
    })
  )
);
export type GetOrderShipmentsOutputSchema = z.infer<typeof getOrderShipmentsOutputSchema>;

export const dailyShipmentsReportInputSchema = z.object({
  courier: z.string(),
});
export type DailyShipmentsReportInputSchema = z.infer<typeof dailyShipmentsReportInputSchema>;

export const dailyShipmentsReportOutputSchema = createOutputSchema(
  z.array(
    z.object({
      orderId: z.number(),
      orderNumber: z.number(),
    })
  )
);
export type DailyShipmentsReportOutputSchema = z.infer<typeof dailyShipmentsReportOutputSchema>;

export const importShipmentsInputSchema = z.object({
  file: z.instanceof(File),
});
export type ImportShipmentsInputSchema = z.infer<typeof importShipmentsInputSchema>;

export const importShipmentsOutputSchema = createOutputSchema(
  z.object({
    updated: z.number(),
    skipped: z.number(),
    total: z.number(),
  })
);
export type ImportShipmentsOutputSchema = z.infer<typeof importShipmentsOutputSchema>;

export const shipmentReportInputSchema = z.object({
  pincode: z.number(),
});
export type ShipmentReportInputSchema = z.infer<typeof shipmentReportInputSchema>;

export const shipmentReportOutputSchema = createOutputSchema(
  z.object({
    couriers: z.array(
      z.object({
        id: z.string(),
        name: z.string(),
        image: z.string(),
        totalShipments: z.number(),
        averageDeliveryTimeInDays: z.number().nullable(),
        deliveredCount: z.number(),
        rtoCount: z.number(),
        otherStatusCount: z.number(),
        averageRate: z.number(),
        platformBookings: z.record(z.string(), z.number()).transform((val) => val as Record<CourierPlatforms, number>),
      })
    ),
  })
);
export type ShipmentReportOutputSchema = z.infer<typeof shipmentReportOutputSchema>;
