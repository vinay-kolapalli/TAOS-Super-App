import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { exportData } from "../contract";
import { exportDataInputSchema } from "../schema";
import {
  dailyShipmentsReportInputSchema,
  dailyShipmentsReportOutputSchema,
  getOrderShipmentsInputSchema,
  getOrderShipmentsOutputSchema,
  importShipmentsInputSchema,
  importShipmentsOutputSchema,
  shipmentReportInputSchema,
  shipmentReportOutputSchema,
} from "./schema";

const getOrderShipments = oc
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.courierChecker.read] })
  .input(getOrderShipmentsInputSchema)
  .output(getOrderShipmentsOutputSchema);

const dailyShipmentsReport = oc
  .meta({
    permission: [permissionsList.courierChecker.read],
  })
  .input(dailyShipmentsReportInputSchema)
  .output(dailyShipmentsReportOutputSchema);

const importShipments = oc
  .meta({ permission: [permissionsList.orderFlow.write] })
  .input(importShipmentsInputSchema)
  .output(importShipmentsOutputSchema);

const exportShipments = exportData
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.courierChecker.read] })
  .input(exportDataInputSchema);

const shipmentReport = oc
  .meta({ permission: [permissionsList.courierChecker.read] })
  .input(shipmentReportInputSchema)
  .output(shipmentReportOutputSchema);

export const contract = {
  list: getOrderShipments,
  dailyReport: dailyShipmentsReport,
  import: importShipments,
  export: exportShipments,
  report: shipmentReport,
};
