import { db } from "@/db";
import { orderShipmentRates, orderShipments, orderShipmentsStatus } from "@/db/schema/courier-checker";
import { couriers } from "@/db/schema/shipping";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { fetchAllData } from "@/db/utils/fetch";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { formatDate, getEndOfDay, getStartOfDay } from "@/utils/date";
import { implement, ORPCError } from "@orpc/server";
import { differenceInDays } from "date-fns";
import { and, between, eq, gt, gte, inArray, lte } from "drizzle-orm";
import { startCase } from "lodash";
import { contract } from "./contract";
import { CourierData } from "./schema";

const os = implement(contract);

const getOrderShipments = os.list.use(authMiddleware).handler(async ({ input }) => {
  const order = await db.query.orderShipments.findMany({
    where(fields, { eq }) {
      return eq(fields.orderNumber, input.orderNumber);
    },
    with: {
      warehouse: {
        columns: {
          id: true,
          name: true,
        },
      },
      box: {
        columns: {
          id: true,
          name: true,
        },
      },
    },
  });

  // Get all rates for each shipment
  const shipmentsWithAllRates = await Promise.all(
    order.map(async (shipment) => {
      const allRates = await db.query.orderShipmentRates.findMany({
        where(fields, { eq }) {
          return eq(fields.orderShipment, shipment.id);
        },
        with: {
          courier: {
            columns: {
              id: true,
              name: true,
              image: true,
            },
          },
        },
        orderBy(fields, operators) {
          return operators.asc(fields.priority);
        },
      });

      return {
        ...shipment,
        rate: allRates.find((rate) => rate.id === shipment.rate),
        rates: allRates,
      };
    })
  );

  return { message: "Shipments retrieved", data: shipmentsWithAllRates };
});

const dailyShipmentsReport = os.dailyReport.use(authMiddleware).handler(async ({ input }) => {
  const today = new Date();
  const startOfToday = getStartOfDay(today);
  const endOfToday = getEndOfDay(today);

  const { error, data } = await tryCatch(
    db
      .select({
        orderId: orderShipments.orderId,
        orderNumber: orderShipments.orderNumber,
      })
      .from(orderShipments)
      .leftJoin(orderShipmentRates, eq(orderShipments.rate, orderShipmentRates.id))
      .where(
        and(eq(orderShipmentRates.courier, input.courier), between(orderShipments.createdAt, startOfToday, endOfToday))
      )
      .limit(1000)
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to fetch daily shipments" }),
    });
  }

  return { message: "Daily report generated", data };
});

const importShipments = os.import.use(authMiddleware).handler(async ({ input }) => {
  const file = input.file;
  const text = (await file.text()).replaceAll("\r", "");
  const lines = text.split("\n");
  const headers = lines[0].split(",");

  // check if headers are correct
  if (
    headers[0] !== "tracking_number" ||
    headers[1] !== "picked_at" ||
    headers[2] !== "delivered_at" ||
    headers[3] !== "status"
  ) {
    throw new ORPCError("BAD_REQUEST", {
      message: "Invalid file format. Expected headers: tracking_number, picked_at, delivered_at, status",
    });
  }

  const data = lines
    .slice(1)
    .filter((line) => line.trim() !== "")
    .map((line) => {
      const values = line.split(",");
      return {
        trackingNumber: values[0],
        pickedAt: values[1],
        deliveredAt: values[2],
        status: values[3],
      };
    });

  const filteredData = data.filter(
    (item) =>
      item.trackingNumber &&
      orderShipmentsStatus.includes(item.status.toLowerCase() as (typeof orderShipmentsStatus)[number])
  );

  let updated = 0;
  let skipped = data.length - filteredData.length;

  const { error } = await tryCatch(
    db.transaction(async (tx) => {
      for (const item of filteredData) {
        const status = item.status.toLowerCase() as (typeof orderShipmentsStatus)[number];
        await tx
          .update(orderShipments)
          .set({
            pickedAt: item.pickedAt ? new Date(item.pickedAt) : undefined,
            deliveredAt: item.deliveredAt ? new Date(item.deliveredAt) : undefined,
            status,
          })
          .where(eq(orderShipments.trackingNumber, item.trackingNumber));
        updated++;
      }
    })
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to import shipments" }),
    });
  }

  return { message: "Shipments imported successfully", data: { updated, skipped, total: data.length } };
});

const exportShipments = os.export.use(authMiddleware).handler(async ({ input, context }) => {
  const { from, to, warehouse } = input;
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses =
    warehouse && userWarehouses.includes(Number(warehouse)) ? [Number(warehouse)] : userWarehouses;

  if (!validWarehouses) {
    throw new ORPCError("FORBIDDEN", {
      message: "Access denied to warehouse",
    });
  }

  const response = await fetchAllData(undefined, async (cursor) => {
    return await db.query.orderShipments.findMany({
      where: and(
        gte(orderShipments.createdAt, from),
        lte(orderShipments.createdAt, to),
        cursor ? gt(orderShipments.id, cursor) : undefined,
        inArray(orderShipments.warehouse, validWarehouses)
      ),
      with: {
        rate: {
          with: {
            courier: {
              columns: {
                name: true,
              },
            },
          },
        },
        warehouse: {
          columns: {
            name: true,
          },
        },
      },
    });
  });
  const shipments = response.map((shipment) => ({
    createdAt: formatDate(shipment.createdAt),
    orderNumber: shipment.orderNumber,
    pincode: shipment.pincode,
    weight: shipment.weight / 1000,
    box: shipment.box,
    courier: shipment.rate?.courier?.name ?? "unknown",
    courierService: shipment.rate?.courierService ?? "unknown",
    platform: shipment.rate?.platform ?? "direct",
    rate: shipment.rate?.rate ?? 0,
    zone: shipment.rate?.zone ?? "unknown",
    priority: shipment.rate?.priority ?? 0,
    trackingNumber: shipment.trackingNumber,
    packedBy: shipment.packedBy,
    scannedBy: shipment.scannedBy,
    isReshipped: shipment.isReshipped,
    nonPriorityReason: shipment.nonPriorityReason,
    warehouse: shipment.warehouse.name,
  }));

  const csv = returnCsv(shipments);

  return { message: "Export completed", data: csv };
});

const exportShipmentsWithRates = os.export.use(authMiddleware).handler(async ({ input, context }) => {
  const { from, to, warehouse } = input;
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses =
    warehouse && userWarehouses.includes(Number(warehouse)) ? [Number(warehouse)] : userWarehouses;

  if (!validWarehouses) {
    throw new ORPCError("FORBIDDEN", {
      message: "Access denied to warehouse",
    });
  }

  // First, get all order shipments in the date range
  const shipments = await fetchAllData(undefined, async (cursor) => {
    return await db.query.orderShipments.findMany({
      where: and(
        gte(orderShipments.createdAt, from),
        lte(orderShipments.createdAt, to),
        cursor ? gt(orderShipments.id, cursor) : undefined,
        inArray(orderShipments.warehouse, validWarehouses)
      ),
      with: {
        warehouse: {
          columns: {
            name: true,
          },
        },
      },
    });
  });

  // Get all shipment IDs
  const shipmentIds = shipments.map((s) => s.id);
  const rates = await db.query.orderShipmentRates.findMany({
    where: inArray(orderShipmentRates.orderShipment, shipmentIds),
    orderBy(fields, operators) {
      return [operators.asc(fields.orderShipment), operators.asc(fields.priority)];
    },
  });

  // Create a map of shipment ID to shipment data for easy lookup
  const shipmentMap = new Map(shipments.map((s) => [s.id, s]));

  // Flatten the data: one row per rate with shipment details
  const ratesReport = rates
    .map((rate) => {
      const shipment = shipmentMap.get(rate.orderShipment);
      if (!shipment) return null;

      return {
        createdAt: formatDate(shipment.createdAt),
        orderNumber: shipment.orderNumber,
        pincode: shipment.pincode,
        weight: shipment.weight / 1000,
        box: shipment.box,
        courier: rate?.courier ?? "unknown",
        courierService: rate?.courierService ?? "unknown",
        platform: rate?.platform ?? "direct",
        rate: rate?.rate ?? 0,
        zone: rate?.zone ?? "unknown",
        priority: rate?.priority ?? 0,
        trackingNumber: shipment.trackingNumber,
        packedBy: shipment.packedBy,
        scannedBy: shipment.scannedBy,
        isReshipped: shipment.isReshipped,
        nonPriorityReason: shipment.nonPriorityReason,
        warehouse: shipment.warehouse.name,
      };
    })
    .filter((item): item is NonNullable<typeof item> => item !== null);

  const csv = returnCsv(ratesReport);

  return { message: "Export completed", data: csv };
});

const shipmentReport = os.report.use(authMiddleware).handler(async ({ input }) => {
  const shipmentData = await db
    .select({
      id: orderShipments.id,
      courier: {
        id: orderShipmentRates.courier,
        name: couriers.name,
        image: couriers.image,
      },
      status: orderShipments.status,
      pickedAt: orderShipments.pickedAt,
      deliveredAt: orderShipments.deliveredAt,
      rate: orderShipmentRates.rate,
      platform: orderShipmentRates.platform,
    })
    .from(orderShipments)
    .leftJoin(orderShipmentRates, eq(orderShipments.rate, orderShipmentRates.id))
    .leftJoin(couriers, eq(orderShipmentRates.courier, couriers.id))
    .where(eq(orderShipments.pincode, input.pincode))
    .limit(500);

  const courierMap: Record<string, CourierData> = {};
  const platforms = new Set<string>();

  shipmentData.forEach((shipment) => {
    const courier = shipment.courier.id || "unknown";
    const platform = shipment.platform || "direct";
    platforms.add(platform);

    if (!courierMap[courier]) {
      courierMap[courier] = {
        totalShipments: 0,
        deliveryTimes: [],
        deliveredCount: 0,
        rtoCount: 0,
        otherStatusCount: 0,
        totalRate: 0,
        platformBookings: {},
      };
    }

    const courierData = courierMap[courier];
    courierData.totalShipments++;
    courierData.totalRate += shipment.rate || 0;
    courierData.platformBookings[platform] = (courierData.platformBookings[platform] || 0) + 1;

    if (shipment.deliveredAt && shipment.pickedAt) {
      const timeDiff = differenceInDays(shipment.deliveredAt, shipment.pickedAt);
      courierData.deliveryTimes.push(timeDiff);
    }

    const status = shipment.status?.toLowerCase();
    if (status === "delivered") {
      courierData.deliveredCount++;
    } else if (status === "rto") {
      courierData.rtoCount++;
    } else {
      courierData.otherStatusCount++;
    }
  });

  const courierReport = Object.entries(courierMap).map(([courier, data]) => {
    const averageDeliveryTimeInDays =
      data.deliveryTimes.length > 0
        ? Math.round((data.deliveryTimes.reduce((acc, time) => acc + time, 0) / data.deliveryTimes.length) * 100) / 100
        : null;

    const averageRate = data.totalShipments > 0 ? Math.round((data.totalRate / data.totalShipments) * 100) / 100 : 0;

    // Find courier name from shipment data (we'll have it from the first shipment of this courier)
    const shipmentWithCourierName = shipmentData.find((s) => s.courier.id === courier);
    const courierName = shipmentWithCourierName?.courier.name || startCase(courier);

    return {
      id: courier,
      name: courierName,
      image: shipmentWithCourierName?.courier.image ? shipmentWithCourierName.courier.image : "/images/placeholder.png",
      totalShipments: data.totalShipments,
      averageDeliveryTimeInDays,
      deliveredCount: data.deliveredCount,
      rtoCount: data.rtoCount,
      otherStatusCount: data.otherStatusCount,
      averageRate,
      platformBookings: data.platformBookings,
    };
  });

  const data = {
    couriers: courierReport
      .map((c) => ({
        ...c,
        platformBookings: {
          ...Object.fromEntries(Array.from(platforms).map((platform) => [platform, 0])),
          ...c.platformBookings,
        },
      }))
      .sort((a, b) => b.totalShipments - a.totalShipments),
  };

  return { message: "Report generated", data };
});

export const router = {
  list: getOrderShipments,
  dailyReport: dailyShipmentsReport,
  report: shipmentReport,
  import: importShipments,
  export: exportShipments,
  exportWithRates: exportShipmentsWithRates,
};
