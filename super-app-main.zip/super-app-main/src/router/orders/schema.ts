import { courierPlatforms, courierServices, zones } from "@/data/shipping";
import { createOutputSchema } from "@/lib/orpc/contract";
import { getEndOfDay, getStartOfDay } from "@/utils/date";
import z from "zod";

const rate = z.object({
  courier: z.string(),
  courierService: z.enum(courierServices),
  platform: z.enum(courierPlatforms).nullable().optional(),
  zone: z.enum(zones),
  priority: z.number(),
  rate: z.number(),
});

export const shipOrderInputSchema = z.object({
  orderId: z.number(),
  orderNumber: z.number(),
  trackingNumber: z.string(),
  isReshipped: z.boolean(),
  weight: z.number(),
  box: z.string(),
  packedBy: z.string(),
  scannedBy: z.string(),
  pincode: z.number(),
  nonPriorityReason: z.string().nullable(),
  rates: z.array(rate),
  priority: z.number(),
});
export type ShipOrderInputSchema = z.infer<typeof shipOrderInputSchema>;

export const shipOrderOutputSchema = createOutputSchema();
export type ShipOrderOutputSchema = z.infer<typeof shipOrderOutputSchema>;

export const exportDataInputSchema = z.object({
  from: z.date().transform((val) => getStartOfDay(val)),
  to: z.date().transform((val) => getEndOfDay(val)),
  warehouse: z.number().optional(),
});
export type ExportDataInputSchema = z.infer<typeof exportDataInputSchema>;

export const exportDataOutputSchema = createOutputSchema(z.string());
export type ExportDataOutputSchema = z.infer<typeof exportDataOutputSchema>;
