import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export const getOrderReviewInputSchema = z.object({
  orderNumber: z.number(),
});
export type GetOrderReviewInputSchema = z.infer<typeof getOrderReviewInputSchema>;

export const getOrderReviewOutputSchema = createOutputSchema(
  z.array(
    z.object({
      id: z.string(),
      orderId: z.number(),
      orderNumber: z.number(),
      createdAt: z.date(),
      reviewedBy: z.string(),
      scannedProducts: z.array(z.string()),
      warehouse: z.number(),
    })
  )
);
export type GetOrderReviewOutputSchema = z.infer<typeof getOrderReviewOutputSchema>;

export const createOrderReviewInputSchema = z.object({
  orderId: z.number(),
  orderNumber: z.number(),
  reviewedBy: z.string(),
  scannedProducts: z.array(z.string()),
});
export type CreateOrderReviewInputSchema = z.infer<typeof createOrderReviewInputSchema>;

export const createOrderReviewOutputSchema = createOutputSchema();
export type CreateOrderReviewOutputSchema = z.infer<typeof createOrderReviewOutputSchema>;
