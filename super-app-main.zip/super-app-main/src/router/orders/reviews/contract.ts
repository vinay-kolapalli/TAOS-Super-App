import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { exportData } from "../contract";
import { exportDataInputSchema } from "../schema";
import {
  createOrderReviewInputSchema,
  createOrderReviewOutputSchema,
  getOrderReviewInputSchema,
  getOrderReviewOutputSchema,
} from "./schema";

const getOrderReview = oc
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.reviewDesk.read] })
  .input(getOrderReviewInputSchema)
  .output(getOrderReviewOutputSchema);

const createOrderReview = oc
  .meta({
    permission: [permissionsList.reviewDesk.write],
  })
  .input(createOrderReviewInputSchema)
  .output(createOrderReviewOutputSchema);

const exportReviews = exportData
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.reviewDesk.read] })
  .input(exportDataInputSchema);

export const contract = {
  list: getOrderReview,
  create: createOrderReview,
  export: exportReviews,
};
