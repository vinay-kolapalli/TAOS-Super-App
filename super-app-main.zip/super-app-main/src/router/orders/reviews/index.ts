import { orderFlowStatus } from "@/data/order-flow";
import { db } from "@/db";
import { orderFlows } from "@/db/schema/order-flow";
import { orderReviews } from "@/db/schema/review-desk";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { fetchAllData } from "@/db/utils/fetch";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { formatDate } from "@/utils/date";
import { implement, ORPCError } from "@orpc/server";
import { and, eq, gt, gte, inArray, lte } from "drizzle-orm";
import { contract } from "./contract";

const os = implement(contract);

const getOrderReview = os.list.use(authMiddleware).handler(async ({ input }) => {
  const reviews = await db.select().from(orderReviews).where(eq(orderReviews.orderNumber, input.orderNumber));
  return { message: "Reviews retrieved", data: reviews };
});

const createOrderReview = os.create.use(authMiddleware).handler(async ({ input, context }) => {
  const reviewedAt = new Date();

  const { error } = await tryCatch(
    db.transaction(async (tx) => {
      await tx
        .insert(orderFlows)
        .values({
          orderNumber: input.orderNumber,
          status: orderFlowStatus.reviewed,
          reviewedAt,
          warehouse: context.user.primaryWarehouse,
        })
        .onConflictDoUpdate({
          target: [orderFlows.orderNumber],
          set: {
            status: orderFlowStatus.reviewed,
            reviewedAt,
          },
        });

      await tx
        .insert(orderReviews)
        .values({ ...input, createdAt: reviewedAt, warehouse: context.user.primaryWarehouse });
    })
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to save review" }),
    });
  }

  return { message: "Review saved" };
});

const exportReviews = os.export.use(authMiddleware).handler(async ({ input, context }) => {
  const { from, to, warehouse } = input;
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses =
    warehouse && userWarehouses.includes(Number(warehouse)) ? [Number(warehouse)] : userWarehouses;

  if (!validWarehouses) {
    throw new ORPCError("FORBIDDEN", {
      message: "Access denied to warehouse",
    });
  }

  const response = await fetchAllData(undefined, async (cursor) => {
    return await db
      .select()
      .from(orderReviews)
      .where(
        and(
          gte(orderReviews.createdAt, from),
          lte(orderReviews.createdAt, to),
          cursor ? gt(orderReviews.id, cursor) : undefined,
          inArray(orderReviews.warehouse, validWarehouses)
        )
      );
  });
  const reviews = response.map((review) => ({
    ...review,
    createdAt: formatDate(review.createdAt),
  }));

  const csv = returnCsv(reviews);

  return { message: "Export completed", data: csv };
});

export const router = {
  list: getOrderReview,
  create: createOrderReview,
  export: exportReviews,
};
