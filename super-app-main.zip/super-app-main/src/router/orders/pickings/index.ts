import { orderFlowStatus } from "@/data/order-flow";
import { db } from "@/db";
import { orderFlows } from "@/db/schema/order-flow";
import { orderPickings } from "@/db/schema/pick-and-pack";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { fetchAllData } from "@/db/utils/fetch";
import { authMiddleware } from "@/lib/orpc/middleware";
import { getSignedUrl, uploadFile } from "@/lib/s3";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { formatDate } from "@/utils/date";
import { implement, ORPCError } from "@orpc/server";
import { and, eq, gt, gte, inArray, lte } from "drizzle-orm";
import { nanoid } from "nanoid";
import { contract } from "./contract";

const os = implement(contract);

const getOrderPickings = os.list.use(authMiddleware).handler(async ({ input }) => {
  const pickings = await db.select().from(orderPickings).where(eq(orderPickings.orderNumber, input.orderNumber));
  const result = pickings.map((picking) => ({
    ...picking,
    image: picking.image ? getSignedUrl(picking.image) : null,
  }));

  return { message: "Pickings retrieved", data: result };
});

const createPicking = os.create.use(authMiddleware).handler(async ({ input, context }) => {
  const fileKey = `order-pickings/${input.orderNumber}-${nanoid(5)}.png`;
  const status = input.type === "plants" ? orderFlowStatus.plantsPicked : orderFlowStatus.othersPicked;
  const plantsPickedAt = input.type === "plants" ? new Date() : undefined;
  const othersPickedAt = input.type === "other" ? new Date() : undefined;

  const { error } = await tryCatch(
    db.transaction(async (tx) => {
      await tx
        .insert(orderFlows)
        .values({
          status,
          orderNumber: input.orderNumber,
          plantsPickedAt,
          othersPickedAt,
          warehouse: context.user.primaryWarehouse,
        })
        .onConflictDoUpdate({
          target: [orderFlows.orderNumber],
          set: {
            status,
            plantsPickedAt,
            othersPickedAt,
          },
        });

      await tx.insert(orderPickings).values({
        employee: input.employee,
        orderNumber: input.orderNumber,
        image: input.image ? fileKey : null,
        type: input.type,
        warehouse: context.user.primaryWarehouse,
      });
    })
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to save picking record" }),
    });
  }

  // Upload image
  if (input.image) {
    const response = await fetch(input.image);
    if (!response.ok) {
      throw new ORPCError("INTERNAL_SERVER_ERROR", {
        message: "Unable to process image",
      });
    }
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    await uploadFile({
      contentType: "image/webp",
      file: buffer,
      key: fileKey,
    });
  }

  return { message: "Picking recorded successfully" };
});

const exportPickings = os.export.use(authMiddleware).handler(async ({ input, context }) => {
  const { from, to, type, warehouse } = input;
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses =
    warehouse && userWarehouses.includes(Number(warehouse)) ? [Number(warehouse)] : userWarehouses;

  if (!validWarehouses) {
    throw new ORPCError("FORBIDDEN", {
      message: "Access denied to warehouse",
    });
  }

  const response = await fetchAllData(undefined, async (cursor) => {
    return await db
      .select()
      .from(orderPickings)
      .where(
        and(
          gte(orderPickings.createdAt, from),
          lte(orderPickings.createdAt, to),
          eq(orderPickings.type, type),
          cursor ? gt(orderPickings.id, cursor) : undefined,
          inArray(orderPickings.warehouse, validWarehouses)
        )
      );
  });

  const pickings = response.map((picking) => ({
    ...picking,
    image: picking.image ? String(new URL(picking.image, process.env.NEXT_PUBLIC_CLOUDFLARE_R2_ENDPOINT)) : "",
    createdAt: formatDate(picking.createdAt),
  }));

  const csv = returnCsv(pickings);

  return { message: "Export completed", data: csv };
});

export const router = {
  list: getOrderPickings,
  create: createPicking,
  export: exportPickings,
};
