import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { exportData } from "../contract";
import {
  createPickingInputSchema,
  createPickingOutputSchema,
  exportPickingInputSchema,
  getOrderPickingsInputSchema,
  getOrderPickingsOutputSchema,
} from "./schema";

const getOrderPickings = oc
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.orderPicking.read] })
  .input(getOrderPickingsInputSchema)
  .output(getOrderPickingsOutputSchema);

const createPicking = oc
  .meta({ permission: [permissionsList.orderPicking.write] })
  .input(createPickingInputSchema)
  .output(createPickingOutputSchema);

const exportPickings = exportData
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.orderPicking.read] })
  .input(exportPickingInputSchema);

export const contract = {
  list: getOrderPickings,
  create: createPicking,
  export: exportPickings,
};
