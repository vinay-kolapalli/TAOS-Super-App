import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";
import { exportDataInputSchema } from "../schema";

export const getOrderPickingsInputSchema = z.object({
  orderNumber: z.number(),
});
export type GetOrderPickingsInputSchema = z.infer<typeof getOrderPickingsInputSchema>;

export const getOrderPickingsOutputSchema = createOutputSchema(
  z.array(
    z.object({
      id: z.string(),
      createdAt: z.date(),
      orderNumber: z.number(),
      type: z.string(),
      employee: z.string(),
      image: z.string().nullable(),
      warehouse: z.number(),
    })
  )
);
export type GetOrderPickingsOutputSchema = z.infer<typeof getOrderPickingsOutputSchema>;

export const createPickingInputSchema = z.object({
  orderNumber: z.number(),
  type: z.enum(["plants", "other"]),
  image: z.string().nullable().optional(),
  employee: z.string(),
});
export type CreatePickingInputSchema = z.infer<typeof createPickingInputSchema>;

export const createPickingOutputSchema = createOutputSchema();
export type CreatePickingOutputSchema = z.infer<typeof createPickingOutputSchema>;

export const exportPickingInputSchema = exportDataInputSchema.extend({
  type: z.enum(["plants", "other"]),
});
export type ExportPickingInputSchema = z.infer<typeof exportPickingInputSchema>;

export const exportPickingOutputSchema = createOutputSchema(z.string());
export type ExportPickingOutputSchema = z.infer<typeof exportPickingOutputSchema>;
