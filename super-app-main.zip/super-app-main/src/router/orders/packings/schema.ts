import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export const getOrderPackingsInputSchema = z.object({
  orderNumber: z.number(),
});
export type GetOrderPackingsInputSchema = z.infer<typeof getOrderPackingsInputSchema>;

export const getOrderPackingsOutputSchema = createOutputSchema(
  z.array(
    z.object({
      id: z.string(),
      createdAt: z.date(),
      employee: z.string(),
      orderNumber: z.number(),
      warehouse: z.number(),
    })
  )
);
export type GetOrderPackingsOutputSchema = z.infer<typeof getOrderPackingsOutputSchema>;

export const createPackingInputSchema = z.object({
  employee: z.string(),
  orderNumber: z.number(),
});
export type CreatePackingInputSchema = z.infer<typeof createPackingInputSchema>;

export const createPackingOutputSchema = createOutputSchema();
export type CreatePackingOutputSchema = z.infer<typeof createPackingOutputSchema>;
