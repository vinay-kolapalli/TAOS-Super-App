import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { exportData } from "../contract";
import { exportDataInputSchema } from "../schema";
import {
  createPackingInputSchema,
  createPackingOutputSchema,
  getOrderPackingsInputSchema,
  getOrderPackingsOutputSchema,
} from "./schema";

const getOrderPackings = oc
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.orderPacking.read] })
  .input(getOrderPackingsInputSchema)
  .output(getOrderPackingsOutputSchema);

const createPacking = oc
  .meta({ permission: [permissionsList.orderPacking.write] })
  .input(createPackingInputSchema)
  .output(createPackingOutputSchema);

const exportPackings = exportData
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.orderPacking.read] })
  .input(exportDataInputSchema);

export const contract = {
  list: getOrderPackings,
  create: createPacking,
  export: exportPackings,
};
