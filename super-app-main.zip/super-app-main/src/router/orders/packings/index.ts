import { orderFlowStatus } from "@/data/order-flow";
import { db } from "@/db";
import { orderFlows } from "@/db/schema/order-flow";
import { orderPackings } from "@/db/schema/pick-and-pack";
import { orderReviews } from "@/db/schema/review-desk";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { fetchAllData } from "@/db/utils/fetch";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { formatDate } from "@/utils/date";
import { implement, ORPCError } from "@orpc/server";
import { and, eq, gt, gte, inArray, lte } from "drizzle-orm";
import { contract } from "./contract";

const os = implement(contract);

const getOrderPackings = os.list.use(authMiddleware).handler(async ({ input }) => {
  const packings = await db.select().from(orderPackings).where(eq(orderPackings.orderNumber, input.orderNumber));
  return { message: "Packings retrieved", data: packings };
});

const createPacking = os.create.use(authMiddleware).handler(async ({ input, context }) => {
  const packedAt = new Date();

  const { error } = await tryCatch(
    db.transaction(async (tx) => {
      await tx
        .insert(orderFlows)
        .values({
          status: orderFlowStatus.packed,
          orderNumber: input.orderNumber,
          packedAt,
          warehouse: context.user.primaryWarehouse,
        })
        .onConflictDoUpdate({
          target: [orderFlows.orderNumber],
          set: {
            status: orderFlowStatus.packed,
            packedAt,
          },
        });

      await tx.insert(orderPackings).values({
        employee: input.employee,
        orderNumber: input.orderNumber,
        createdAt: packedAt,
        warehouse: context.user.primaryWarehouse,
      });
    })
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to save packing record" }),
    });
  }

  return { message: "Packing recorded successfully" };
});

const exportPackings = os.export.use(authMiddleware).handler(async ({ input, context }) => {
  const { from, to, warehouse } = input;
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses =
    warehouse && userWarehouses.includes(Number(warehouse)) ? [Number(warehouse)] : userWarehouses;

  if (!validWarehouses) {
    throw new ORPCError("FORBIDDEN", {
      message: "Access denied to warehouse",
    });
  }

  const response = await fetchAllData(undefined, async (cursor) => {
    return await db
      .select()
      .from(orderPackings)
      .where(
        and(
          gte(orderPackings.createdAt, from),
          lte(orderPackings.createdAt, to),
          cursor ? gt(orderReviews.id, cursor) : undefined,
          inArray(orderPackings.warehouse, validWarehouses)
        )
      );
  });

  const packings = response.map((packing) => ({
    ...packing,
    createdAt: formatDate(packing.createdAt),
  }));

  const csv = returnCsv(packings);

  return { message: "Export completed", data: csv };
});

export const router = {
  list: getOrderPackings,
  create: createPacking,
  export: exportPackings,
};
