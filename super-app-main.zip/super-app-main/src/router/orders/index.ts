import { orderFlowStatus } from "@/data/order-flow";
import { db } from "@/db";
import { orderShipmentRates, orderShipments } from "@/db/schema/courier-checker";
import { orderFlows } from "@/db/schema/order-flow";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { authMiddleware } from "@/lib/orpc/middleware";
import { convertShopifyIdToGid } from "@/lib/shopify";
import { cancelFulfillment, createFulfillment, getOrderFulfillmentDetails } from "@/lib/shopify/fulfillment";
import { updateOrder as updateShopifyOrder } from "@/lib/shopify/orders";
import { tryCatch } from "@/lib/try-catch";
import { getTrackingUrl } from "@/utils/tracking";
import { implement, ORPCError } from "@orpc/server";
import { eq } from "drizzle-orm";
import { contract } from "./contract";
import * as packing from "./packings";
import * as picking from "./pickings";
import * as reviews from "./reviews";
import * as shipments from "./shipments";

const os = implement(contract);

const shipOrder = os.ship.use(authMiddleware).handler(async ({ input, context }) => {
  const courierCheckedAt = new Date();

  const usedRate = input.rates.find((rate) => rate.priority === input.priority);
  if (!usedRate) throw new ORPCError("BAD_REQUEST", { message: "Selected shipping rate not found" });

  // Cancel the closed fulfillment order if the order is reshipped
  if (input.isReshipped) {
    const order = await getOrderFulfillmentDetails(convertShopifyIdToGid(input.orderId, "Order"));
    const closedFulfillmentId = order.fulfillments[0]?.id;
    if (closedFulfillmentId) {
      await cancelFulfillment(closedFulfillmentId);
    }
  }

  // Get the open fulfillment order
  const order = await getOrderFulfillmentDetails(convertShopifyIdToGid(input.orderId, "Order"));
  const openFulfillmentOrders = order.fulfillmentOrders.edges.filter(
    (fulfillmentOrder) => fulfillmentOrder.node.status === "OPEN"
  );
  const openFulfillmentOrderId = openFulfillmentOrders?.[0]?.node.id;
  if (!openFulfillmentOrderId)
    throw new ORPCError("BAD_REQUEST", { message: "No open fulfillment orders found for this order" });

  const existingFilteredTags = order.tags.filter((tag) => !tag.startsWith("status:"));

  await createFulfillment({
    fulfillmentOrderId: openFulfillmentOrderId,
    fulfillmentOrderLineItems: [],
    notifyCustomer: true,
    trackingInfo: {
      company: usedRate.courier,
      number: input.trackingNumber,
      url: getTrackingUrl(usedRate.courier, input.trackingNumber),
    },
  });

  // Update the order with tags and metafields
  await updateShopifyOrder({
    id: convertShopifyIdToGid(input.orderId, "Order"),
    tags: [...existingFilteredTags, input.isReshipped ? "status:reshipped" : "status:shipped"],
    metafields: [
      {
        key: "taos_packed_by",
        value: input.packedBy,
        namespace: "taos_super_app",
        type: "single_line_text_field",
      },
      {
        key: "taos_scanned_by",
        value: input.scannedBy,
        namespace: "taos_super_app",
        type: "single_line_text_field",
      },
      {
        key: "taos_weight",
        value: String(input.weight),
        namespace: "taos_super_app",
        type: "single_line_text_field",
      },
      {
        key: "taos_box_type",
        value: input.box,
        type: "single_line_text_field",
      },
      {
        key: "taos_tracking_number",
        value: input.trackingNumber,
        namespace: "taos_super_app",
        type: "single_line_text_field",
      },
      {
        key: "taos_reshipped",
        value: String(input.isReshipped),
        namespace: "taos_super_app",
        type: "single_line_text_field",
      },
      {
        key: "taos_courier_id",
        value: usedRate.courier,
        namespace: "taos_super_app",
        type: "single_line_text_field",
      },
      {
        key: "taos_shipped_at",
        value: courierCheckedAt.toISOString(),
        namespace: "taos_super_app",
        type: "single_line_text_field",
      },
    ],
  });

  const { error } = await tryCatch(
    db.transaction(async (tx) => {
      await tx
        .insert(orderFlows)
        .values({
          status: orderFlowStatus.courierChecked,
          orderNumber: input.orderNumber,
          courierCheckedAt,
          warehouse: context.user.primaryWarehouse,
        })
        .onConflictDoUpdate({
          target: [orderFlows.orderNumber],
          set: {
            status: orderFlowStatus.courierChecked,
            courierCheckedAt,
          },
        });

      const [orderShipment] = await tx
        .insert(orderShipments)
        .values({
          createdAt: courierCheckedAt,
          orderId: input.orderId,
          orderNumber: input.orderNumber,
          trackingNumber: input.trackingNumber,
          weight: input.weight * 1000,
          box: input.box,
          packedBy: input.packedBy,
          scannedBy: input.scannedBy,
          rate: null,
          pincode: input.pincode,
          isReshipped: input.isReshipped,
          nonPriorityReason: input.nonPriorityReason ? input.nonPriorityReason : undefined,
          warehouse: context.user.primaryWarehouse,
        })
        .returning({ id: orderShipments.id });

      const rates = await tx
        .insert(orderShipmentRates)
        .values(input.rates.map((rate) => ({ ...rate, orderShipment: orderShipment.id })))
        .returning({ id: orderShipmentRates.id, priority: orderShipmentRates.priority });

      const rateId = rates.find((r) => r.priority === input.priority)?.id;
      if (!rateId) {
        throw new ORPCError("INTERNAL_SERVER_ERROR", { message: "Unable to save shipping rate" });
      }

      await tx.update(orderShipments).set({ rate: rateId }).where(eq(orderShipments.id, orderShipment.id));
    })
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to save shipment details" }),
    });
  }

  return { message: "Order shipped successfully" };
});

export const router = {
  ship: shipOrder,
  pickings: picking.router,
  packings: packing.router,
  reviews: reviews.router,
  shipments: shipments.router,
};
