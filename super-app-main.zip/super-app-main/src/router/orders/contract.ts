import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { exportDataOutputSchema, shipOrderInputSchema, shipOrderOutputSchema } from "./schema";

const shipOrder = oc
  .meta({ permission: [permissionsList.courierChecker.write] })
  .input(shipOrderInputSchema)
  .output(shipOrderOutputSchema);

export const exportData = oc.output(exportDataOutputSchema);

export const contract = {
  ship: shipOrder,
  export: exportData,
};
