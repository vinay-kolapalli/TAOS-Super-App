import { db } from "@/db";
import { inboundInventoryRecords } from "@/db/schema/records";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { fetchAllData } from "@/db/utils/fetch";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { formatDate } from "@/utils/date";
import { implement, ORPCError } from "@orpc/server";
import { and, eq, gt, gte, lte } from "drizzle-orm";
import { contract } from "./contract";

const os = implement(contract);

const createRecord = os.create.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(db.insert(inboundInventoryRecords).values(input));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to create inbound inventory record" }),
    });
  }

  return { message: "Inbound inventory record created" };
});

const updateRecord = os.update.use(authMiddleware).handler(async ({ input }) => {
  const { id, ...rest } = input;
  const { error } = await tryCatch(
    db.update(inboundInventoryRecords).set(rest).where(eq(inboundInventoryRecords.id, id))
  );
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to update inbound inventory record" }),
    });
  }

  return { message: "Inbound inventory record updated" };
});

const deleteRecord = os.delete.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(db.delete(inboundInventoryRecords).where(eq(inboundInventoryRecords.id, input.id)));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to delete inbound inventory record" }),
    });
  }

  return { message: "Inbound inventory record deleted" };
});

const exportRecords = os.export.use(authMiddleware).handler(async ({ input }) => {
  const response = await fetchAllData(undefined, async (cursor) => {
    return await db.query.inboundInventoryRecords.findMany({
      with: {
        product: {
          columns: {
            name: true,
          },
        },
      },
      where: and(
        gte(inboundInventoryRecords.date, input.from),
        lte(inboundInventoryRecords.date, input.to),
        cursor ? gt(inboundInventoryRecords.id, cursor) : undefined
      ),
    });
  });

  const records = response.map((record) => ({
    date: formatDate(record.date),
    name: record.name,
    email: record.email,
    product: record.product.name,
    poNumber: record.poNumber,
    quantityOrdered: record.quantityOrdered,
    quantityReceived: record.quantityReceived,
    quantityUpdated: record.quantityUpdated,
    reason: record.reason,
    comments: record.comments,
  }));

  const csv = returnCsv(records);

  return { message: "Export completed", data: csv };
});

export const router = {
  create: createRecord,
  update: updateRecord,
  delete: deleteRecord,
  export: exportRecords,
};
