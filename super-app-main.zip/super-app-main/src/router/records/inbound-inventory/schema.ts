import { createOutputSchema } from "@/lib/orpc/contract";
import { getEndOfDay, getStartOfDay } from "@/utils/date";
import z from "zod";

export const createRecordInputSchema = z.object({
  id: z.string().optional(),
  date: z.date(),
  name: z.string(),
  email: z.string(),
  product: z.coerce.number<number>(),
  poNumber: z.string(),
  quantityOrdered: z.number(),
  quantityReceived: z.number(),
  quantityUpdated: z.number(),
  reason: z.string(),
  comments: z.string(),
});
export type CreateRecordInputSchema = z.infer<typeof createRecordInputSchema>;

export const createRecordOutputSchema = createOutputSchema();
export type CreateRecordOutputSchema = z.infer<typeof createRecordOutputSchema>;

export const updateRecordInputSchema = createRecordInputSchema.extend({
  id: z.string(),
});
export type UpdateRecordInputSchema = z.infer<typeof updateRecordInputSchema>;

export const updateRecordOutputSchema = createOutputSchema();
export type UpdateRecordOutputSchema = z.infer<typeof updateRecordOutputSchema>;

export const deleteRecordInputSchema = z.object({
  id: z.string(),
});
export type DeleteRecordInputSchema = z.infer<typeof deleteRecordInputSchema>;

export const deleteRecordOutputSchema = createOutputSchema();
export type DeleteRecordOutputSchema = z.infer<typeof deleteRecordOutputSchema>;

export const exportRecordsInputSchema = z.object({
  from: z.date().transform((val) => getStartOfDay(val)),
  to: z.date().transform((val) => getEndOfDay(val)),
});
export type ExportRecordsInputSchema = z.infer<typeof exportRecordsInputSchema>;

export const exportRecordsOutputSchema = createOutputSchema(z.string());
export type ExportRecordsOutputSchema = z.infer<typeof exportRecordsOutputSchema>;
