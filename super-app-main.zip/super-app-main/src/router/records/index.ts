import * as damagedProducts from "./damaged-products";
import * as inboundInventory from "./inbound-inventory";
import * as offlineSales from "./offline-sales";
import * as recoveredProducts from "./recovered-products";
import * as seedsBundling from "./seeds-bundling";

export const router = {
  seedsBundling: seedsBundling.router,
  damagedProducts: damagedProducts.router,
  inboundInventory: inboundInventory.router,
  offlineSales: offlineSales.router,
  recoveredProducts: recoveredProducts.router,
};
