import { db } from "@/db";
import { recoveredProductsRecords } from "@/db/schema/records";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { fetchAllData } from "@/db/utils/fetch";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { formatDate } from "@/utils/date";
import { implement, ORPCError } from "@orpc/server";
import { and, eq, gt, gte, lte } from "drizzle-orm";
import { contract } from "./contract";

const os = implement(contract);

const createRecord = os.create.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(db.insert(recoveredProductsRecords).values(input));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to create recovered product record" }),
    });
  }

  return { message: "Recovered product record created" };
});

const updateRecord = os.update.use(authMiddleware).handler(async ({ input }) => {
  const { id, ...rest } = input;
  const { error } = await tryCatch(
    db.update(recoveredProductsRecords).set(rest).where(eq(recoveredProductsRecords.id, id))
  );
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to update recovered product record" }),
    });
  }

  return { message: "Recovered product record updated" };
});

const deleteRecord = os.delete.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(
    db.delete(recoveredProductsRecords).where(eq(recoveredProductsRecords.id, input.id))
  );
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to delete recovered product record" }),
    });
  }

  return { message: "Recovered product record deleted" };
});

const exportRecords = os.export.use(authMiddleware).handler(async ({ input }) => {
  const response = await fetchAllData(undefined, async (cursor) => {
    return await db.query.recoveredProductsRecords.findMany({
      with: {
        product: {
          columns: {
            name: true,
          },
        },
      },
      where: and(
        gte(recoveredProductsRecords.date, input.from),
        lte(recoveredProductsRecords.date, input.to),
        cursor ? gt(recoveredProductsRecords.id, cursor) : undefined
      ),
    });
  });

  const records = response.map((record) => ({
    date: formatDate(record.date),
    name: record.name,
    email: record.email,
    product: record.product.name,
    quantity: record.quantity,
    comments: record.comments,
  }));

  const csv = returnCsv(records);

  return { message: "Export completed", data: csv };
});

export const router = {
  create: createRecord,
  update: updateRecord,
  delete: deleteRecord,
  export: exportRecords,
};
