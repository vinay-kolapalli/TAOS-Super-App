import { db } from "@/db";
import { seedsBundlingRecords } from "@/db/schema/records";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { fetchAllData } from "@/db/utils/fetch";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { returnCsv } from "@/utils/csv";
import { formatDate } from "@/utils/date";
import { implement, ORPCError } from "@orpc/server";
import { and, eq, gt, gte, lte } from "drizzle-orm";
import { contract } from "./contract";

const os = implement(contract);

const createRecord = os.create.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(db.insert(seedsBundlingRecords).values({ ...input, weight: input.weight * 1000 }));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to create seeds bundling record" }),
    });
  }

  return { message: "Seeds bundling record created" };
});

const updateRecord = os.update.use(authMiddleware).handler(async ({ input }) => {
  const { id, ...rest } = input;
  const { error } = await tryCatch(
    db
      .update(seedsBundlingRecords)
      .set({ ...rest, weight: rest.weight * 1000 })
      .where(eq(seedsBundlingRecords.id, id))
  );
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to update seeds bundling record" }),
    });
  }

  return { message: "Seeds bundling record updated" };
});

const deleteRecord = os.delete.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(db.delete(seedsBundlingRecords).where(eq(seedsBundlingRecords.id, input.id)));
  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, { fallback: "Unable to delete seeds bundling record" }),
    });
  }

  return { message: "Seeds bundling record deleted" };
});

const exportRecords = os.export.use(authMiddleware).handler(async ({ input }) => {
  const response = await fetchAllData(undefined, async (cursor) => {
    return await db.query.seedsBundlingRecords.findMany({
      with: {
        product: {
          columns: {
            name: true,
          },
        },
      },
      where: and(
        gte(seedsBundlingRecords.date, input.from),
        lte(seedsBundlingRecords.date, input.to),
        cursor ? gt(seedsBundlingRecords.id, cursor) : undefined
      ),
    });
  });

  const records = response.map((record) => ({
    date: formatDate(record.date),
    product: record.product.name,
    issuedTo: record.issuedTo,
    issuedDate: formatDate(record.issuedDate),
    weight: record.weight / 1000,
    returnDate: formatDate(record.returnDate),
    noOfPackets: record.noOfPackets,
  }));

  const csv = returnCsv(records);

  return { message: "Export completed", data: csv };
});

export const router = {
  create: createRecord,
  update: updateRecord,
  delete: deleteRecord,
  export: exportRecords,
};
