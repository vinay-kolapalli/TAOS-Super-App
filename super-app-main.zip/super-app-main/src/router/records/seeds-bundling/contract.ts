import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import {
  createRecordInputSchema,
  createRecordOutputSchema,
  deleteRecordInputSchema,
  deleteRecordOutputSchema,
  exportRecordsInputSchema,
  exportRecordsOutputSchema,
  updateRecordInputSchema,
  updateRecordOutputSchema,
} from "./schema";

const createRecord = oc
  .meta({ permission: [permissionsList.seedsBundlingRecords.write] })
  .input(createRecordInputSchema)
  .output(createRecordOutputSchema);

const updateRecord = oc
  .meta({ permission: [permissionsList.seedsBundlingRecords.write] })
  .input(updateRecordInputSchema)
  .output(updateRecordOutputSchema);

const deleteRecord = oc
  .meta({
    permission: [permissionsList.seedsBundlingRecords.write],
  })
  .input(deleteRecordInputSchema)
  .output(deleteRecordOutputSchema);

const exportRecords = oc
  .meta({
    permission: [permissionsList.seedsBundlingRecords.read],
  })
  .input(exportRecordsInputSchema)
  .output(exportRecordsOutputSchema);

export const contract = {
  create: createRecord,
  update: updateRecord,
  delete: deleteRecord,
  export: exportRecords,
};
