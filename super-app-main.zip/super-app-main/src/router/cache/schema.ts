import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export const clearCacheOutputSchema = createOutputSchema(
  z.object({
    revalidated: z.boolean(),
    message: z.string(),
    timestamp: z.string(),
  })
);
