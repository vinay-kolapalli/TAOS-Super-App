import { oc } from "@/lib/orpc/contract";
import { clearCacheOutputSchema } from "./schema";

const clearCache = oc.output(clearCacheOutputSchema);

export const contract = {
  clearCache,
};
