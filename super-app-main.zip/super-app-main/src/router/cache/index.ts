import { authMiddleware } from "@/lib/orpc/middleware";
import { implement } from "@orpc/server";
import { revalidateTag } from "next/cache";
import { contract } from "./contract";

const os = implement(contract);

const clearCache = os.clearCache.use(authMiddleware).handler(async () => {
  revalidateTag("api-access-token");

  return {
    message: "Cache cleared",
    data: { revalidated: true, message: "Cache revalidated", timestamp: new Date().toISOString() },
  };
});

export const router = {
  clearCache,
};
