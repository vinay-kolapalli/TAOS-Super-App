import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import {
  deletePincodesByCourierInputSchema,
  deletePincodesByCourierOutputSchema,
  deletePincodesInputSchema,
  deletePincodesOutputSchema,
  getPincodesReportInputSchema,
  getPincodesReportOutputSchema,
  upsertPincodeOutputSchema,
  upsertPincodesInputSchema,
} from "./schema";

export const upsertPincodes = oc
  .meta({ permission: [permissionsList.pincodes.write] })
  .input(upsertPincodesInputSchema)
  .output(upsertPincodeOutputSchema);

export const deletePincodesByCourier = oc
  .meta({ permission: [permissionsList.pincodes.write] })
  .input(deletePincodesByCourierInputSchema)
  .output(deletePincodesByCourierOutputSchema);

export const deletePincodes = oc
  .meta({ permission: [permissionsList.pincodes.write] })
  .input(deletePincodesInputSchema)
  .output(deletePincodesOutputSchema);

const getPincodesReport = oc
  .meta({ permission: [permissionsList.orderFlow.read, permissionsList.pincodes.read] })
  .input(getPincodesReportInputSchema)
  .output(getPincodesReportOutputSchema);

export const contract = {
  create: upsertPincodes,
  update: upsertPincodes,
  delete: deletePincodes,
  deleteCourier: deletePincodesByCourier,
  report: getPincodesReport,
};
