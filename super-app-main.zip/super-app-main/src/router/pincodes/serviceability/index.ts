import { db } from "@/db";
import { getWarehouse } from "@/db/utils/warehouse";
import { authMiddleware } from "@/lib/orpc/middleware";
import { implement } from "@orpc/server";
import { contract } from "./contract";
import {
  checkAmazonServiceability,
  checkDelhiveryServiceability,
  checkFshipServiceability,
  checkIThinkLogisticsServiceability,
  checkPincodeServiceability as checkPincodeServiceabilityUtils,
  checkShiphereServiceability,
  checkShiprocketServiceability,
  checkShipwayServiceability,
  CourierInfo,
  getAlwaysAvailableCouriers,
} from "./utils";

const os = implement(contract);

const checkPincodeServiceability = os.check.use(authMiddleware).handler(async ({ input, context }) => {
  const warehouse = await getWarehouse(context.user.primaryWarehouse);
  const couriersResponse = await db.query.couriers.findMany({
    columns: {
      id: true,
      name: true,
      image: true,
      services: true,
      serviceabilityCheck: true,
    },
    where: (fields, operators) => operators.eq(fields.isActive, true),
    limit: 500,
  });

  // Create sets for faster lookups
  const availableCourierSet = new Set(warehouse.availableCouriers);
  const availablePlatformSet = new Set(warehouse.availablePlatforms);

  const couriersData = couriersResponse.filter((c) => availableCourierSet.has(c.id));

  // Pre-filter platform couriers once
  const platformCouriers = couriersData.filter((courier) => courier.serviceabilityCheck.includes("platform"));

  // Create platform availability map once
  const platformAvailability = {
    shipway: availablePlatformSet.has("shipway"),
    shiprocket: availablePlatformSet.has("shiprocket"),
    delhivery: availablePlatformSet.has("delhivery"),
    shiphere: availablePlatformSet.has("shiphere"),
    fship: availablePlatformSet.has("fship"),
    ithinkLogistics: availablePlatformSet.has("ithink-logistics"),
    amazon: availablePlatformSet.has("amazon"),
  };

  const [
    pincodeServiceableCouriers,
    shipwayServiceableCouriers,
    shiprocketServiceableCouriers,
    delhiveryServiceableCouriers,
    shiphereServiceableCouriers,
    fshipServiceableCouriers,
    ithinkLogisticsServiceableCouriers,
    amazonServiceableCouriers,
  ] = await Promise.all([
    checkPincodeServiceabilityUtils(input.pincode, couriersData),
    platformAvailability.shipway ? checkShipwayServiceability(input.pincode, platformCouriers) : [],
    platformAvailability.shiprocket ? checkShiprocketServiceability(input.pincode, platformCouriers) : [],
    platformAvailability.delhivery ? checkDelhiveryServiceability(input.pincode, platformCouriers) : [],
    platformAvailability.shiphere ? checkShiphereServiceability(input.pincode, platformCouriers) : [],
    platformAvailability.fship ? checkFshipServiceability(input.pincode, platformCouriers) : [],
    platformAvailability.ithinkLogistics ? checkIThinkLogisticsServiceability(input.pincode, platformCouriers) : [],
    platformAvailability.amazon ? checkAmazonServiceability(input.pincode, platformCouriers) : [],
  ]);

  const alwaysAvailableCouriers = getAlwaysAvailableCouriers(couriersData);

  // Create sets for faster lookups
  const shipwayCourierIds = new Set(shipwayServiceableCouriers.map((c) => c.id));
  const shiprocketCourierIds = new Set(shiprocketServiceableCouriers.map((c) => c.id));

  // Optimize shiphere and fship filtering using sets for O(1) lookups
  const filteredShiphereCouriers = shiphereServiceableCouriers.filter(
    (shiphereCourier) => shipwayCourierIds.has(shiphereCourier.id) || shiprocketCourierIds.has(shiphereCourier.id)
  );

  const filteredFshipCouriers = fshipServiceableCouriers.filter(
    (fshipCourier) => shipwayCourierIds.has(fshipCourier.id) || shiprocketCourierIds.has(fshipCourier.id)
  );

  const filteredAmazonCouriers = amazonServiceableCouriers.filter(
    (amazonCourier) => shipwayCourierIds.has(amazonCourier.id) || shiprocketCourierIds.has(amazonCourier.id)
  );

  const allServiceableCouriers: CourierInfo[] = [
    ...pincodeServiceableCouriers,
    ...shipwayServiceableCouriers,
    ...shiprocketServiceableCouriers,
    ...delhiveryServiceableCouriers,
    ...alwaysAvailableCouriers,
    ...filteredShiphereCouriers,
    ...filteredFshipCouriers,
    ...ithinkLogisticsServiceableCouriers,
    ...filteredAmazonCouriers,
  ];

  return {
    message: "Pincode serviceability checked",
    data: {
      pincode: input.pincode,
      couriers: allServiceableCouriers,
    },
  };
});

export const router = {
  check: checkPincodeServiceability,
};
