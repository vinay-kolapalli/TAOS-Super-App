import { db } from "@/db";
import { Courier } from "@/db/types";
import { logger } from "@/lib/logging/server";
import { checkDelhiveryPincodeServiceability } from "@/lib/shipping/delhivery";
import { fshipCourierIds } from "@/lib/shipping/fship";
import { checkIThinkLogisticsPincodeServiceability } from "@/lib/shipping/ithink-logistics";
import { shiphereCourierIds } from "@/lib/shipping/shiphere";
import { checkShiprocketPincodeServiceability } from "@/lib/shipping/shiprocket";
import { checkShipwayPincodeServiceability } from "@/lib/shipping/shipway";
import { tryCatch } from "@/lib/try-catch";
import Fuse from "fuse.js";
import { CheckPincodeServiceabilityOutputSchema } from "./schema";

export type CourierInfo = CheckPincodeServiceabilityOutputSchema["data"]["couriers"][number];
export type PartialCourier = Pick<Courier, "id" | "name" | "image" | "services" | "serviceabilityCheck">;

export async function checkShipwayServiceability(
  pincode: number,
  platformCouriers: PartialCourier[]
): Promise<CourierInfo[]> {
  const response = await tryCatch(checkShipwayPincodeServiceability(pincode));
  if (response.error) {
    logger.error("checkShipwayServiceability", { input: { pincode, platformCouriers }, error: response.error });
    return [];
  }
  logger.info("checkShipwayServiceability", { input: { pincode, platformCouriers }, response: response.data });
  const filteredResponse = response.data.message.filter((c) => c.payment_type === "P");

  const fuse = new Fuse(filteredResponse, {
    keys: ["name", "carrier_title"],
    threshold: 0.3,
    includeScore: true,
  });

  const serviceableCouriers: CourierInfo[] = [];

  for (const courier of platformCouriers) {
    const searchResults = fuse.search(courier.name);

    if (searchResults.length > 0 && searchResults[0].score! < 0.5) {
      const matchedCouriers: CourierInfo[] = searchResults.map((result) => ({
        id: courier.id,
        name: courier.name,
        image: courier.image,
        platform: "shipway",
        platformId: result.item.carrier_id,
        service: "surface",
      }));
      serviceableCouriers.push(...matchedCouriers);
    }
  }

  return serviceableCouriers;
}

export async function checkShiprocketServiceability(
  pincode: number,
  platformCouriers: PartialCourier[]
): Promise<CourierInfo[]> {
  const response = await tryCatch(
    checkShiprocketPincodeServiceability({
      pickup_postcode: pincode,
      delivery_postcode: pincode,
      cod: 0,
      weight: "0.5",
    })
  );
  if (response.error) {
    logger.error("checkShiprocketServiceability", { input: { pincode, platformCouriers }, error: response.error });
    return [];
  }
  logger.info("checkShiprocketServiceability", { input: { pincode, platformCouriers }, response: response.data });

  const fuse = new Fuse(response.data.data.available_courier_companies, {
    keys: ["courier_name"],
    threshold: 0.3,
    includeScore: true,
  });

  const serviceableCouriers: CourierInfo[] = [];

  for (const courier of platformCouriers) {
    const searchResults = fuse.search(courier.name);
    if (searchResults.length > 0 && searchResults[0].score! < 0.5) {
      const matchedCouriers: CourierInfo[] = searchResults.map((result) => ({
        id: courier.id,
        name: courier.name,
        image: courier.image,
        platform: "shiprocket",
        platformId: String(result.item.courier_company_id),
        service: result.item.is_surface ? "surface" : "air",
      }));
      serviceableCouriers.push(...matchedCouriers);
    }
  }

  return serviceableCouriers;
}

export async function checkShiphereServiceability(
  pincode: number,
  platformCouriers: PartialCourier[]
): Promise<CourierInfo[]> {
  const serviceableCouriers: CourierInfo[] = [];

  const fuse = new Fuse(platformCouriers, {
    keys: ["id", "name"],
    threshold: 0.3,
    includeScore: true,
  });

  // Find Delhivery courier
  const delhiveryResults = fuse.search("delhivery");
  const delhiveryCourier =
    delhiveryResults.length > 0 && delhiveryResults[0].score! < 0.5
      ? {
          id: delhiveryResults[0].item.id,
          name: delhiveryResults[0].item.name,
          image: delhiveryResults[0].item.image,
          platform: "shiphere" as const,
          service: "surface" as const,
        }
      : null;

  // Find Amazon courier
  const amazonResults = fuse.search("amazon");
  const amazonCourier =
    amazonResults.length > 0 && amazonResults[0].score! < 0.5
      ? {
          id: amazonResults[0].item.id,
          name: amazonResults[0].item.name,
          image: amazonResults[0].item.image,
          platform: "shiphere" as const,
          service: "surface" as const,
        }
      : null;

  // Find Ekart courier
  const ekartResults = fuse.search("ekart");
  const ekartCourier =
    ekartResults.length > 0 && ekartResults[0].score! < 0.5
      ? {
          id: ekartResults[0].item.id,
          name: ekartResults[0].item.name,
          image: ekartResults[0].item.image,
          platform: "shiphere" as const,
          service: "surface" as const,
        }
      : null;

  // Delhivery couriers
  const delhiveryCouriers = delhiveryCourier
    ? [
        { ...delhiveryCourier, platformId: String(shiphereCourierIds.delhivery_one_500g) },
        { ...delhiveryCourier, platformId: String(shiphereCourierIds.delhivery_one_1kg) },
        { ...delhiveryCourier, platformId: String(shiphereCourierIds.delhivery_one_2kg) },
        { ...delhiveryCourier, platformId: String(shiphereCourierIds.delhivery_one_3kg) },
        { ...delhiveryCourier, platformId: String(shiphereCourierIds.delhivery_one_4kg) },
        { ...delhiveryCourier, platformId: String(shiphereCourierIds.delhivery_one_5kg) },
      ]
    : [];

  // Amazon couriers
  const amazonCouriers = amazonCourier
    ? [
        {
          ...amazonCourier,
          platformId: String(shiphereCourierIds.amazon_shipping_surface_500gm),
        },
        {
          ...amazonCourier,
          platformId: String(shiphereCourierIds.amazon_shipping_surface_1kg),
        },
        {
          ...amazonCourier,
          platformId: String(shiphereCourierIds.amazon_shipping_surface_2kg),
        },
        {
          ...amazonCourier,
          platformId: String(shiphereCourierIds.amazon_shipping_surface_3kg),
        },
        {
          ...amazonCourier,
          platformId: String(shiphereCourierIds.amazon_shipping_surface_4kg),
        },
        {
          ...amazonCourier,
          platformId: String(shiphereCourierIds.amazon_shipping_surface_5kg),
        },
      ]
    : [];

  // Ekart couriers
  const ekartCouriers = ekartCourier
    ? [
        {
          ...ekartCourier,
          platformId: String(shiphereCourierIds.ekart_500g),
        },
        {
          ...ekartCourier,
          platformId: String(shiphereCourierIds.ekart_1kg),
        },
        {
          ...ekartCourier,
          platformId: String(shiphereCourierIds.ekart_2kg),
        },
        {
          ...ekartCourier,
          platformId: String(shiphereCourierIds.ekart_3kg),
        },
        {
          ...ekartCourier,
          platformId: String(shiphereCourierIds.ekart_4kg),
        },
        {
          ...ekartCourier,
          platformId: String(shiphereCourierIds.ekart_5kg),
        },
      ]
    : [];

  serviceableCouriers.push(...delhiveryCouriers, ...amazonCouriers, ...ekartCouriers);
  return serviceableCouriers;
}

export async function checkFshipServiceability(
  pincode: number,
  platformCouriers: PartialCourier[]
): Promise<CourierInfo[]> {
  const serviceableCouriers: CourierInfo[] = [];

  const fuse = new Fuse(platformCouriers, {
    keys: ["id", "name"],
    threshold: 0.3,
    includeScore: true,
  });

  // Find Delhivery courier
  const delhiveryResults = fuse.search("delhivery");
  const delhiveryCourier =
    delhiveryResults.length > 0 && delhiveryResults[0].score! < 0.5
      ? {
          id: delhiveryResults[0].item.id,
          name: delhiveryResults[0].item.name,
          image: delhiveryResults[0].item.image,
          platform: "fship" as const,
          service: "surface" as const,
          platformId: String(fshipCourierIds.delhivery),
        }
      : null;

  // Find Amazon courier
  const amazonResults = fuse.search("amazon");
  const amazonCourier =
    amazonResults.length > 0 && amazonResults[0].score! < 0.5
      ? {
          id: amazonResults[0].item.id,
          name: amazonResults[0].item.name,
          image: amazonResults[0].item.image,
          platform: "fship" as const,
          service: "surface" as const,
          platformId: String(fshipCourierIds.amazon_india),
        }
      : null;

  delhiveryCourier && serviceableCouriers.push(delhiveryCourier);
  amazonCourier && serviceableCouriers.push(amazonCourier);

  return serviceableCouriers;
}

export async function checkIThinkLogisticsServiceability(
  pincode: number,
  platformCouriers: PartialCourier[]
): Promise<CourierInfo[]> {
  const response = await tryCatch(checkIThinkLogisticsPincodeServiceability(pincode));
  if (response.error) {
    logger.error("checkIThinkLogisticsServiceability", { input: { pincode, platformCouriers }, error: response.error });
    return [];
  }
  logger.info("checkIThinkLogisticsServiceability", { input: { pincode, platformCouriers }, response: response.data });

  const pincodeData = response.data.data[String(pincode)];
  if (!pincodeData) {
    return [];
  }

  const platformCourierIds = Object.keys(pincodeData).slice(5);

  const fuse = new Fuse(platformCouriers, {
    keys: ["name"],
    threshold: 0.3,
    includeScore: true,
  });

  const serviceableCouriers: CourierInfo[] = [];

  for (const platformId of platformCourierIds) {
    const courierData = pincodeData[platformId];
    if (courierData.prepaid !== "Y") continue;
    const searchResults = fuse.search(platformId);

    if (searchResults.length > 0 && searchResults[0].score! < 0.5) {
      const matchedCouriers: CourierInfo[] = searchResults.map((result) => ({
        id: result.item.id,
        name: result.item.name,
        image: result.item.image,
        platform: "ithink-logistics",
        platformId,
        service: "surface",
      }));
      serviceableCouriers.push(...matchedCouriers);
    }
  }

  return serviceableCouriers;
}

export async function checkDelhiveryServiceability(
  pincode: number,
  platformCouriers: PartialCourier[]
): Promise<CourierInfo[]> {
  const response = await tryCatch(checkDelhiveryPincodeServiceability(pincode));
  if (response.error) {
    logger.error("checkDelhiveryServiceability", { input: { pincode, platformCouriers }, error: response.error });
    return [];
  }
  logger.info("checkDelhiveryServiceability", { input: { pincode, platformCouriers }, response: response.data });

  const fuse = new Fuse(platformCouriers, {
    keys: ["name"],
    threshold: 0.3,
    includeScore: true,
  });

  let delhiveryCourier: PartialCourier | null = null;

  const searchResults = fuse.search("delhivery");
  if (searchResults.length > 0 && searchResults[0].score! < 0.5) {
    delhiveryCourier = searchResults[0].item;
  }

  const serviceableCouriers: CourierInfo[] = [];

  if (delhiveryCourier && response.data.delivery_codes.length > 0) {
    serviceableCouriers.push({
      id: delhiveryCourier.id,
      name: delhiveryCourier.name,
      image: delhiveryCourier.image,
      platform: "delhivery",
      service: "surface",
    });
  }

  return serviceableCouriers;
}

export async function checkAmazonServiceability(
  pincode: number,
  platformCouriers: PartialCourier[]
): Promise<CourierInfo[]> {
  const fuse = new Fuse(platformCouriers, {
    keys: ["name"],
    threshold: 0.3,
    includeScore: true,
  });

  let amazonCourier: PartialCourier | null = null;

  const searchResults = fuse.search("amazon");
  if (searchResults.length > 0 && searchResults[0].score! < 0.5) {
    amazonCourier = searchResults[0].item;
  }

  const serviceableCouriers: CourierInfo[] = [];

  amazonCourier &&
    serviceableCouriers.push({
      id: amazonCourier.id,
      name: amazonCourier.name,
      image: amazonCourier.image,
      platform: "amazon",
      service: "surface",
    });

  return serviceableCouriers;
}

export async function checkPincodeServiceability(pincode: number, couriers: PartialCourier[]): Promise<CourierInfo[]> {
  const pincodeCouriers = couriers.filter((courier) => courier.serviceabilityCheck.includes("pincode"));

  if (pincodeCouriers.length === 0) {
    return [];
  }

  // Create all courier-service combinations for batch query
  const courierServiceCombinations = pincodeCouriers.flatMap((courier) =>
    courier.services.map((service) => ({ courierId: courier.id, service }))
  );

  // Batch fetch all pincode details at once
  const response = await tryCatch(
    db.query.courierPincodes.findMany({
      columns: {
        courier: true,
        courierService: true,
        metadata: true,
      },
      where: (fields, operators) => {
        return operators.and(
          operators.eq(fields.pincode, pincode),
          operators.inArray(fields.courier, [...new Set(courierServiceCombinations.map((combo) => combo.courierId))])
        );
      },
      limit: 500,
    })
  );

  if (response.error) {
    logger.error("checkPincodeServiceability", { input: { pincode, couriers }, error: response.error });
    return [];
  }
  logger.info("checkPincodeServiceability", { input: { pincode, couriers }, response: response.data });

  // Group results by courier and service
  const pincodeDetailsMap = new Map<string, any>();
  for (const detail of response.data) {
    const key = `${detail.courier}|${detail.courierService}`;
    pincodeDetailsMap.set(key, detail);
  }

  // Build serviceable couriers from results
  const serviceableCouriers: CourierInfo[] = [];

  for (const courier of pincodeCouriers) {
    for (const service of courier.services) {
      const key = `${courier.id}|${service}`;
      const pincodeDetail = pincodeDetailsMap.get(key);

      if (pincodeDetail) {
        serviceableCouriers.push({
          id: courier.id,
          name: courier.name,
          image: courier.image,
          metadata: pincodeDetail.metadata,
          service: service,
          platform: undefined,
        });
      }
    }
  }

  return serviceableCouriers;
}

export function getAlwaysAvailableCouriers(couriers: PartialCourier[]): CourierInfo[] {
  const alwaysAvailableCouriers = couriers.filter((courier) =>
    courier.serviceabilityCheck.includes("always_available")
  );
  const response = alwaysAvailableCouriers.flatMap((courier) =>
    courier.services.map((service) => ({
      id: courier.id,
      name: courier.name,
      image: courier.image,
      service: service,
      platform: undefined,
    }))
  );

  logger.info("getAlwaysAvailableCouriers", { input: { couriers }, response });

  return response;
}
