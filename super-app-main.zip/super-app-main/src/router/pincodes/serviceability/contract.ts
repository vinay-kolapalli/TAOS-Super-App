import { permissionsList } from "@/data/permissions";
import { oc } from "@/lib/orpc/contract";
import { checkPincodeServiceabilityInputSchema, checkPincodeServiceabilityOutputSchema } from "./schema";

const checkPincodeServiceability = oc
  .meta({ permission: [permissionsList.pincodes.read, permissionsList.courierChecker.read] })
  .input(checkPincodeServiceabilityInputSchema)
  .output(checkPincodeServiceabilityOutputSchema);

export const contract = {
  check: checkPincodeServiceability,
};
