import { CourierPlatforms, CourierServices } from "@/data/shipping";
import { createOutputSchema } from "@/lib/orpc/contract";
import z from "zod";

export const checkPincodeServiceabilityInputSchema = z.object({
  pincode: z.number().int().min(100000).max(999999),
});
export type CheckPincodeServiceabilityInputSchema = z.infer<typeof checkPincodeServiceabilityInputSchema>;

export const checkPincodeServiceabilityOutputSchema = createOutputSchema(
  z.object({
    pincode: z.number().int().min(100000).max(999999),
    couriers: z.array(
      z.object({
        id: z.string(),
        name: z.string(),
        image: z.string(),
        service: z.string() as z.ZodType<CourierServices>,
        platform: z.string().optional() as z.ZodType<CourierPlatforms | undefined>,
        platformId: z.string().optional(),
        metadata: z
          .array(
            z.object({
              key: z.string(),
              value: z.string(),
            })
          )
          .optional(),
      })
    ),
  })
);
export type CheckPincodeServiceabilityOutputSchema = z.infer<typeof checkPincodeServiceabilityOutputSchema>;
