import { db } from "@/db";
import { orderShipments } from "@/db/schema/courier-checker";
import { courierPincodes } from "@/db/schema/pincodes";
import { getDatabaseErrorMessage } from "@/db/utils/error";
import { fetchAllData } from "@/db/utils/fetch";
import { authMiddleware } from "@/lib/orpc/middleware";
import { tryCatch } from "@/lib/try-catch";
import { batchProcess } from "@/utils/batch";
import { returnCsv } from "@/utils/csv";
import { implement, ORPCError } from "@orpc/server";
import { differenceInDays } from "date-fns";
import { and, eq, gt, gte, inArray, lte } from "drizzle-orm";
import { contract } from "./contract";
import { PincodeData } from "./schema";
import * as serviceability from "./serviceability";

const os = implement(contract);

const upsertPincodes = os.create.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(
    batchProcess(input, 5000, async (values) => {
      const { error } = await tryCatch(
        db
          .insert(courierPincodes)
          .values(values)
          .onConflictDoUpdate({
            target: [courierPincodes.pincode, courierPincodes.courier, courierPincodes.courierService],
            set: values,
          })
      );

      if (error) {
        throw new Error(
          getDatabaseErrorMessage(error, {
            uniqueConstraint: "A pincode with this pincode, courier, and service combination already exists",
            foreignKeyConstraint: "Invalid courier - please ensure the courier exists",
            parameterLimit: "Too many parameters in batch - try reducing the chunk size",
            fallback: "Unable to save pincodes",
          })
        );
      }
    })
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: error.message || "Unable to save pincodes",
    });
  }

  return { message: "Pincodes saved successfully" };
});

const deletePincodesByCourier = os.deleteCourier.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(
    db
      .delete(courierPincodes)
      .where(and(eq(courierPincodes.courier, input.id), eq(courierPincodes.courierService, input.service)))
  );

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, {
        fallback: "Unable to delete courier pincodes",
      }),
    });
  }

  return { message: "Courier pincodes deleted successfully" };
});

const deletePincodes = os.delete.use(authMiddleware).handler(async ({ input }) => {
  const { error } = await tryCatch(db.delete(courierPincodes).where(inArray(courierPincodes.id, input.ids)));

  if (error) {
    throw new ORPCError("INTERNAL_SERVER_ERROR", {
      message: getDatabaseErrorMessage(error, {
        fallback: "Unable to delete pincodes",
      }),
    });
  }

  return { message: "Pincodes deleted successfully" };
});

const getPincodesReport = os.report.use(authMiddleware).handler(async ({ input, context }) => {
  const { from, to, warehouse } = input;
  const userWarehouses = [context.user.primaryWarehouse, ...context.user.otherWarehouses];
  const validWarehouses =
    warehouse && userWarehouses.includes(Number(warehouse)) ? [Number(warehouse)] : userWarehouses;

  if (!validWarehouses) {
    throw new ORPCError("FORBIDDEN", {
      message: "Access denied to warehouse",
    });
  }

  const shipments = await fetchAllData(undefined, async (cursor) => {
    return await db.query.orderShipments.findMany({
      where: and(
        gte(orderShipments.createdAt, from),
        lte(orderShipments.createdAt, to),
        cursor ? gt(orderShipments.id, cursor) : undefined,
        inArray(orderShipments.warehouse, validWarehouses)
      ),
      with: {
        rate: {
          with: {
            courier: {
              columns: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
    });
  });

  const pincodeMap = new Map<string, PincodeData>();

  shipments.forEach((shipment) => {
    const key = `${shipment.pincode}-${shipment.rate?.courier?.id || "-"}`;
    const courierName = shipment.rate?.courier?.name ?? "-";

    let entry = pincodeMap.get(key);
    if (!entry) {
      entry = {
        pincode: shipment.pincode,
        courierName,
        totalShipments: 0,
        rates: [],
        deliveredCount: 0,
        rtoCount: 0,
        deliveryTimes: [],
      };
      pincodeMap.set(key, entry);
    }

    // Update common fields
    entry.totalShipments += 1;
    entry.rates.push(shipment.rate?.rate || 0);

    // Handle status-specific logic
    if (shipment.status === "delivered") {
      entry.deliveredCount += 1;

      // Calculate delivery time if both dates exist
      if (shipment.deliveredAt && shipment.createdAt) {
        const deliveryTimeDays = differenceInDays(
          new Date(shipment.deliveredAt).toLocaleDateString("en-US", { timeZone: "Asia/Kolkata" }),
          new Date(shipment.createdAt).toLocaleDateString("en-US", { timeZone: "Asia/Kolkata" })
        );
        entry.deliveryTimes.push(deliveryTimeDays);
      }
    } else if (shipment.status === "rto") {
      entry.rtoCount += 1;
    }
  });

  // Convert to final report format
  const reportData = Array.from(pincodeMap.values()).map((entry) => ({
    pincode: entry.pincode,
    courierName: entry.courierName,
    totalShipments: entry.totalShipments,
    averageRate: Math.round(entry.rates.reduce((sum, rate) => sum + rate, 0) / entry.rates.length),
    deliveredCount: entry.deliveredCount,
    rtoCount: entry.rtoCount,
    averageDeliveryTimeInDays:
      entry.deliveryTimes.length > 0
        ? Math.round(entry.deliveryTimes.reduce((sum, time) => sum + time, 0) / entry.deliveryTimes.length)
        : null,
  }));

  const csv = returnCsv(reportData);

  return { message: "Export completed", data: csv };
});

export const router = {
  create: upsertPincodes,
  update: upsertPincodes,
  delete: deletePincodes,
  deleteCourier: deletePincodesByCourier,
  report: getPincodesReport,
  serviceability: serviceability.router,
};
