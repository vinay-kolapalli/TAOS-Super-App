import { courierServices } from "@/data/shipping";
import { createOutputSchema } from "@/lib/orpc/contract";
import { getEndOfDay, getStartOfDay } from "@/utils/date";
import z from "zod";

export interface PincodeData {
  pincode: number;
  courierName: string;
  totalShipments: number;
  rates: number[];
  deliveredCount: number;
  rtoCount: number;
  deliveryTimes: number[];
}

const courierPincodeMetadataSchema = z.object({
  key: z.string(),
  value: z.string(),
});

export const upsertPincodesInputSchema = z.array(
  z.object({
    pincode: z.number(),
    metadata: z.array(courierPincodeMetadataSchema),
    courier: z.string(),
    courierService: z.enum(courierServices),
  })
);
export type UpsertPincodesInputSchema = z.infer<typeof upsertPincodesInputSchema>;

export const upsertPincodeOutputSchema = createOutputSchema();
export type UpsertPincodeOutputSchema = z.infer<typeof upsertPincodeOutputSchema>;

export const deletePincodesByCourierInputSchema = z.object({
  id: z.string(),
  service: z.enum(courierServices),
});
export type DeletePincodesByCourierInputSchema = z.infer<typeof deletePincodesByCourierInputSchema>;

export const deletePincodesByCourierOutputSchema = createOutputSchema();
export type DeletePincodesByCourierOutputSchema = z.infer<typeof deletePincodesByCourierOutputSchema>;

export const deletePincodesInputSchema = z.object({
  ids: z.array(z.string()),
});
export type DeletePincodesInputSchema = z.infer<typeof deletePincodesInputSchema>;

export const deletePincodesOutputSchema = createOutputSchema();
export type DeletePincodesOutputSchema = z.infer<typeof deletePincodesOutputSchema>;

export const getPincodesReportInputSchema = z.object({
  from: z.date().transform((val) => getStartOfDay(val)),
  to: z.date().transform((val) => getEndOfDay(val)),
  warehouse: z.number().optional(),
});
export type GetPincodesReportInputSchema = z.infer<typeof getPincodesReportInputSchema>;

export const getPincodesReportOutputSchema = createOutputSchema(z.string());
export type GetPincodesReportOutputSchema = z.infer<typeof getPincodesReportOutputSchema>;
