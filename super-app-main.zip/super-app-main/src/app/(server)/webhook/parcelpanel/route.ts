import { db } from "@/db";
import { orderShipments } from "@/db/schema/courier-checker";
import { logger, withAxiom } from "@/lib/logging/server";
import { ParcelPanelWebhook } from "@/types/parcelpanel";
import { mapParcelPanelStatus } from "@/utils/parcelpanel";
import crypto from "crypto";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export const POST = withAxiom(async (request: NextRequest) => {
  const signature = request.headers.get("X-ParcelPanel-HMAC-SHA256");
  if (!signature) {
    return new NextResponse("Missing signature", { status: 401 });
  }

  const body = await request.text();
  const payload: ParcelPanelWebhook = JSON.parse(body);
  logger.info(`[/webhook/parcelpanel] Input`, { input: payload });

  // Verify the HMAC-SHA256 signature
  const expectedSignature = crypto.createHmac("sha256", process.env.PARCEL_PANEL_API_KEY).update(body).digest("base64");
  if (signature !== expectedSignature) {
    return new NextResponse("Invalid signature", { status: 401 });
  }

  // Process the webhook payload here
  let pickedAt = new Date(payload.fulfillment_date);
  if (payload.carrier.code !== "shree-tirupati") {
    pickedAt = payload.pickup_date ? new Date(payload.pickup_date) : new Date(payload.fulfillment_date);
  }

  await db
    .update(orderShipments)
    .set({
      status: mapParcelPanelStatus(payload.status),
      pickedAt,
      deliveredAt: payload.delivery_date ? new Date(payload.delivery_date) : null,
    })
    .where(eq(orderShipments.trackingNumber, payload.tracking_number));

  return new NextResponse("OK", { status: 200 });
});
