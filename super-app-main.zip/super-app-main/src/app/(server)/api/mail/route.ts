import { getSession } from "@/lib/auth";
import { logger, withAxiom } from "@/lib/logging/server";
import { sendMail, sendMailOptionsSchema } from "@/lib/mail";
import { NextRequest, NextResponse } from "next/server";

export const POST = withAxiom(async (request: NextRequest) => {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const data = await request.json();
  logger.info(`[/api/mail] Input`, { data });

  const mailOptions = sendMailOptionsSchema.safeParse(data);
  if (mailOptions.error) {
    return NextResponse.json({ error: "Invalid mail options" }, { status: 400 });
  }

  await sendMail(mailOptions.data);

  return NextResponse.json({ message: "Mail sent successfully" });
});
