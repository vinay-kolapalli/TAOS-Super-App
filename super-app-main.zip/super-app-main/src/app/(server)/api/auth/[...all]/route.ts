import { auth } from "@/lib/auth";
import { withAxiom } from "@/lib/logging/server";
import { toNextJsHandler } from "better-auth/next-js";

const handlers = toNextJsHandler(auth.handler);

export const GET = withAxiom(handlers.GET);
export const POST = withAxiom(handlers.POST);
