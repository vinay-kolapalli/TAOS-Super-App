import { baseLogger } from "@/lib/logging/server";
import { createProxyRouteHandler } from "@axiomhq/nextjs";

export const POST = createProxyRouteHandler(baseLogger);
