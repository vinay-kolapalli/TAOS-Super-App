"use client";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { IconAlertTriangle } from "@tabler/icons-react";
import { useState } from "react";
import { clearCookies } from "./_actions/errors";

export default function Page() {
  const [isLoading, setisLoading] = useState(false);

  async function handleClear() {
    setisLoading(true);
    try {
      localStorage.clear();
      sessionStorage.clear();
      await clearCookies();
      window.location.reload();
    } catch (e) {
      setisLoading(false);
    }
  }

  return (
    <div className="flex items-center justify-center min-h-dvh">
      <div className="flex w-full max-w-lg flex-col gap-6 items-center">
        <Logo className="size-20" />
        <Card className="w-full max-w-lg">
          <CardHeader className="items-center gap-2 pb-2">
            <div className="flex items-center justify-center bg-yellow-100 rounded-full p-3 mb-2">
              <IconAlertTriangle className="w-10 h-10 text-yellow-500" />
            </div>
            <CardTitle className="text-center text-lg font-semibold">Uh-oh! Something went wrong</CardTitle>
            <CardDescription className="text-center text-muted-foreground">
              We&apos;re sorry, but we&apos;re having a little trouble right now.
              <br />
              Try clearing your browser cache, cookies, and local storage for this site, then try again.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-4 pt-2">
            <Button
              onClick={handleClear}
              disabled={isLoading}
              isLoading={isLoading}
              className="w-full"
              variant="default"
            >
              Clear Cache & Cookies
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
