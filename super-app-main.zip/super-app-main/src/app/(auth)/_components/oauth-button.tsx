"use client";
import { IconGoogle } from "@/components/icons/google";
import { Button } from "@/components/ui/button";
import { authClient } from "@/lib/auth.client";
import toast from "react-hot-toast";

interface Props {
  title: string;
  provider: "google";
  variant?: "outline" | "default";
  className?: string;
  disabled?: boolean;
}

export function OAuthButton({
  title,
  provider,
  variant = "default",
  className,
  disabled,
}: Props) {
  async function handleOAuthSignIn() {
    const { error } = await authClient.signIn.social({
      provider,
      requestSignUp: false,
    });

    if (error) {
      toast.error(error?.message ?? "Something went wrong");
    }
  }

  return (
    <Button
      type="button"
      variant={variant}
      onClick={handleOAuthSignIn}
      disabled={disabled}
      className={className}
    >
      <OAuthIcons provider={provider} />
      {title}
    </Button>
  );
}

function OAuthIcons({ provider }: { provider: "google" }) {
  switch (provider) {
    case "google":
      return <IconGoogle />;
    default:
  }
}
