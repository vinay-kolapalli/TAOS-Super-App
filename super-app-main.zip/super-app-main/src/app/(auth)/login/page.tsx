"use client";
import { LoginForm } from "./_components/login-form";

function Page() {
  return <LoginForm className="w-full" />;
}

export default Page;
