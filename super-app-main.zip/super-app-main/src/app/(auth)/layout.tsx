import { Logo } from "@/components/logo";

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <main>
      <div className="flex items-center justify-center min-h-dvh -my-5">
        <div className="flex w-full max-w-sm flex-col gap-6 items-center">
          <Logo className="size-20" />
          {children}
        </div>
      </div>
    </main>
  );
}
