import { PageContainer, PageHeader } from "@/components/page";
import { db } from "@/db";
import { notFound } from "next/navigation";
import { BoxForm } from "../_components/box-form";

interface Props {
  params: Promise<{ id: string }>;
}

export default async function Page({ params }: Props) {
  const { id } = await params;

  const box = await db.query.boxes.findFirst({
    where(fields, operators) {
      return operators.eq(fields.id, id);
    },
  });

  if (!box) {
    notFound();
  }

  return (
    <PageContainer>
      <PageHeader title="Edit Box" description={`Update details for ${box.name}.`} />
      <BoxForm defaultValues={box} />
    </PageContainer>
  );
}
