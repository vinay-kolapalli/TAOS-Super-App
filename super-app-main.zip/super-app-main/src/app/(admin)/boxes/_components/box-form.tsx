"use client";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Box } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { UpsertBoxInputSchema, upsertBoxInputSchema } from "@/router/boxes/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { toast } from "react-hot-toast";

interface Props {
  defaultValues?: Partial<Box>;
}

export function BoxForm({ defaultValues }: Props) {
  const form = useForm<UpsertBoxInputSchema>({
    resolver: zodResolver(upsertBoxInputSchema),
    defaultValues,
  });
  const { isSubmitting } = form.formState;
  const router = useRouter();

  async function onSubmit(values: UpsertBoxInputSchema) {
    const rpc = defaultValues?.id ? orpc.boxes.update : orpc.boxes.create;
    const { error, data } = await safe(rpc(values));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    router.push("/boxes");
  }

  function calculateVolumetricWeight() {
    const length = form.getValues("length");
    const breadth = form.getValues("breadth");
    const height = form.getValues("height");

    if (length && breadth && height) {
      const vol = (length * breadth * height) / 5000;
      form.setValue("volumetricWeight", parseFloat(vol.toFixed(3)));
    }
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
      <Form {...form}>
        <FormField
          control={form.control}
          name="id"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Box ID</FormLabel>
              <FormControl>
                <Input
                  placeholder="e.g., small-box, medium-box"
                  {...field}
                  disabled={!!defaultValues?.id}
                  readOnly={!!defaultValues?.id}
                />
              </FormControl>
              <FormDescription>
                Unique identifier for the box. Use lowercase letters, numbers, and hyphens only.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Box Name</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Small Box, Medium Box" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="length"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Length (cm)</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    step="0.1"
                    min="0"
                    {...field}
                    onChange={(e) => {
                      field.onChange(parseFloat(e.target.value) || 0);
                      calculateVolumetricWeight();
                    }}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="breadth"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Breadth (cm)</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    step="0.1"
                    min="0"
                    {...field}
                    onChange={(e) => {
                      field.onChange(parseFloat(e.target.value) || 0);
                      calculateVolumetricWeight();
                    }}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="height"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Height (cm)</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    step="0.1"
                    min="0"
                    {...field}
                    onChange={(e) => {
                      field.onChange(parseFloat(e.target.value) || 0);
                      calculateVolumetricWeight();
                    }}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <FormField
          control={form.control}
          name="volumetricWeight"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Volumetric Weight (kg)</FormLabel>
              <FormControl>
                <Input type="number" step="0.001" min="0" {...field} />
              </FormControl>
              <FormDescription>
                Calculated as (L x B x H) ÷ 5000. Auto-calculated when dimensions are entered.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="isActive"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm space-y-0">
              <div>
                <FormLabel>Is Active</FormLabel>
                <FormDescription>Enable or disable the box.</FormDescription>
              </div>
              <FormControl>
                <Switch checked={field.value} onCheckedChange={field.onChange} />
              </FormControl>
            </FormItem>
          )}
        />
        <Button isLoading={isSubmitting} disabled={isSubmitting}>
          Submit
        </Button>
      </Form>
    </form>
  );
}
