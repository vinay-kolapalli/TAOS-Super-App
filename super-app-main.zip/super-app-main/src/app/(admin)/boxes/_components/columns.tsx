"use client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Box } from "@/db/types";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { BoxMenu } from "./box-menu";

export const columns: ColumnDef<Box>[] = [
  {
    accessorKey: "title",
    header: "Name",
    cell: ({ row }) => {
      return <div className="font-medium">{row.original.name}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "id",
    header: "ID",
    cell: ({ row }) => {
      return <div className="font-mono text-sm">{row.original.id}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "isActive",
    header: "Status",
    cell: ({ row }) => {
      return (
        <Badge variant={row.original.isActive ? "default" : "secondary"}>
          {row.original.isActive ? "Active" : "Inactive"}
        </Badge>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "dimensions",
    header: "Dimensions (cm)",
    cell: ({ row }) => {
      const { length, breadth, height } = row.original;
      return (
        <div className="font-mono text-sm">
          {length} x {breadth} x {height}
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "volumetricWeight",
    header: "Vol. Weight (kg)",
    cell: ({ row }) => {
      return <div className="font-mono text-sm">{row.original.volumetricWeight}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "actions",
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <BoxMenu id={row.original.id}>
            <Button variant="ghost" size="icon">
              <IconDots />
            </Button>
          </BoxMenu>
        </div>
      );
    },
    enableSorting: false,
  },
];
