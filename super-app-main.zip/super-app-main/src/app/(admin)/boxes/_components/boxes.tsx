"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { Box } from "@/db/types";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { columns } from "./columns";

interface Props {
  boxes: Box[];
  totalBoxes: number;
  isLoading?: boolean;
}

export function Boxes({ boxes, totalBoxes, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });

  const table = useReactTable({
    data: boxes,
    columns,
    pageCount: Math.ceil(totalBoxes / pagination.pageSize),
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    state: {
      pagination,
    },
  });

  return <DataTable table={table} isLoading={isLoading} paginationType="numeric" />;
}
