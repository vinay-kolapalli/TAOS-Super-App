import { Search } from "@/components/search";
import { Button } from "@/components/ui/button";
import { db } from "@/db";
import { boxes } from "@/db/schema/shipping";
import { asc, count, ilike, or } from "drizzle-orm";
import { nanoid } from "nanoid";
import Link from "next/link";
import { Suspense } from "react";
import { Boxes } from "./_components/boxes";

interface Props {
  searchParams: Promise<{
    page: string;
    per_page: string;
    search: string;
  }>;
}

export default function Page(props: Props) {
  return (
    <div className="w-full space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-lg font-bold">Boxes</h2>
        <div className="flex gap-4 flex-wrap">
          <Search shallow={false} />
          <Link href="/boxes/new">
            <Button>Create</Button>
          </Link>
        </div>
      </div>
      <Suspense key={nanoid()} fallback={<Boxes boxes={[]} totalBoxes={0} isLoading={true} />}>
        <PageWithFetch {...props} />
      </Suspense>
    </div>
  );
}

async function PageWithFetch({ searchParams }: Props) {
  const searchParamsList = await searchParams;
  const page = Number(searchParamsList.page ?? 1);
  const per_page = Number(searchParamsList.per_page ?? 10);
  const search = searchParamsList.search ?? "";

  const where = search ? or(ilike(boxes.name, `%${search}%`), ilike(boxes.id, `%${search}%`)) : undefined;

  const boxesData = await db.query.boxes.findMany({
    limit: per_page,
    offset: (page - 1) * per_page,
    where,
    orderBy: [asc(boxes.name)],
  });

  const [totalBoxes] = await db.select({ count: count() }).from(boxes).where(where);

  return <Boxes boxes={boxesData} totalBoxes={totalBoxes.count} />;
}
