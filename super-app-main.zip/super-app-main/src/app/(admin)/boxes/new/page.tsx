import { PageContainer, PageHeader } from "@/components/page";
import { BoxForm } from "../_components/box-form";

export default function Page() {
  return (
    <PageContainer>
      <PageHeader title="Create Box" description="Add a new box to the system." />
      <BoxForm
        defaultValues={{
          id: "",
          name: "",
          isActive: true,
          length: 0,
          breadth: 0,
          height: 0,
          volumetricWeight: 0,
        }}
      />
    </PageContainer>
  );
}
