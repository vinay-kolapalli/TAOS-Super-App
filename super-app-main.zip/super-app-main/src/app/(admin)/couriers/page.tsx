import { Search } from "@/components/search";
import { Button } from "@/components/ui/button";
import { db } from "@/db";
import { couriers } from "@/db/schema/shipping";
import { asc, count, ilike, or } from "drizzle-orm";
import { nanoid } from "nanoid";
import Link from "next/link";
import { Suspense } from "react";
import { Couriers } from "./_components/couriers";

interface Props {
  searchParams: Promise<{
    page: string;
    per_page: string;
    search: string;
  }>;
}

export default function Page(props: Props) {
  return (
    <div className="w-full space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-lg font-bold">Couriers</h2>
        <div className="flex gap-4 flex-wrap">
          <Search shallow={false} />
          <Link href="/couriers/new">
            <Button>Create</Button>
          </Link>
        </div>
      </div>
      <Suspense key={nanoid()} fallback={<Couriers couriers={[]} totalCouriers={0} isLoading={true} />}>
        <PageWithFetch {...props} />
      </Suspense>
    </div>
  );
}

async function PageWithFetch({ searchParams }: Props) {
  const searchParamsList = await searchParams;
  const page = Number(searchParamsList.page ?? 1);
  const per_page = Number(searchParamsList.per_page ?? 10);
  const search = searchParamsList.search ?? "";

  const where = search ? or(ilike(couriers.name, `%${search}%`), ilike(couriers.id, `%${search}%`)) : undefined;

  const couriersData = await db.query.couriers.findMany({
    limit: per_page,
    offset: (page - 1) * per_page,
    where,
    orderBy: [asc(couriers.name)],
  });

  const [totalCouriers] = await db.select({ count: count() }).from(couriers).where(where);

  return <Couriers couriers={couriersData} totalCouriers={totalCouriers.count} />;
}
