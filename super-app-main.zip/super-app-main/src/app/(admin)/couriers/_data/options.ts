import { CourierServiceabilityCheck } from "@/data/shipping";
import { SelectOption } from "@/types/general";

export const serviceabilityCheckOptions: SelectOption<CourierServiceabilityCheck>[] = [
  {
    label: "Always available",
    value: "always_available",
  },
  {
    label: "Pincode",
    value: "pincode",
  },
  {
    label: "Platform",
    value: "platform",
  },
];
