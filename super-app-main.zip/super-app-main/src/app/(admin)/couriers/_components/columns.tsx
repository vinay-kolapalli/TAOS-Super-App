"use client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Courier } from "@/db/types";
import { getSignedUrl } from "@/lib/s3";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import Image from "next/image";
import { CourierMenu } from "./courier-menu";

export const columns: ColumnDef<Courier>[] = [
  {
    accessorKey: "image",
    header: "Logo",
    cell: ({ row }) => {
      return (
        <div className="w-10 h-10 relative">
          <Image
            src={getSignedUrl(row.original.image)}
            alt={row.original.name}
            fill
            className="object-contain rounded-md"
          />
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "title",
    header: "Name",
    cell: ({ row }) => {
      return <div className="font-medium">{row.original.name}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "id",
    header: "ID",
    cell: ({ row }) => {
      return <div className="font-medium">{row.original.id}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "isActive",
    header: "Status",
    cell: ({ row }) => {
      return (
        <Badge variant={row.original.isActive ? "default" : "secondary"}>
          {row.original.isActive ? "Active" : "Inactive"}
        </Badge>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "actions",
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <CourierMenu id={row.original.id}>
            <Button variant="ghost" size="icon">
              <IconDots />
            </Button>
          </CourierMenu>
        </div>
      );
    },
    enableSorting: false,
  },
];
