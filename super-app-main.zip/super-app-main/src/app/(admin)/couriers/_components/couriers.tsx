"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { Courier } from "@/db/types";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { columns } from "./columns";

interface Props {
  couriers: Courier[];
  totalCouriers: number;
  isLoading?: boolean;
}

export function Couriers({ couriers, totalCouriers, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });

  const table = useReactTable({
    data: couriers,
    columns,
    pageCount: Math.ceil(totalCouriers / pagination.pageSize),
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    state: {
      pagination,
    },
  });

  return <DataTable table={table} isLoading={isLoading} paginationType="numeric" />;
}
