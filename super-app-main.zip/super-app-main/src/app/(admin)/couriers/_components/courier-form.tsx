"use client";
import { FileUploader, OnUploadFiles } from "@/components/file-upload/file-uploader";
import { MultiSelect } from "@/components/multi-select";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { courierServicesOptions } from "@/data/shipping";
import { Courier } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { upsertCourierInputSchema, UpsertCourierInputSchema } from "@/router/couriers/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "react-hot-toast";
import { serviceabilityCheckOptions } from "../_data/options";

interface Props {
  defaultValues?: Partial<Courier>;
}

export function CourierForm({ defaultValues }: Props) {
  const [isUploading, setIsUploading] = useState(false);
  const form = useForm<UpsertCourierInputSchema>({
    resolver: zodResolver(upsertCourierInputSchema),
    defaultValues,
  });
  const { isSubmitting } = form.formState;
  const router = useRouter();

  async function onSubmit(values: UpsertCourierInputSchema) {
    const rpc = defaultValues?.id ? orpc.couriers.update : orpc.couriers.create;
    const { error, data } = await safe(rpc(values));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    router.push("/couriers");
  }

  function handleFileUpload(files: OnUploadFiles, error?: string) {
    if (error) {
      toast.error(error);
      return;
    }
    form.setValue("image", files[0].path);
  }

  function handleFileDelete() {
    form.setValue("image", "");
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
      <Form {...form}>
        <FormField
          control={form.control}
          name="id"
          render={({ field }) => (
            <FormItem>
              <FormLabel>ID</FormLabel>
              <FormControl>
                <Input
                  {...field}
                  placeholder="e.g., dtdc, delhivery, amazon-india"
                  disabled={!!defaultValues?.id}
                  readOnly={!!defaultValues?.id}
                />
              </FormControl>
              <FormDescription>
                Unique identifier for the courier. Use lowercase letters, numbers, and hyphens only.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input placeholder="e.g., DTDC, Delhivery, Amazon India" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="image"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Logo</FormLabel>
              <FormControl>
                <FileUploader
                  files={[field.value]}
                  folder="couriers"
                  accept="image/*"
                  maxFiles={1}
                  maxSizeInMB={5}
                  onUpload={handleFileUpload}
                  onDelete={handleFileDelete}
                  isUploading={isUploading}
                  setIsUploading={setIsUploading}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="services"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Services</FormLabel>
              <FormControl>
                <MultiSelect
                  options={courierServicesOptions}
                  value={field.value}
                  onValueChange={field.onChange}
                  placeholder="Select"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="serviceabilityCheck"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Serviceability Check</FormLabel>
              <FormControl>
                <MultiSelect
                  options={serviceabilityCheckOptions}
                  value={field.value}
                  onValueChange={field.onChange}
                  placeholder="Select"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="isActive"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm space-y-0">
              <div>
                <FormLabel>Is Active</FormLabel>
                <FormDescription>Enable or disable the courier.</FormDescription>
              </div>
              <FormControl>
                <Switch checked={field.value} onCheckedChange={field.onChange} />
              </FormControl>
            </FormItem>
          )}
        />
        <Button isLoading={isSubmitting} disabled={isSubmitting || isUploading}>
          Submit
        </Button>
      </Form>
    </form>
  );
}
