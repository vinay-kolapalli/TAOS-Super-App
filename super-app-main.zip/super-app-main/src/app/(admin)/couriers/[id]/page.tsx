import { PageContainer, PageHeader } from "@/components/page";
import { db } from "@/db";
import { notFound } from "next/navigation";
import { CourierForm } from "../_components/courier-form";

interface Props {
  params: Promise<{ id: string }>;
}

export default async function Page({ params }: Props) {
  const { id } = await params;

  const courier = await db.query.couriers.findFirst({
    where(fields, operators) {
      return operators.eq(fields.id, id);
    },
  });

  if (!courier) {
    notFound();
  }

  return (
    <PageContainer>
      <PageHeader title="Edit Courier" description={`Update details for ${courier.name}.`} />
      <CourierForm defaultValues={courier} />
    </PageContainer>
  );
}
