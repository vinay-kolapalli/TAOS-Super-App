import { PageContainer, PageHeader } from "@/components/page";
import { CourierForm } from "../_components/courier-form";

export default function Page() {
  return (
    <PageContainer>
      <PageHeader title="Create Courier" description="Add a new courier to the system." />
      <CourierForm
        defaultValues={{
          id: "",
          name: "",
          image: "",
          isActive: true,
          services: [],
          serviceabilityCheck: [],
        }}
      />
    </PageContainer>
  );
}
