import { Card, CardContent } from "@/components/ui/card";
import { db } from "@/db";
import { Truck } from "lucide-react";
import { redirect } from "next/navigation";

interface Props {
  params: Promise<{ id: string }>;
}

export default async function Page({ params }: Props) {
  const { id } = await params;

  const courier = await db.query.couriers.findFirst({
    where(fields, operators) {
      return operators.eq(fields.id, id);
    },
  });

  if (!courier) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-muted flex items-center justify-center">
            <Truck className="text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Courier Not Found</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            The requested courier service could not be found. Please verify the courier ID and try again.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (courier.services.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-muted flex items-center justify-center">
            <Truck className="text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No Services Available</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            This courier service has no available shipping services configured. Contact your administrator to set up
            services.
          </p>
        </CardContent>
      </Card>
    );
  }

  redirect(`/pincodes/${id}/${courier.services[0]}`);
}
