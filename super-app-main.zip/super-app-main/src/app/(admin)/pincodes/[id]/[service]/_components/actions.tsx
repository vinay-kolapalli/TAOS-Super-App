import { Search } from "@/components/search";
import { CourierServices } from "@/data/shipping";
import { AddPincodeButton } from "./add-pincode-button";
import { BulkActions } from "./bulk-actions";

interface Props {
  courier: { id: string; name: string; service: CourierServices };
}

export function Actions({ courier }: Props) {
  return (
    <div className="flex gap-4 flex-wrap">
      <Search shallow={false} />
      <div className="flex gap-2">
        <AddPincodeButton courier={courier} />
        <BulkActions courier={courier} />
      </div>
    </div>
  );
}
