"use client";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { CourierServices } from "@/data/shipping";
import { useRouter } from "next/navigation";
import { PincodeForm } from "./pincode-form";

interface Props {
  courier: { id: string; service: CourierServices };
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddPincodeSheet({ courier, open, onOpenChange }: Props) {
  const router = useRouter();

  function handleSuccess() {
    onOpenChange(false);
    router.refresh();
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <SheetTitle>Add New Pincode</SheetTitle>
          <SheetDescription>Add a new pincode with service metadata for this courier.</SheetDescription>
        </SheetHeader>
        <div className="mt-6">
          <PincodeForm
            defaultValues={{ courier: courier.id, courierService: courier.service }}
            onSuccess={handleSuccess}
          />
        </div>
      </SheetContent>
    </Sheet>
  );
}
