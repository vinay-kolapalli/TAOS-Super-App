"use client";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { CourierPincode } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { IconPlus, IconTrash } from "@tabler/icons-react";
import { useFieldArray, useForm } from "react-hook-form";
import { toast } from "react-hot-toast";
import { pincodeFormSchema, PincodeFormSchema } from "./schema";

interface Props {
  defaultValues?: Partial<CourierPincode>;
  onSuccess?: () => void;
}

export function PincodeForm({ defaultValues, onSuccess }: Props) {
  const form = useForm<PincodeFormSchema>({
    resolver: zodResolver(pincodeFormSchema),
    defaultValues,
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "metadata",
  });

  function addMetadataField() {
    append({ key: "", value: "" });
  }

  function removeMetadataField(index: number) {
    remove(index);
  }

  async function onSubmit(values: PincodeFormSchema) {
    const rpc = defaultValues?.id ? orpc.pincodes.update : orpc.pincodes.create;
    if (!defaultValues?.courier || !defaultValues?.courierService) {
      toast.error("Courier and courier service are required");
      return;
    }

    const { error, data } = await safe(
      rpc([
        {
          pincode: values.pincode,
          metadata: values.metadata,
          courier: defaultValues.courier,
          courierService: defaultValues.courierService,
        },
      ])
    );
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    onSuccess?.();
    return;
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="pincode"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Pincode</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  placeholder="110001"
                  min="100000"
                  max="999999"
                  {...field}
                  disabled={!!defaultValues?.id}
                  readOnly={!!defaultValues?.id}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Metadata</Label>
            <Button type="button" onClick={addMetadataField} variant="outline" size="sm">
              <IconPlus />
              Add
            </Button>
          </div>

          <ScrollArea className="h-[50dvh]">
            {fields.map((field, index) => (
              <div key={field.id} className="space-y-2 not-last:mb-4">
                <FormField
                  control={form.control}
                  name={`metadata.${index}.key`}
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel className="text-sm">Key</FormLabel>
                      <FormControl>
                        <div className="flex justify-between items-center gap-2">
                          <Input placeholder="service_type" {...field} />
                          <Button
                            type="button"
                            onClick={() => removeMetadataField(index)}
                            variant="destructive"
                            size="icon"
                          >
                            <IconTrash />
                          </Button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name={`metadata.${index}.value`}
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel className="text-sm">Value</FormLabel>
                      <FormControl>
                        <Textarea placeholder="express" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            ))}
            {fields.length === 0 && (
              <div className="p-4 rounded-lg border border-dashed">
                <p className="text-sm text-center">No metadata found</p>
              </div>
            )}
          </ScrollArea>
        </div>

        <Button className="w-full" disabled={form.formState.isSubmitting} isLoading={form.formState.isSubmitting}>
          Submit
        </Button>
      </form>
    </Form>
  );
}
