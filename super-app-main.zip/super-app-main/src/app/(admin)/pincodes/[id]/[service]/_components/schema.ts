import { z } from "zod";

export const pincodeFormSchema = z.object({
  pincode: z.coerce.number<number>().min(100000).max(999999),
  metadata: z.array(
    z.object({
      key: z.string().min(1, "Key is required"),
      value: z.string().min(1, "Value is required"),
    })
  ),
});

export type PincodeFormSchema = z.infer<typeof pincodeFormSchema>;

export const bulkImportSchema = z.object({
  file: z
    .instanceof(File)
    .refine((file) => {
      return file.size > 0;
    }, "Please select a file")
    .refine((file) => {
      return file.type === "text/csv" || file.name.endsWith(".csv");
    }, "Please select a CSV file"),
});

export type BulkImportSchema = z.infer<typeof bulkImportSchema>;
