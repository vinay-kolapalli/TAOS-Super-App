"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { CourierServices } from "@/data/shipping";
import { useRouter } from "next/navigation";
import { BulkImportForm } from "./bulk-import-form";

interface Props {
  courier: { id: string; service: CourierServices };
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function BulkImportSheet({ courier, open, onOpenChange }: Props) {
  const router = useRouter();

  function handleSuccess() {
    onOpenChange(false);
    router.refresh();
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <SheetTitle>Bulk Import</SheetTitle>
          <SheetDescription>Import multiple pincodes from a CSV file.</SheetDescription>
        </SheetHeader>
        <div className="mt-6 space-y-6">
          <Instructions />
          <BulkImportForm courier={courier} onSuccess={handleSuccess} />
        </div>
      </SheetContent>
    </Sheet>
  );
}

function Instructions() {
  return (
    <Card>
      <CardHeader className="p-4">
        <CardTitle>CSV Format</CardTitle>
        <CardDescription>
          First row should contain column headers starting with &apos;pincode&apos; followed by metadata keys.
          Subsequent rows contain data. If a record already exists, it will be updated.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <code className="text-xs bg-secondary border p-2 rounded-md block">
          pincode,service_type,zone,region
          <br />
          401208,express,north,delhi
          <br />
          110001,standard,south,mumbai
          <br />
          560001,premium,west,bangalore
        </code>
      </CardContent>
    </Card>
  );
}
