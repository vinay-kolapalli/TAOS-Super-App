"use client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { CourierPincode } from "@/db/types";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { PincodeMenu } from "./pincode-menu";

export const columns: ColumnDef<CourierPincode>[] = [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={table.getIsAllPageRowsSelected() || (table.getIsSomePageRowsSelected() && "indeterminate")}
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "pincode",
    header: "Pincode",
    cell: ({ row }) => {
      return <div className="font-mono text-sm">{row.original.pincode}</div>;
    },
    enableSorting: true,
  },
  {
    accessorKey: "metadata",
    header: "Metadata",
    cell: ({ row }) => {
      const metadata = row.original.metadata;
      if (!metadata || metadata.length === 0) {
        return <span className="text-muted-foreground">No info</span>;
      }

      return (
        <div className="flex flex-wrap gap-1">
          {metadata.slice(0, 3).map((item, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {item.key}: {item.value.slice(0, 15)}...
            </Badge>
          ))}
          {metadata.length > 3 && (
            <Badge variant="secondary" className="text-xs">
              +{metadata.length - 3} more
            </Badge>
          )}
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "actions",
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <PincodeMenu pincode={row.original}>
            <Button variant="ghost" size="icon">
              <IconDots />
            </Button>
          </PincodeMenu>
        </div>
      );
    },
    enableSorting: false,
  },
];
