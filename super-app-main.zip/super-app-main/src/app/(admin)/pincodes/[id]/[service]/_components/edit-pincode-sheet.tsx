"use client";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { CourierPincode } from "@/db/types";
import { useRouter } from "next/navigation";
import { PincodeForm } from "./pincode-form";

interface Props {
  pincode: CourierPincode;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function EditPincodeSheet({ pincode, open, onOpenChange }: Props) {
  const router = useRouter();

  function handleSuccess() {
    onOpenChange(false);
    router.refresh();
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <SheetTitle>Edit Pincode</SheetTitle>
          <SheetDescription>Update the pincode details and service metadata.</SheetDescription>
        </SheetHeader>
        <div className="mt-6">
          <PincodeForm defaultValues={pincode} onSuccess={handleSuccess} />
        </div>
      </SheetContent>
    </Sheet>
  );
}
