"use client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CourierPincode } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { safe } from "@orpc/client";
import { IconEdit, IconTrash } from "@tabler/icons-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";
import { EditPincodeSheet } from "./edit-pincode-sheet";

interface Props {
  children: React.ReactNode;
  pincode: CourierPincode;
}

export function PincodeMenu({ children, pincode }: Props) {
  const router = useRouter();
  const [showEditSheet, setShowEditSheet] = useState(false);

  async function handleDelete() {
    const { error } = await safe(orpc.pincodes.delete({ ids: [pincode.id] }));
    if (error) {
      toast.error(error.message);
      return;
    }
    router.refresh();
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>{children}</DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setShowEditSheet(true)}>
            <IconEdit />
            Edit
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleDelete} className="text-destructive">
            <IconTrash />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <EditPincodeSheet pincode={pincode} open={showEditSheet} onOpenChange={setShowEditSheet} />
    </>
  );
}
