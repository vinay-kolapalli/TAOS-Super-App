import { CourierServices } from "@/data/shipping";
import { db } from "@/db";
import { courierPincodes } from "@/db/schema/pincodes";
import { and, asc, count, eq } from "drizzle-orm";
import { nanoid } from "nanoid";
import { Suspense } from "react";
import { Actions } from "./_components/actions";
import CourierNotAvailable from "./_components/courier-not-available";
import { Header } from "./_components/header";
import { Pincodes } from "./_components/pincodes";
import { ServicesTabs } from "./_components/services-tabs";

interface Props {
  params: Promise<{ id: string; service: CourierServices }>;
  searchParams: Promise<{
    page?: string;
    per_page?: string;
    search?: string;
  }>;
}

export default async function Page(props: Props) {
  const { id, service: activeService } = await props.params;

  const courier = await db.query.couriers.findFirst({
    where(fields, operators) {
      return operators.eq(fields.id, id);
    },
  });

  if (!courier || !courier.serviceabilityCheck.includes("pincode")) {
    return <CourierNotAvailable />;
  }

  return (
    <div className="space-y-4">
      <ServicesTabs services={courier.services} activeService={activeService} />
      <div className="w-full space-y-4">
        <div className="flex justify-between items-center flex-wrap gap-4">
          <Header courier={courier} service={activeService} />
          <Actions courier={{ id: courier.id, name: courier.name, service: activeService }} />
        </div>
        <Suspense key={nanoid()} fallback={<Pincodes pincodes={[]} totalPincodes={0} isLoading={true} />}>
          <PageWithFetch {...props} />
        </Suspense>
      </div>
    </div>
  );
}

async function PageWithFetch({ params, searchParams }: Props) {
  const { id, service } = await params;
  const searchParamsList = await searchParams;

  const page = Number(searchParamsList.page) || 1;
  const perPage = Number(searchParamsList.per_page) || 10;
  const search = searchParamsList.search || "";

  const offset = (page - 1) * perPage;

  const whereConditions = [eq(courierPincodes.courier, id), eq(courierPincodes.courierService, service)];

  if (search) {
    whereConditions.push(eq(courierPincodes.pincode, Number(search)));
  }

  const [pincodes, [{ count: totalCount }]] = await Promise.all([
    db.query.courierPincodes.findMany({
      where: and(...whereConditions),
      limit: perPage,
      offset,
      orderBy: [asc(courierPincodes.pincode)],
    }),
    db
      .select({ count: count() })
      .from(courierPincodes)
      .where(and(...whereConditions)),
  ]);

  return <Pincodes pincodes={pincodes} totalPincodes={totalCount} />;
}
