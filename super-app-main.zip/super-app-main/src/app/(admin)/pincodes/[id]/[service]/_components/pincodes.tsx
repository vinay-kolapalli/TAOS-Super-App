"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { CourierPincode } from "@/db/types";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { BulkSelectedActions } from "./bulk-selected-actions";
import { columns } from "./columns";

interface Props {
  pincodes: CourierPincode[];
  totalPincodes: number;
  isLoading?: boolean;
}

export function Pincodes({ pincodes, totalPincodes, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });
  const [rowSelection, setRowSelection] = useState({});
  const router = useRouter();

  const table = useReactTable({
    data: pincodes,
    columns,
    pageCount: Math.ceil(totalPincodes / pagination.pageSize),
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    onRowSelectionChange: setRowSelection,
    enableRowSelection: true,
    state: {
      pagination,
      rowSelection,
    },
  });

  const selectedPincodes = table.getFilteredSelectedRowModel().rows.map((row) => row.original);

  function handleApply() {
    setRowSelection({});
    table.resetRowSelection();
    router.refresh();
  }

  return (
    <div className="space-y-4">
      {selectedPincodes.length > 0 && <BulkSelectedActions selectedPincodes={selectedPincodes} onApply={handleApply} />}
      <DataTable className="w-full" table={table} isLoading={isLoading} paginationType="numeric" />
    </div>
  );
}
