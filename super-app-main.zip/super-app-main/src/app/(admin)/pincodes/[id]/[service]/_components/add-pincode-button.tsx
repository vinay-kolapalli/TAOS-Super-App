"use client";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CourierServices } from "@/data/shipping";
import { IconFile, IconPlus } from "@tabler/icons-react";
import { useState } from "react";
import { AddPincodeSheet } from "./add-pincode-sheet";
import { BulkImportSheet } from "./bulk-import-sheet";

interface Props {
  courier: { id: string; service: CourierServices };
}

export function AddPincodeButton({ courier }: Props) {
  const [showAddSheet, setShowAddSheet] = useState(false);
  const [showImportSheet, setShowImportSheet] = useState(false);

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button>Add Pincodes</Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setShowAddSheet(true)}>
            <IconPlus />
            Add Pincode
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setShowImportSheet(true)}>
            <IconFile />
            Bulk Import
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <AddPincodeSheet courier={courier} open={showAddSheet} onOpenChange={setShowAddSheet} />
      <BulkImportSheet courier={courier} open={showImportSheet} onOpenChange={setShowImportSheet} />
    </>
  );
}
