import { CourierServices } from "@/data/shipping";
import { Courier } from "@/db/types";
import { getSignedUrl } from "@/lib/s3";
import Image from "next/image";

interface Props {
  courier: Pick<Courier, "id" | "name" | "image">;
  service: CourierServices;
}

export function Header({ courier, service }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <div className="w-8 h-8 relative">
        <Image src={getSignedUrl(courier.image)} alt={courier.name} fill className="object-contain rounded-md" />
      </div>
      <div>
        <h2 className="text-base md:text-lg font-bold capitalize">
          {courier.name} {service} Pincodes
        </h2>
        <p className="text-xs md:text-sm text-muted-foreground">
          Manage serviceability pincodes • For zone mappings, visit{" "}
          <a href={`/zones/${courier.id}`} className="text-primary hover:underline">
            Zone Management
          </a>
        </p>
      </div>
    </div>
  );
}
