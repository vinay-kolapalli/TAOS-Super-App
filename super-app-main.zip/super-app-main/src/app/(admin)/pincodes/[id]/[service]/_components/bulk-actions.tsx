"use client";
import { AlertModal } from "@/components/alert-modal";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CourierServices } from "@/data/shipping";
import { orpc } from "@/lib/orpc/client";
import { safe } from "@orpc/client";
import { IconDots, IconTrash } from "@tabler/icons-react";
import { useRouter } from "next/navigation";
import { toast } from "react-hot-toast";

interface Props {
  courier: { id: string; name: string; service: CourierServices };
}

export function BulkActions({ courier }: Props) {
  const router = useRouter();

  async function handleDeleteAll() {
    const { error, data } = await safe(orpc.pincodes.deleteCourier({ id: courier.id, service: courier.service }));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    router.refresh();
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon">
          <IconDots />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <AlertModal
          onConfirm={handleDeleteAll}
          title="Delete All Pincodes"
          description={`Are you sure you want to delete all pincodes for ${courier.name}? This action cannot be undone.`}
        >
          <DropdownMenuItem className="text-destructive" onSelect={(e) => e.preventDefault()}>
            <IconTrash />
            Delete All
          </DropdownMenuItem>
        </AlertModal>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
