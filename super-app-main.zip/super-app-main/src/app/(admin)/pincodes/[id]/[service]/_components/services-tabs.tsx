import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CourierServices } from "@/data/shipping";
import Link from "next/link";

interface Props {
  services: CourierServices[];
  activeService?: CourierServices;
}

export function ServicesTabs({ services, activeService }: Props) {
  return (
    <Tabs defaultValue={activeService}>
      <TabsList>
        {services.map((service) => (
          <TabsTrigger key={service} value={service}>
            <Link href={`./${service}`} className="capitalize">
              {service}
            </Link>
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );
}
