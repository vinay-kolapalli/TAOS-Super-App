"use client";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { CourierServices } from "@/data/shipping";
import { CourierPincode } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { BulkImportSchema, bulkImportSchema } from "./schema";

interface Props {
  courier: { id: string; service: CourierServices };
  onSuccess?: () => void;
}

export function BulkImportForm({ courier, onSuccess }: Props) {
  const form = useForm<BulkImportSchema>({
    resolver: zodResolver(bulkImportSchema),
  });
  const { isSubmitting } = form.formState;

  function parseCSVFile(text: string): Omit<CourierPincode, "id">[] {
    const lines = text.split("\n").filter((line) => line.trim());
    if (lines.length === 0) {
      throw new Error("File is empty");
    }

    if (lines.length < 2) {
      throw new Error("CSV must contain at least a header row and one data row");
    }

    // Parse header row
    const headerLine = lines[0].trim();
    const headers = headerLine.split(",").map((h) => h.trim());

    if (headers.length < 2 || headers[0].toLowerCase() !== "pincode") {
      throw new Error("First column must be 'pincode' in header row");
    }

    const metadataKeys = headers.slice(1); // All columns after pincode are metadata keys

    const pincodes: Omit<CourierPincode, "id">[] = [];

    // Parse data rows
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const parts = line.split(",").map((p) => p.trim());

      if (parts.length !== headers.length) {
        throw new Error(`Line ${i + 1}: Expected ${headers.length} columns, got ${parts.length}`);
      }

      const pincodeValue = parts[0];

      if (!pincodeValue || isNaN(Number(pincodeValue))) {
        throw new Error(`Invalid pincode at line ${i + 1}: ${pincodeValue}`);
      }

      const metadata = [];
      // Map values to metadata keys from header
      for (let j = 1; j < parts.length; j++) {
        const key = metadataKeys[j - 1];
        const value = parts[j];

        if (key && value) {
          metadata.push({ key, value });
        }
      }

      pincodes.push({
        pincode: Number(pincodeValue),
        metadata,
        courier: courier.id,
        courierService: courier.service,
      });
    }

    if (pincodes.length === 0) {
      throw new Error("No valid pincodes found in file");
    }

    return pincodes;
  }

  async function handleFileUpload(values: BulkImportSchema) {
    try {
      const file = values.file;
      const text = await file.text();

      const pincodes = parseCSVFile(text);

      const { error, data } = await safe(orpc.pincodes.create(pincodes));
      if (error) {
        toast.error(error.message);
        return;
      }

      toast.success(data.message);
      onSuccess?.();
    } catch (error) {
      const message = error instanceof Error ? error.message : "An error occurred while processing the file";
      form.setError("file", { message });
    }
  }

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue("file", file);
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFileUpload)} className="space-y-4">
        <FormField
          control={form.control}
          name="file"
          render={() => (
            <FormItem>
              <FormLabel>CSV File</FormLabel>
              <FormControl>
                <Input type="file" accept=".csv" onChange={handleFileSelect} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button disabled={isSubmitting} isLoading={isSubmitting} className="w-full">
          Import
        </Button>
      </form>
    </Form>
  );
}
