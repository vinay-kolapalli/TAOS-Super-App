import { Card, CardContent } from "@/components/ui/card";
import { Truck } from "lucide-react";

export default function Page() {
  return (
    <Card>
      <CardContent className="text-center py-12">
        <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-muted flex items-center justify-center">
          <Truck className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold mb-2">Select a Courier</h3>
        <p className="text-muted-foreground mb-6 max-w-md mx-auto">
          Choose a courier to view and manage their pincode serviceability data, delivery zones, and coverage areas.
        </p>
      </CardContent>
    </Card>
  );
}
