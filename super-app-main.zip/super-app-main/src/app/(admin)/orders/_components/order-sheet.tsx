import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { orpc } from "@/lib/orpc/client";
import { Address, LineItem, Order, OrderCalculations as OrderCalculationsType, Tracking } from "@/types/order";
import { safe } from "@orpc/client";
import { IconEdit } from "@tabler/icons-react";
import { format } from "date-fns";
import Image from "next/image";
import { useState } from "react";
import toast from "react-hot-toast";
import { EditAddressSheet } from "./edit-address-sheet";

interface Props {
  order: Order;
  children: React.ReactNode;
}

export function OrderSheet({ order, children }: Props) {
  const [updatedOrder, setUpdatedOrder] = useState(order);

  async function handleShippingChange(value: Address) {
    const newOrder = { ...updatedOrder, shipping: value };
    setUpdatedOrder(newOrder);
    await handleOrderUpdate(newOrder);
  }

  async function handleOrderUpdate(updatedOrder: Order) {
    const { error, data } = await safe(orpc.store.orders.update([updatedOrder]));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
  }

  return (
    <Sheet>
      <SheetTrigger asChild>{children}</SheetTrigger>
      <SheetContent className="md:!max-w-2xl w-full space-y-2">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-3">
            #{order.number}
            <Badge className="capitalize">{order.status}</Badge>
          </SheetTitle>
          <SheetDescription className="flex">
            Order placed by {order.billing.firstName} {order.billing.lastName} on{" "}
            {format(order.createdAt, "dd MMM yyyy")}
          </SheetDescription>
        </SheetHeader>
        <ScrollArea className="h-[90dvh]">
          <div className="space-y-4 pb-4">
            <div className="grid lg:grid-cols-2 gap-5">
              <AddressCard title="Billing Address" address={updatedOrder.billing} />
              <AddressCard title="Shipping Address" address={updatedOrder.shipping} onSave={handleShippingChange} />
            </div>
            <ProductList lineItems={order.lineItems} />
            <div className="grid lg:grid-cols-2 gap-5">
              <ShippingInfo order={order} />
              {updatedOrder.tracking && <TrackingInfo tracking={updatedOrder.tracking} />}
            </div>
            <OrderCalculations
              calculations={order.calculations}
              coupons={order.coupons}
              rewardPoints={order.metadata.rewardPointsRedeemed}
            />
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}

interface AddressProps {
  title: string;
  address: Address;
  onSave?: (value: Address) => void;
}

function AddressCard({ title, address, onSave }: AddressProps) {
  return (
    <div>
      <div className="flex justify-between items-center gap-4">
        <h3 className="font-semibold">{title}</h3>
        {onSave && (
          <EditAddressSheet title={title} address={address} onSave={onSave}>
            <Button type="button" variant="ghost" size="icon">
              <IconEdit />
            </Button>
          </EditAddressSheet>
        )}
      </div>
      <address className="text-sm">
        {address.firstName} {address.lastName}
        <br />
        {address.address1}
        <br />
        {address.address2}
        <br />
        {address.city} {address.state}
        <br />
        {address.postcode}
        <br />
        Phone: {address.phone}
        {address.email && (
          <>
            <br />
            Email: {address.email}
          </>
        )}
      </address>
    </div>
  );
}

interface ProductListProps {
  lineItems: LineItem[];
}

function ProductList({ lineItems }: ProductListProps) {
  return (
    <div>
      <h3 className="font-semibold mb-2">Products</h3>
      <ScrollArea className="h-60 max-h-fit *:max-h-fit">
        <div className="space-y-2">
          {lineItems.map((item) => (
            <div key={item.id} className="flex items-center gap-2 w-full">
              <Image
                src={item.image}
                alt={item.name}
                width={50}
                height={50}
                className="aspect-square object-cover rounded-lg border"
                onError={(e) => (e.currentTarget.src = "/images/placeholder.png")}
              />
              <div className="w-full">
                <div className="font-semibold">
                  {item.name} x {item.quantity}
                </div>
                <div className="text-sm flex justify-between gap-2">
                  <span>SKU: {item.sku}</span>
                  <span>
                    ₹{item.price} x {item.quantity} = ₹{item.total}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}

interface ShippingInfoProps {
  order: Order;
}

function ShippingInfo({ order }: ShippingInfoProps) {
  return (
    <div>
      <h3 className="font-semibold mb-2">Shipping Method</h3>
      <div>
        <h4>{order.shippingMethod}</h4>
      </div>
      {order.metadata.note && (
        <>
          <h3 className="font-semibold mb-2">Note</h3>
          <div>
            <ScrollArea className="h-20 max-h-fit *:max-h-fit">{order.metadata.note}</ScrollArea>
          </div>
        </>
      )}
    </div>
  );
}

interface TrackingInfoProps {
  tracking: Tracking;
  onSave?: (value: Tracking) => void;
}

function TrackingInfo({ tracking, onSave }: TrackingInfoProps) {
  if (!tracking) return null;

  return (
    <div>
      <div className="flex justify-between items-center gap-4">
        <h3 className="font-semibold">Tracking</h3>
      </div>
      <div>
        <h4 className="font-medium">{tracking.courierName}</h4>
        <p>{tracking.trackingNumber}</p>
        <p>{tracking.shippedAt ? format(tracking.shippedAt, "dd MMM yyyy") : "No Date"}</p>
      </div>
    </div>
  );
}

interface OrderCalculationsProps {
  calculations: OrderCalculationsType;
  coupons: string[];
  rewardPoints: number;
}

function OrderCalculations({ calculations, coupons, rewardPoints }: OrderCalculationsProps) {
  return (
    <div>
      <h3 className="font-semibold mb-2">Calculations</h3>
      <div>
        <div className="flex justify-between">
          <span className="font-medium">Subtotal</span>
          <span>₹{calculations.subtotal}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-medium">Discount</span>
          <span>-₹{calculations.discount}</span>
        </div>
        {coupons.length > 0 && (
          <div>
            <span className="font-medium">Coupons</span>
            <ol className="bg-secondary p-2 rounded-lg">
              {coupons.map((coupon) => (
                <li className="flex justify-between gap-2" key={coupon}>
                  <span className="flex items-center gap-2">{coupon}</span>
                </li>
              ))}
            </ol>
          </div>
        )}
        <div className="flex justify-between">
          <span className="font-medium">Reward points</span>
          <span>-{rewardPoints}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-medium">Shipping</span>
          <span>₹{calculations.shipping}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-medium">Tax (Included)</span>
          <span>₹{calculations.tax}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-medium">Total</span>
          <span>₹{calculations.total}</span>
        </div>
      </div>
    </div>
  );
}
