"use client";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { queryClient } from "@/context/react-query-context";
import { useWarehouses } from "@/hooks/warehouse";
import { generateInvoices } from "@/lib/invoice";
import { orpc } from "@/lib/orpc/client";
import { generatePackingSlips } from "@/lib/packing-slip";
import { tryCatch } from "@/lib/try-catch";
import { Order } from "@/types/order";
import { printBuffer } from "@/utils/print";
import { safe } from "@orpc/client";
import { IconChevronDown } from "@tabler/icons-react";
import { useState } from "react";
import toast from "react-hot-toast";

interface Props {
  selectedOrders: Order[];
  onApply?: () => void;
}

export function BulkActions({ selectedOrders, onApply }: Props) {
  const [isLoading, setIsLoading] = useState(false);
  const { data: warehouses } = useWarehouses();

  async function handleStatusChange(newStatus: string) {
    setIsLoading(true);
    const toastId = toast.loading("Updating order status...");
    const { error, data } = await safe(
      orpc.store.orders.update(
        selectedOrders.map((order) => ({
          id: order.id,
          tags: [...order.tags.filter((tag) => !tag.startsWith("status:")), `status:${newStatus}`],
        }))
      )
    );
    if (error) {
      toast.error(error.message, { id: toastId });
      setIsLoading(false);
      return;
    }
    queryClient.invalidateQueries();
    toast.success(data.message, { id: toastId });
    setIsLoading(false);
    onApply?.();
  }

  async function handlePrintInvoice() {
    setIsLoading(true);
    const toastId = toast.loading("Printing invoices...");
    const { data, error } = await tryCatch(generateInvoices(selectedOrders));
    if (error) {
      toast.error("Failed to print invoices", { id: toastId });
      setIsLoading(false);
      return;
    }
    const print = await tryCatch(printBuffer(data));
    setIsLoading(false);

    if (print.error) {
      toast.error(print.error.message, { id: toastId });
      return;
    }

    toast.dismiss(toastId);
    onApply?.();
  }

  async function handlePrintPackingSlip() {
    setIsLoading(true);
    const toastId = toast.loading("Printing packing slips...");
    const { data, error } = await tryCatch(generatePackingSlips(selectedOrders));
    if (error) {
      toast.error("Failed to print packing slips", { id: toastId });
      setIsLoading(false);
      return;
    }
    const print = await tryCatch(printBuffer(data));
    setIsLoading(false);

    if (print.error) {
      toast.error(print.error.message, { id: toastId });
      return;
    }

    toast.dismiss(toastId);
    onApply?.();
  }

  async function handleWarehouseChange(warehouseId: number) {
    setIsLoading(true);
    const toastId = toast.loading("Updating order tags...");
    const changeTagsResponse = await safe(
      orpc.store.orders.update(
        selectedOrders.map((order) => ({
          id: order.id,
          tags: [...order.tags.filter((tag) => !tag.startsWith("warehouse:")), `warehouse:${warehouseId}`],
        }))
      )
    );
    if (changeTagsResponse.error) {
      toast.error(changeTagsResponse.error.message, { id: toastId });
      setIsLoading(false);
      return;
    }
    toast.loading("Updating warehouse...");
    const changeWarehouseResponse = await safe(
      orpc.store.orders.changeWarehouse({
        orders: selectedOrders.map((order) => order.id),
        warehouse: warehouseId,
      })
    );
    if (changeWarehouseResponse.error) {
      toast.error(changeWarehouseResponse.error.message, { id: toastId });
      setIsLoading(false);
      return;
    }
    queryClient.invalidateQueries();
    toast.success(changeWarehouseResponse.data.message, { id: toastId });
    setIsLoading(false);
    onApply?.();
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          type="button"
          variant="outline"
          disabled={isLoading || selectedOrders.length === 0}
          className="flex items-center gap-2"
        >
          Bulk Actions
          <IconChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start">
        <DropdownMenuSub>
          <DropdownMenuSubTrigger>Change Status</DropdownMenuSubTrigger>
          <DropdownMenuSubContent>
            <DropdownMenuItem onClick={() => handleStatusChange("on-hold")}>On hold</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("processing")}>Processing</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("printed")}>Printed</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("previewed")}>Previewed</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("shipped")}>Shipped</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("reship")}>Reship</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("reshipped")}>Reshipped</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleStatusChange("address-issue")}>Address Issue</DropdownMenuItem>
          </DropdownMenuSubContent>
        </DropdownMenuSub>
        <DropdownMenuSub>
          <DropdownMenuSubTrigger>Print</DropdownMenuSubTrigger>
          <DropdownMenuSubContent>
            <DropdownMenuItem onClick={handlePrintInvoice}>Invoice</DropdownMenuItem>
            <DropdownMenuItem onClick={handlePrintPackingSlip}>Packing Slip</DropdownMenuItem>
          </DropdownMenuSubContent>
        </DropdownMenuSub>
        <DropdownMenuSub>
          <DropdownMenuSubTrigger>Assign Warehouse</DropdownMenuSubTrigger>
          <DropdownMenuSubContent>
            {warehouses?.map((warehouse) => (
              <DropdownMenuItem key={warehouse.id} onClick={() => handleWarehouseChange(warehouse.id)}>
                {warehouse.name}
              </DropdownMenuItem>
            ))}
          </DropdownMenuSubContent>
        </DropdownMenuSub>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
