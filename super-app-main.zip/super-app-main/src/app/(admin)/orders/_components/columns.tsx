"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useWarehouses } from "@/hooks/warehouse";
import { generateBarcodeProductLabels, generateQRProductLabels } from "@/lib/label";
import { tryCatch } from "@/lib/try-catch";
import { Order } from "@/types/order";
import { printBuffer } from "@/utils/print";
import { IconBarcode, IconEye, IconQrcode } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import toast from "react-hot-toast";
import { OrderSheet } from "./order-sheet";

export const columns: ColumnDef<Order>[] = [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={table.getIsAllPageRowsSelected() || (table.getIsSomePageRowsSelected() && "indeterminate")}
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    id: "ORDER_NUMBER",
    accessorKey: "number",
    header: "Order Number",
    enableSorting: true,
    enableHiding: false,
  },
  {
    accessorKey: "shipping",
    header: "Name",
    cell: ({ row }) => {
      const shipping = row.original.shipping;
      return (
        <div>
          {shipping.firstName} {shipping.lastName}
        </div>
      );
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    id: "PROCESSED_AT",
    accessorKey: "createdAt",
    header: "Created At",
    cell: ({ row }) => {
      const createdAt = row.original.createdAt;
      return <div>{format(createdAt, "dd MMM yyyy")}</div>;
    },
    enableSorting: true,
    enableHiding: false,
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.original.status;
      return (
        <Badge variant="outline" className="border capitalize">
          {status}
        </Badge>
      );
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "warehouse",
    header: "Warehouse",
    cell: ({ row }) => {
      return <WarehouseColumn id={row.original.warehouse} />;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "tracking",
    header: "Tracking",
    cell: ({ row }) => {
      const tracking = row.original.tracking;
      if (!tracking) return <div>-</div>;
      return (
        <div className="flex flex-col">
          <span className="font-semibold">{tracking.courierName}</span>
          <span>{tracking.trackingNumber}</span>
        </div>
      );
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "lineItems",
    header: "Actions",
    cell: ({ row }) => {
      const labelData = row.original.lineItems.flatMap((item) => {
        const labels = [];
        for (let i = 0; i < item.quantity; i++) {
          labels.push({
            orderNumber: row.original.number,
            productName: `${item.name} X ${item.quantity}`,
            value: String(item.price),
            tags: item.tags,
          });
        }
        return labels;
      });

      async function printQrLabels() {
        const filteredLabelData = labelData.filter(
          (item) =>
            item.tags.some((tag) => tag.toLowerCase() === "plant") &&
            !item.productName.toLowerCase().includes("donate") &&
            !item.productName.toLowerCase().includes("gift wrap")
        );
        const qr = await generateQRProductLabels(filteredLabelData);
        const print = await tryCatch(printBuffer(qr));
        if (print.error) {
          toast.error(print.error.message);
          return;
        }
      }

      async function printBarcodeLabels() {
        const filteredLabelData = labelData.filter(
          (item) =>
            !item.tags.some((tag) => tag.toLowerCase() === "plant") &&
            !item.productName.toLowerCase().includes("donate") &&
            !item.productName.toLowerCase().includes("gift wrap")
        );
        const barcode = await generateBarcodeProductLabels(filteredLabelData);
        const print = await tryCatch(printBuffer(barcode));
        if (print.error) {
          toast.error(print.error.message);
          return;
        }
      }

      return (
        <div className="space-x-2">
          <OrderSheet order={row.original}>
            <Button title="View" type="button" variant="ghost" size="icon">
              <IconEye />
            </Button>
          </OrderSheet>

          {(row.original.status === "printed" ||
            row.original.status === "reship" ||
            row.original.status === "shipped" ||
            row.original.status === "reshipped" ||
            row.original.status === "completed") && (
            <>
              <Button title="Qr Label" type="button" variant="outline" size="icon" onClick={printQrLabels}>
                <IconQrcode />
              </Button>
              <Button title="Barcode Label" type="button" variant="secondary" size="icon" onClick={printBarcodeLabels}>
                <IconBarcode />
              </Button>
            </>
          )}
        </div>
      );
    },
    enableSorting: false,
    enableHiding: false,
  },
];

function WarehouseColumn({ id }: { id: number | null }) {
  const { data: warehouses } = useWarehouses();
  const warehouse = warehouses?.find((warehouse) => warehouse.id === id);
  return <div>{warehouse?.name ?? "-"}</div>;
}
