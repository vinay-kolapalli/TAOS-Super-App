"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { orpc } from "@/lib/orpc/client";
import { safe } from "@orpc/client";
import { useMemo, useState } from "react";
import toast from "react-hot-toast";

export function TaxReport() {
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const currentMonth = useMemo(() => String(new Date().getMonth() + 1).padStart(2, "0"), []);
  const currentYear = useMemo(() => new Date().getFullYear(), []);

  async function handleGenerate(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    let toastId = toast.loading("Initiating tax report generation...");
    setIsLoading(true);
    setOpen(false);

    const formData = new FormData(e.target as HTMLFormElement);
    const month = formData.get("month") as string;
    const year = formData.get("year") as string;

    const { data, error } = await safe(
      orpc.store.report.tax({
        month: Number(month),
        year: Number(year),
      })
    );

    setIsLoading(false);

    if (error) {
      toast.error(error.message, {
        id: toastId,
      });
      return;
    }

    toast.success(data.message, {
      id: toastId,
    });
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" disabled={isLoading} isLoading={isLoading}>
          Tax Report
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0 rounded-xl">
        <Card className="p-3 space-y-3 shadow-none border-none">
          <CardHeader className="p-0">
            <CardTitle className="text-sm">Tax Report</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <form className="space-y-3" onSubmit={handleGenerate}>
              <Select defaultValue={String(currentMonth)} name="month">
                <SelectTrigger>
                  <SelectValue placeholder="Select a month" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="01">January</SelectItem>
                  <SelectItem value="02">February</SelectItem>
                  <SelectItem value="03">March</SelectItem>
                  <SelectItem value="04">April</SelectItem>
                  <SelectItem value="05">May</SelectItem>
                  <SelectItem value="06">June</SelectItem>
                  <SelectItem value="07">July</SelectItem>
                  <SelectItem value="08">August</SelectItem>
                  <SelectItem value="09">September</SelectItem>
                  <SelectItem value="10">October</SelectItem>
                  <SelectItem value="11">November</SelectItem>
                  <SelectItem value="12">December</SelectItem>
                </SelectContent>
              </Select>
              <Select defaultValue={String(currentYear)} name="year">
                <SelectTrigger>
                  <SelectValue placeholder="Select a year" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 3 }).map((_, index) => {
                    const year = currentYear - (2 - index);
                    return (
                      <SelectItem key={year} value={String(year)}>
                        {year}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              <Button className="w-full" disabled={isLoading} isLoading={isLoading}>
                Generate
              </Button>
            </form>
          </CardContent>
        </Card>
      </PopoverContent>
    </Popover>
  );
}
