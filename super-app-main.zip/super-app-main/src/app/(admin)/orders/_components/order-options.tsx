"use client";
import { Search } from "@/components/search";
import { Button } from "@/components/ui/button";
import { UserWarehouseSelect } from "@/components/warehouse-select";
import { queryClient } from "@/context/react-query-context";
import { IconRefresh } from "@tabler/icons-react";
import { useQueryState } from "nuqs";
import { useOrdersProvider } from "../_context/orders";
import { BulkActions } from "./bulk-actions";
import { TaxReport } from "./tax-report";

export function OrderOptions() {
  const { table, selectedOrders, refetch } = useOrdersProvider();
  const [warehouse, setWarehouse] = useQueryState("warehouse", {
    shallow: false,
  });

  function handleApply() {
    table.setRowSelection({});
  }

  function handleRefresh() {
    refetch();
    queryClient.refetchQueries({ queryKey: ["fetch-orders-count"] });
  }

  return (
    <div className="flex flex-wrap gap-4">
      <BulkActions selectedOrders={selectedOrders} onApply={handleApply} />
      <Search />
      <TaxReport />
      <UserWarehouseSelect value={warehouse ? Number(warehouse) : undefined} onValueChange={setWarehouse} />
      <Button title="Refresh" type="button" size="icon" variant="outline" onClick={handleRefresh}>
        <IconRefresh />
      </Button>
    </div>
  );
}
