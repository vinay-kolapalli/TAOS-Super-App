"use client";
import { DataTable } from "@/components/ui/data-table";
import { useOrdersProvider } from "../_context/orders";

export function Orders() {
  const { table, isFetching } = useOrdersProvider();

  return (
    <DataTable table={table} isLoading={isFetching} paginationType="cursor" extraPaginationOptions={[150, 200, 250]} />
  );
}
