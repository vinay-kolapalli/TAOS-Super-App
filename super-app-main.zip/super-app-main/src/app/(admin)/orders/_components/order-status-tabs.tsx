"use client";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useOrdersCount } from "@/hooks/order";
import { useQueryState } from "nuqs";

export function OrderStatusTabs() {
  const [status, setStatus] = useQueryState("status", {
    defaultValue: "all",
  });
  const [warehouse] = useQueryState("warehouse");
  const { data } = useOrdersCount({ warehouses: warehouse ? [Number(warehouse)] : null });

  return (
    <Tabs value={status} onValueChange={setStatus}>
      <TabsList className="flex-wrap h-fit justify-start gap-y-2">
        <TabsTrigger value="all">All {renderCount(data?.all)}</TabsTrigger>
        <TabsTrigger value="on-hold">On hold {renderCount(data?.onHold)}</TabsTrigger>
        <TabsTrigger value="processing">Processing {renderCount(data?.processing)}</TabsTrigger>
        <TabsTrigger value="previewed">Previewed {renderCount(data?.previewed)}</TabsTrigger>
        <TabsTrigger value="printed">Printed {renderCount(data?.printed)}</TabsTrigger>
        <TabsTrigger value="shipped">Shipped {renderCount(data?.shipped)}</TabsTrigger>
        <TabsTrigger value="cancelled">Cancelled {renderCount(data?.cancelled)}</TabsTrigger>
        <TabsTrigger value="address-issue">Address Issue {renderCount(data?.addressIssue)}</TabsTrigger>
        <TabsTrigger value="reship">Reship {renderCount(data?.reship)}</TabsTrigger>
        <TabsTrigger value="reshipped">Reshipped {renderCount(data?.reshipped)}</TabsTrigger>
        <TabsTrigger value="rto">RTO {renderCount(data?.rto)}</TabsTrigger>
        <TabsTrigger value="refunded">Refunded {renderCount(data?.refunded)}</TabsTrigger>
      </TabsList>
    </Tabs>
  );
}

function renderCount(count?: number) {
  if (count !== undefined && count >= 0) {
    return <span className="ml-1">({count === 10000 ? "9999+" : count})</span>;
  }
  return null;
}
