"use client";
import { usePaginationSearchParams, useSortingSearchParams } from "@/components/ui/data-table";
import { useOrders } from "@/hooks/order";
import { Order } from "@/types/order";
import { getCoreRowModel, Table, useReactTable } from "@tanstack/react-table";
import { useQueryState } from "nuqs";
import { createContext, useContext, useMemo, useState } from "react";
import { columns } from "../_components/columns";

export const OrdersContext = createContext<{
  table: Table<Order>;
  selectedOrders: Order[];
  isFetching: boolean;
  refetch: () => void;
}>({} as any);

export const useOrdersProvider = () => useContext(OrdersContext);

export function OrdersProvider({ children }: { children: React.ReactNode }) {
  const [rowSelection, setRowSelection] = useState({});
  const [status] = useQueryState("status");
  const [search] = useQueryState("search");
  const [pagination, setPagination] = usePaginationSearchParams();
  const [after, setAfter] = useQueryState("after", { defaultValue: "" });
  const [before, setBefore] = useQueryState("before", { defaultValue: "" });
  const [sorting, setSorting] = useSortingSearchParams({ default: { id: "PROCESSED_AT", desc: true } });
  const [warehouse] = useQueryState("warehouse");

  const { data, isFetching, refetch } = useOrders({
    perPage: pagination.pageSize,
    after,
    before,
    search: search ?? undefined,
    status: status ?? undefined,
    sort: sorting[0]?.desc ? "desc" : "asc",
    sortBy: sorting[0]?.id,
    warehouses: warehouse ? [Number(warehouse)] : undefined,
  });

  const orders = useMemo(() => data?.orders ?? [], [data]);
  const selectedOrders = useMemo(
    () => Object.keys(rowSelection).map((key) => orders[Number(key)]),
    [orders, rowSelection]
  );

  const table = useReactTable({
    data: orders,
    columns,
    pageCount: data?.hasNextPage ? Infinity : undefined,
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    manualSorting: true,
    enableSortingRemoval: false,
    onPaginationChange: (updater) => {
      const newPagination = typeof updater === "function" ? updater(pagination) : updater;

      // Set after and before cursor based on pagination change
      if (newPagination.pageIndex > pagination.pageIndex) {
        setAfter(data?.endCursor ?? "");
        setBefore("");
      } else if (newPagination.pageIndex < pagination.pageIndex) {
        setAfter("");
        setBefore(data?.startCursor ?? "");
      }

      setPagination(newPagination);
    },
    onSortingChange: setSorting,
    onRowSelectionChange: setRowSelection,
    state: {
      rowSelection,
      pagination,
      sorting,
    },
  });

  return (
    <OrdersContext.Provider
      value={{
        table,
        selectedOrders,
        isFetching,
        refetch,
      }}
    >
      {children}
    </OrdersContext.Provider>
  );
}
