import { OrderOptions } from "./_components/order-options";
import { OrderStatusTabs } from "./_components/order-status-tabs";
import { Orders } from "./_components/orders";

export default async function Page() {
  return (
    <div className="w-full space-y-4">
      <OrderStatusTabs />
      <OrderOptions />
      <Orders />
    </div>
  );
}
