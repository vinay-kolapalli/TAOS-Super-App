import { getSession } from "@/lib/auth";
import { getEndOfDay, getStartOfDay } from "@/utils/date";
import { BoxesBreakdown } from "./_components/boxes-breakdown";
import { CourierBreakdown } from "./_components/courier-breakdown";
import { DashboardFilters } from "./_components/dashboard-filters";
import { DashboardSummary } from "./_components/dashboard-summary";
import { PlatformBreakdown } from "./_components/platform-breakdown";
import { DashboardFilter } from "./_types/dashboard";

interface Props {
  searchParams: Promise<{
    from: string;
    to: string;
    warehouse_id: string;
  }>;
}

export default async function Page(props: Props) {
  const searchParams = await props.searchParams;

  const session = await getSession();
  if (!session?.user) {
    throw new Error("Unauthorized");
  }

  const warehouse = searchParams.warehouse_id ? Number(searchParams.warehouse_id) : undefined;
  const userWarehouses = [session.user.primaryWarehouse, ...session.user.otherWarehouses];
  const validWarehouseId = warehouse && userWarehouses.includes(warehouse) ? warehouse : undefined;
  const from = getStartOfDay(searchParams.from || new Date());
  const to = getEndOfDay(searchParams.to || new Date());

  const filters: DashboardFilter = {
    dateRange: {
      from,
      to,
    },
    warehouseId: validWarehouseId,
  };

  return (
    <div className="space-y-4 w-full">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-lg font-bold">Dashboard</h2>
        <div className="flex gap-4 justify-between flex-wrap">
          <DashboardFilters />
        </div>
      </div>
      <div className="space-y-6">
        <DashboardSummary filters={filters} userWarehouses={userWarehouses} />
        <CourierBreakdown filters={filters} userWarehouses={userWarehouses} />
        <PlatformBreakdown filters={filters} userWarehouses={userWarehouses} />
        <BoxesBreakdown filters={filters} userWarehouses={userWarehouses} />
      </div>
    </div>
  );
}
