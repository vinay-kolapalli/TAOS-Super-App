import { Card, CardContent } from "@/components/ui/card";
import { db } from "@/db";
import { rates } from "@/db/schema/rates";
import { IconPackage } from "@tabler/icons-react";
import { redirect } from "next/navigation";

export default async function Page() {
  if (process.env.NEXT_PHASE === "phase-production-build") {
    return null;
  }

  const courier = await db.query.couriers.findFirst({
    columns: { id: true },
    orderBy(fields, operators) {
      return operators.asc(fields.id);
    },
  });

  if (!courier) {
    return (
      <Card className="border-none w-full">
        <CardContent className="p-0">
          <div className="text-center py-12">
            <div className="mx-auto mb-6 w-fit rounded-full bg-muted p-4">
              <IconPackage className="h-8 w-8 text-muted-foreground" />
            </div>
            <div className="mx-auto max-w-md space-y-3">
              <h3 className="text-xl font-semibold">No Couriers Available</h3>
              <p className="text-muted-foreground">
                You need to add at least one courier before creating a rate. Couriers are required to define shipping
                rates and delivery options.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const [newRate] = await db
    .insert(rates)
    .values({
      description: "",
      displayName: "New Rate",
      service: "surface",
      courier: courier.id,
      isActive: false,
    })
    .returning({ id: rates.id });

  return redirect(`/rates/${newRate.id}`);
}
