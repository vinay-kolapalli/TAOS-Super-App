import { Skeleton } from "@/components/ui/skeleton";
import { IconLoader2 } from "@tabler/icons-react";

export default function Loading() {
  return (
    <div className="w-full space-y-6">
      <Skeleton className="h-8 w-48" />

      <div className="text-center py-12">
        <IconLoader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
        <p className="text-lg font-medium">Creating new rate configuration...</p>
      </div>

      <Skeleton className="h-32 w-full" />
    </div>
  );
}
