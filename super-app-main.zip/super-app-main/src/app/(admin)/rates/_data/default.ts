import { ConditionInput, SlabInput } from "../_types/editor";

export const defaultSlab: SlabInput = {
  id: "",
  slabName: "New Rate Slab",
  platformId: "",
  minWeight: 0,
  maxWeight: 0.5,
  additionalUnit: 0.5,
  additionalMaxWeight: 100,
  localBaseRate: 0,
  localAdditionalRate: 0,
  regionalBaseRate: 0,
  regionalAdditionalRate: 0,
  metroBaseRate: 0,
  metroAdditionalRate: 0,
  restOfIndiaBaseRate: 0,
  restOfIndiaAdditionalRate: 0,
  northEastBaseRate: 0,
  northEastAdditionalRate: 0,
  isActive: true,
};

export const defaultCondition: ConditionInput = {
  id: "",
  name: "New Condition",
  values: [],
  operator: "equals",
  type: "state",
};
