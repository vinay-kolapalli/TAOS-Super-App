import { RateConditionOperators, RateConditions } from "@/data/shipping";
import { statesList } from "@/data/states";

export const conditionTypes: {
  value: RateConditions;
  label: string;
  placeholder: string;
  type: "select" | "input";
  options?: { label: string; value: string }[];
}[] = [
  {
    value: "state",
    label: "States",
    placeholder: "Maharashtra, Gujarat",
    type: "select",
    options: statesList.map((s) => ({ value: s.stateCode, label: s.name })),
  },
  {
    value: "city",
    label: "Cities",
    placeholder: "Mumbai, Pune",
    type: "input",
  },
  {
    value: "warehouse",
    label: "Warehouses",
    placeholder: "1, 8",
    type: "select",
  },
  {
    value: "box",
    label: "Boxes",
    placeholder: "env, sm, box-1",
    type: "select",
  },
  {
    value: "shipping_method",
    label: "Shipping Methods",
    placeholder: "next, standard",
    type: "input",
  },
  {
    value: "pincode",
    label: "Pincodes",
    placeholder: "400001, 411001",
    type: "input",
  },
  {
    value: "weight",
    label: "Weight",
    placeholder: "0.5, 1.2, 2.0",
    type: "input",
  },
];

export const conditionOperators: {
  value: RateConditionOperators;
  label: string;
}[] = [
  {
    value: "equals",
    label: "Equals",
  },
  {
    value: "not_equals",
    label: "Not Equals",
  },
  {
    value: "less_than",
    label: "Less Than",
  },
  {
    value: "greater_than",
    label: "Greater Than",
  },
];
