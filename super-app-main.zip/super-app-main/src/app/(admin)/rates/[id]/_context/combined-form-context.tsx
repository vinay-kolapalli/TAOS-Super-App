"use client";
import { Rate, RateCondition, RateSlab } from "@/db/types";
import { SelectOption } from "@/types/general";
import { zodResolver } from "@hookform/resolvers/zod";
import { createContext, useContext, useState } from "react";
import { useForm, UseFormReturn } from "react-hook-form";
import { ConditionInput, SlabInput } from "../../_types/editor";
import { EditRateSchema, editRateSchema } from "../_components/schema";

interface CombinedFormContextProps {
  rateForm: UseFormReturn<EditRateSchema>;
  slabs: SlabInput[];
  setSlabs: (slabs: SlabInput[]) => void;
  conditions: ConditionInput[];
  setConditions: (conditions: ConditionInput[]) => void;
  originalRate: Rate;
  couriers: SelectOption[];
  boxes: SelectOption[];
  warehouses: SelectOption[];
  isSaving: boolean;
  setSaving: (saving: boolean) => void;
}

const CombinedFormContext = createContext<CombinedFormContextProps | null>(null);

interface Props {
  children: React.ReactNode;
  rate: Rate;
  couriers: SelectOption[];
  slabs: RateSlab[];
  conditions: RateCondition[];
  boxes: SelectOption[];
  warehouses: SelectOption[];
}

export function CombinedFormProvider({ children, rate, couriers, slabs, conditions, boxes, warehouses }: Props) {
  const rateForm = useForm<EditRateSchema>({
    resolver: zodResolver(editRateSchema),
    defaultValues: {
      courier: rate.courier,
      service: rate.service,
      isActive: rate.isActive,
      displayName: rate.displayName,
      description: rate.description || "",
      weightType: rate.weightType,
      platform: rate.platform,
    },
  });

  const [slabsState, setSlabs] = useState<SlabInput[]>(
    slabs.map((slab) => ({
      ...slab,
      isNew: false,
    }))
  );

  const [conditionsState, setConditions] = useState<ConditionInput[]>(
    conditions.map((condition) => ({
      ...condition,
      isNew: false,
    }))
  );

  const [isSaving, setSaving] = useState(false);

  const value: CombinedFormContextProps = {
    rateForm,
    slabs: slabsState,
    setSlabs,
    conditions: conditionsState,
    setConditions,
    originalRate: rate,
    couriers,
    boxes,
    warehouses,
    isSaving,
    setSaving,
  };

  return <CombinedFormContext.Provider value={value}>{children}</CombinedFormContext.Provider>;
}

export function useCombinedForm() {
  const context = useContext(CombinedFormContext);
  if (!context) {
    throw new Error("useCombinedForm must be used within a CombinedFormProvider");
  }
  return context;
}
