import { PageContainer, PageHeader } from "@/components/page";
import { db } from "@/db";
import { getBoxOptions, getCourierOptions } from "@/db/utils/shipping";
import { getWarehouseOptions } from "@/db/utils/warehouse";
import { redirect } from "next/navigation";
import { CombinedForm } from "./_components/combined-form";

interface Props {
  params: Promise<{ id: string }>;
}

export default async function Page({ params }: Props) {
  const { id } = await params;

  const rate = await db.query.rates.findFirst({
    where(fields, operators) {
      return operators.eq(fields.id, id);
    },
  });
  if (!rate) {
    redirect("/rates");
  }

  const [couriers, boxes, warehouses, slabs, conditions] = await Promise.all([
    getCourierOptions(),
    getBoxOptions(),
    getWarehouseOptions(),
    db.query.rateSlabs.findMany({
      where(fields, operators) {
        return operators.eq(fields.rate, rate.id);
      },
      orderBy(fields, operators) {
        return [operators.asc(fields.minWeight), operators.asc(fields.maxWeight)];
      },
    }),
    db.query.rateConditions.findMany({
      where(fields, operators) {
        return operators.eq(fields.rate, rate.id);
      },
      orderBy(fields, operators) {
        return [operators.asc(fields.id)];
      },
    }),
  ]);

  return (
    <PageContainer>
      <PageHeader title="Edit Rate" description={`Update ${rate.displayName} rate.`} />
      <CombinedForm
        rate={rate}
        couriers={couriers}
        slabs={slabs}
        conditions={conditions}
        boxes={boxes}
        warehouses={warehouses}
      />
    </PageContainer>
  );
}
