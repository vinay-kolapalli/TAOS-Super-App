"use client";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import { SlabInput } from "../../_types/editor";
import { EntityHeader } from "./entity-header";
import { NumberInput } from "./number-input";
import { TextInput } from "./text-input";

interface Props {
  slab: SlabInput;
  onUpdate: (id: string, field: keyof SlabInput, value: string | number | boolean) => void;
  onRemove: (id: string) => void;
  onDuplicate: (id: string) => void;
}

export function Slab({ slab, onUpdate, onRemove, onDuplicate }: Props) {
  const [isEditing, setIsEditing] = useState(false);

  return (
    <Card>
      <EntityHeader
        title={
          <div className="flex flex-row items-center gap-2">
            <p>{slab.slabName}</p>
            <Badge variant={slab.isActive ? "default" : "secondary"}>{slab.isActive ? "Active" : "Inactive"}</Badge>
          </div>
        }
        description={`${slab.minWeight}kg - ${slab.maxWeight || "∞"}kg ${
          slab.additionalMaxWeight && slab.additionalUnit ? `(Max: ${slab.additionalMaxWeight}kg)` : ""
        }`}
        isEditing={isEditing}
        onToggleEdit={() => setIsEditing(!isEditing)}
        onDuplicate={() => onDuplicate(slab.id)}
        onRemove={() => onRemove(slab.id)}
        duplicateTooltip="Duplicate Slab"
        removeTooltip="Remove Slab"
      />
      <CardContent className="p-4 pt-0">
        {isEditing ? <SlabEditor slab={slab} onUpdate={onUpdate} /> : <SlabViewer slab={slab} />}
      </CardContent>
    </Card>
  );
}

interface SlabEditorProps {
  slab: SlabInput;
  onUpdate: Props["onUpdate"];
}

function SlabEditor({ slab, onUpdate }: SlabEditorProps) {
  return (
    <div className="space-y-6">
      <SlabBasicInfo slab={slab} onUpdate={onUpdate} />
      <Separator />
      <div className="space-y-6">
        <ZoneRates
          title="Local"
          baseRate={slab.localBaseRate}
          additionalRate={slab.localAdditionalRate ?? 0}
          additionalUnit={slab.additionalUnit ?? 0}
          onBaseRateChange={(value) => onUpdate(slab.id, "localBaseRate", value)}
          onAdditionalRateChange={(value) => onUpdate(slab.id, "localAdditionalRate", value)}
        />
        <ZoneRates
          title="Regional"
          baseRate={slab.regionalBaseRate}
          additionalRate={slab.regionalAdditionalRate ?? 0}
          additionalUnit={slab.additionalUnit ?? 0}
          onBaseRateChange={(value) => onUpdate(slab.id, "regionalBaseRate", value)}
          onAdditionalRateChange={(value) => onUpdate(slab.id, "regionalAdditionalRate", value)}
        />
        <ZoneRates
          title="Metro"
          baseRate={slab.metroBaseRate}
          additionalRate={slab.metroAdditionalRate ?? 0}
          additionalUnit={slab.additionalUnit ?? 0}
          onBaseRateChange={(value) => onUpdate(slab.id, "metroBaseRate", value)}
          onAdditionalRateChange={(value) => onUpdate(slab.id, "metroAdditionalRate", value)}
        />
        <ZoneRates
          title="Rest of India"
          baseRate={slab.restOfIndiaBaseRate}
          additionalRate={slab.restOfIndiaAdditionalRate ?? 0}
          additionalUnit={slab.additionalUnit ?? 0}
          onBaseRateChange={(value) => onUpdate(slab.id, "restOfIndiaBaseRate", value)}
          onAdditionalRateChange={(value) => onUpdate(slab.id, "restOfIndiaAdditionalRate", value)}
        />
        <ZoneRates
          title="North East"
          baseRate={slab.northEastBaseRate}
          additionalRate={slab.northEastAdditionalRate ?? 0}
          additionalUnit={slab.additionalUnit ?? 0}
          onBaseRateChange={(value) => onUpdate(slab.id, "northEastBaseRate", value)}
          onAdditionalRateChange={(value) => onUpdate(slab.id, "northEastAdditionalRate", value)}
        />
      </div>
    </div>
  );
}

interface SlabViewerProps {
  slab: SlabInput;
}

function SlabViewer({ slab }: SlabViewerProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-sm">
      <ZoneRatesView
        title="Local"
        baseRate={slab.localBaseRate}
        additionalRate={slab.localAdditionalRate ?? 0}
        additionalUnit={slab.additionalUnit ?? 0}
      />
      <ZoneRatesView
        title="Regional"
        baseRate={slab.regionalBaseRate}
        additionalRate={slab.regionalAdditionalRate ?? 0}
        additionalUnit={slab.additionalUnit ?? 0}
      />
      <ZoneRatesView
        title="Metro"
        baseRate={slab.metroBaseRate}
        additionalRate={slab.metroAdditionalRate ?? 0}
        additionalUnit={slab.additionalUnit ?? 0}
      />
      <ZoneRatesView
        title="Rest of India"
        baseRate={slab.restOfIndiaBaseRate}
        additionalRate={slab.restOfIndiaAdditionalRate ?? 0}
        additionalUnit={slab.additionalUnit ?? 0}
      />
      <ZoneRatesView
        title="North East"
        baseRate={slab.northEastBaseRate}
        additionalRate={slab.northEastAdditionalRate ?? 0}
        additionalUnit={slab.additionalUnit ?? 0}
      />
      <div>
        <p className="font-medium text-muted-foreground mb-1">Platform Id</p>
        <p>ID: {slab.platformId}</p>
      </div>
    </div>
  );
}

interface ZoneRatesProps {
  title: string;
  baseRate: number;
  additionalRate: number;
  additionalUnit: number;
  onBaseRateChange: (value: number) => void;
  onAdditionalRateChange: (value: number) => void;
}

function ZoneRates({
  title,
  baseRate,
  additionalRate,
  additionalUnit,
  onBaseRateChange,
  onAdditionalRateChange,
}: ZoneRatesProps) {
  return (
    <div>
      <h4 className="text-sm font-medium mb-3">{title}</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 [&_label]:mb-2">
        <NumberInput label="Base Rate (₹)" value={baseRate} onChange={onBaseRateChange} />
        <NumberInput label="Additional Rate (₹)" value={additionalRate} onChange={onAdditionalRateChange} />
      </div>
    </div>
  );
}

function ZoneRatesView({
  title,
  baseRate,
  additionalRate,
  additionalUnit,
}: Omit<ZoneRatesProps, "onBaseRateChange" | "onAdditionalRateChange">) {
  return (
    <div>
      <p className="font-medium text-muted-foreground mb-1">{title}</p>
      <p>Base: ₹{baseRate}</p>
      {!!additionalRate && (
        <p>
          Add: ₹{additionalRate}/{additionalUnit}kg
        </p>
      )}
    </div>
  );
}

interface SlabBasicInfoProps {
  slab: SlabInput;
  onUpdate: Props["onUpdate"];
}

function SlabBasicInfo({ slab, onUpdate }: SlabBasicInfoProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 [&_label]:mb-2">
      <TextInput
        label="Slab Name"
        value={slab.slabName}
        onChange={(value) => onUpdate(slab.id, "slabName", value)}
        placeholder="Upto 500g"
        tooltip="Give this slab a clear name like 'Upto 500g' or 'Heavy Package' to identify it easily."
      />
      <NumberInput
        label="Min Weight (kg)"
        value={slab.minWeight}
        onChange={(value) => onUpdate(slab.id, "minWeight", value)}
        tooltip="Packages weighing this amount or more will use this slab. Set 0 to start from any weight."
      />
      <NumberInput
        label="Max Weight (kg)"
        value={slab.maxWeight ?? 0}
        onChange={(value) => onUpdate(slab.id, "maxWeight", value)}
        placeholder="Leave empty for unlimited"
        tooltip="Base rate applies up to this weight. Set 0 for unlimited. Beyond this, additional charges apply."
      />
      <NumberInput
        label="Add. Unit (kg)"
        value={slab.additionalUnit ?? 0}
        onChange={(value) => onUpdate(slab.id, "additionalUnit", value)}
        tooltip="Additional charges are calculated for every X kg beyond max weight. Example: 0.5 means charge for every 500g extra. Set 0 for no additional charges. Note: If max weight is 0 (unlimited), additional charges won't apply."
      />
      <NumberInput
        label="Add. Max Weight (kg)"
        value={slab.additionalMaxWeight ?? 0}
        onChange={(value) => onUpdate(slab.id, "additionalMaxWeight", value)}
        tooltip="Absolute maximum weight this slab can handle. Packages heavier than this are rejected completely. Set 0 to use max weight limit instead. Only works when additional unit is set."
      />
      <TextInput
        label="Platform ID"
        value={slab.platformId ?? ""}
        onChange={(value) => onUpdate(slab.id, "platformId", value)}
        tooltip="Optional ID for specific shipping platforms (like Shiprocket, Delhivery). Leave empty if not needed."
      />
      <div className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm sm:col-span-2 md:col-span-3">
        <div>
          <Label htmlFor={slab.id} className="!mb-0">
            Is Active
          </Label>
          <p className="text-[0.8rem] text-muted-foreground">Enable or disable the slab.</p>
        </div>
        <div>
          <Switch
            id={slab.id}
            checked={slab.isActive}
            onCheckedChange={(value) => onUpdate(slab.id, "isActive", value)}
          />
        </div>
      </div>
    </div>
  );
}
