"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { IconPlus } from "@tabler/icons-react";
import { nanoid } from "nanoid";
import { defaultSlab } from "../../_data/default";
import { SlabInput } from "../../_types/editor";
import { useCombinedForm } from "../_context/combined-form-context";
import { Slab } from "./slab";

export function RateSlabBuilder() {
  const { slabs, setSlabs } = useCombinedForm();

  function addSlab() {
    const newSlab: SlabInput = { ...defaultSlab, id: nanoid() };
    setSlabs([...slabs, newSlab]);
  }

  function removeSlab(id: string) {
    setSlabs(slabs.filter((slab) => slab.id !== id));
  }

  function duplicateSlab(id: string) {
    const slab = slabs.find((s) => s.id === id);
    if (slab) {
      const newSlab: SlabInput = {
        ...slab,
        id: nanoid(),
        slabName: `${slab.slabName} (Copy)`,
      };
      setSlabs([...slabs, newSlab]);
    }
  }

  function updateSlab(id: string, field: keyof SlabInput, value: string | number | boolean) {
    setSlabs(slabs.map((slab) => (slab.id === id ? { ...slab, [field]: value } : slab)));
  }

  return (
    <Card className="border-none">
      <CardHeader className="flex flex-row justify-between gap-4 flex-wrap px-0">
        <div>
          <CardTitle>Slab Builder</CardTitle>
          <CardDescription className="mt-1">Create rate slabs for different zones</CardDescription>
        </div>
        <div>
          <Button type="button" onClick={addSlab} size="sm">
            <IconPlus />
            Add
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {slabs.length === 0 ? (
          <div className="text-center py-6 border border-dashed rounded-lg text-muted-foreground">
            <p className="text-sm font-medium">No rate slabs created yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {slabs.map((slab) => (
              <Slab key={slab.id} slab={slab} onUpdate={updateSlab} onRemove={removeSlab} onDuplicate={duplicateSlab} />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
