"use client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { IconInfoCircle } from "@tabler/icons-react";

interface Props {
  label: string;
  value: number;
  onChange: (value: number) => void;
  placeholder?: string;
  tooltip?: string;
}

export function NumberInput({ label, value, onChange, placeholder, tooltip }: Props) {
  const labelElement = (
    <Label className="flex items-center gap-2">
      {label} {tooltip && <IconInfoCircle size={16} />}
    </Label>
  );

  return (
    <div>
      {tooltip ? (
        <Tooltip>
          <TooltipTrigger asChild>{labelElement}</TooltipTrigger>
          <TooltipContent className="max-w-52">
            <p>{tooltip}</p>
          </TooltipContent>
        </Tooltip>
      ) : (
        labelElement
      )}
      <Input type="number" value={value} onChange={(e) => onChange(Number(e.target.value))} placeholder={placeholder} />
    </div>
  );
}
