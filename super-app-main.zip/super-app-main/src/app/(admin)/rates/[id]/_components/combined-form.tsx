"use client";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Rate, RateCondition, RateSlab } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { SelectOption } from "@/types/general";
import { safe } from "@orpc/client";
import { toast } from "react-hot-toast";
import { CombinedFormProvider, useCombinedForm } from "../_context/combined-form-context";
import { EditRateForm } from "./edit-rate-form";
import { RateConditionsBuilder } from "./rate-conditions-builder";
import { RateSlabBuilder } from "./rate-slab-builder";
import { RateVisualization } from "./rate-visualization";

interface Props {
  rate: Rate;
  couriers: SelectOption[];
  slabs: RateSlab[];
  conditions: RateCondition[];
  boxes: SelectOption[];
  warehouses: SelectOption[];
}

function CombinedFormContent() {
  const { rateForm, slabs, conditions, originalRate, isSaving, setSaving } = useCombinedForm();

  async function handleSave() {
    const isRateValid = await rateForm.trigger();
    if (!isRateValid) {
      toast.error("Please fix the errors in the Basic tab");
      return;
    }

    setSaving(true);

    const rateData = rateForm.getValues();

    const { error, data } = await safe(
      orpc.rates.update({
        rateId: originalRate.id,
        rate: rateData,
        slabs: slabs,
        conditions: conditions,
      })
    );

    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);

    setSaving(false);
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="basic">
        <TabsList>
          <TabsTrigger value="basic">Basic</TabsTrigger>
          <TabsTrigger value="slabs">Slabs</TabsTrigger>
          <TabsTrigger value="conditions">Conditions</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
        </TabsList>
        <TabsContent value="basic">
          <EditRateForm />
        </TabsContent>
        <TabsContent value="slabs">
          <RateSlabBuilder />
        </TabsContent>
        <TabsContent value="conditions">
          <RateConditionsBuilder />
        </TabsContent>
        <TabsContent value="preview">
          <RateVisualization slabs={slabs} configurationName={originalRate.displayName} />
        </TabsContent>
      </Tabs>

      <div>
        <Button onClick={handleSave} isLoading={isSaving} disabled={isSaving} size="lg">
          Update
        </Button>
      </div>
    </div>
  );
}

export function CombinedForm(props: Props) {
  return (
    <CombinedFormProvider {...props}>
      <CombinedFormContent />
    </CombinedFormProvider>
  );
}
