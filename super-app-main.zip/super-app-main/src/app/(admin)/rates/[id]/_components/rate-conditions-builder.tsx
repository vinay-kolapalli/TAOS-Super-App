"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { IconPlus } from "@tabler/icons-react";
import { nanoid } from "nanoid";
import { defaultCondition } from "../../_data/default";
import { ConditionInput } from "../../_types/editor";
import { useCombinedForm } from "../_context/combined-form-context";
import { Condition } from "./condition";

export function RateConditionsBuilder() {
  const { conditions, setConditions, boxes, warehouses } = useCombinedForm();

  function addCondition() {
    const newCondition: ConditionInput = {
      ...defaultCondition,
      id: nanoid(),
    };
    setConditions([...conditions, newCondition]);
  }

  function removeCondition(id: string) {
    setConditions(conditions.filter((condition) => condition.id !== id));
  }

  function duplicateCondition(id: string) {
    const condition = conditions.find((c) => c.id === id);
    if (condition) {
      const newCondition: ConditionInput = {
        ...condition,
        id: nanoid(),
        name: `${condition.name} (Copy)`,
      };
      setConditions([...conditions, newCondition]);
    }
  }

  function updateCondition(id: string, field: keyof ConditionInput, value: any) {
    setConditions(
      conditions.map((condition) => {
        if (condition.id === id) {
          // Only clear values when changing type, preserve them for other fields
          const shouldClearValues = field === "type" && condition.type !== value;
          return {
            ...condition,
            [field]: value,
            ...(shouldClearValues && { values: [] }),
          };
        }
        return condition;
      })
    );
  }

  function addValue(conditionId: string, value: string) {
    if (!value.trim()) return;

    setConditions(
      conditions.map((condition) =>
        condition.id === conditionId ? { ...condition, values: [...condition.values, value.trim()] } : condition
      )
    );
  }

  function removeValue(conditionId: string, valueIndex: number) {
    setConditions(
      conditions.map((condition) =>
        condition.id === conditionId
          ? { ...condition, values: condition.values.filter((_, index) => index !== valueIndex) }
          : condition
      )
    );
  }

  return (
    <Card className="border-none">
      <CardHeader className="flex flex-row justify-between gap-4 flex-wrap px-0">
        <div>
          <CardTitle>Conditions Builder</CardTitle>
          <CardDescription className="mt-1">Set conditions that determine when this rate applies</CardDescription>
        </div>
        <div>
          <Button type="button" onClick={addCondition} size="sm">
            <IconPlus />
            Add
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {conditions.length === 0 ? (
          <div className="text-center py-6 border border-dashed rounded-lg text-muted-foreground">
            <p className="text-sm font-medium">No rate conditions created yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {conditions.map((condition) => (
              <Condition
                key={condition.id}
                condition={condition}
                onUpdate={updateCondition}
                onRemove={removeCondition}
                onDuplicate={duplicateCondition}
                onAddValue={addValue}
                onRemoveValue={removeValue}
                boxes={boxes}
                warehouses={warehouses}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
