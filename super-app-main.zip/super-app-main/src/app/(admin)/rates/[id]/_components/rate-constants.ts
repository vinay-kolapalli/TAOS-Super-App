// Rate calculation constants
export const WEIGHT_STEP = "0.001";
export const DEFAULT_WEIGHT = "0.5";
export const DEFAULT_ADDITIONAL_UNIT = 1;
export const MAX_WEIGHT_VALUE = Number.MAX_SAFE_INTEGER;

// Zone field mappings for type safety (matches calculate API zone naming)
export const ZONE_FIELD_MAP = {
  local: { base: "localBaseRate", additional: "localAdditionalRate" },
  regional: { base: "regionalBaseRate", additional: "regionalAdditionalRate" },
  metro: { base: "metroBaseRate", additional: "metroAdditionalRate" },
  "rest-of-india": { base: "restOfIndiaBaseRate", additional: "restOfIndiaAdditionalRate" },
  "north-east": { base: "northEastBaseRate", additional: "northEastAdditionalRate" },
} as const;

export type ZoneKey = keyof typeof ZONE_FIELD_MAP;
