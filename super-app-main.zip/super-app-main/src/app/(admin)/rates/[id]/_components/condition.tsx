"use client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SelectOption } from "@/types/general";
import { IconPlus, IconX } from "@tabler/icons-react";
import { useMemo, useState } from "react";
import { conditionOperators, conditionTypes } from "../../_data/options";
import { ConditionInput } from "../../_types/editor";
import { EntityHeader } from "./entity-header";
import { SelectField } from "./select-field";
import { TextInput } from "./text-input";

interface Props {
  condition: ConditionInput;
  onUpdate: (id: string, field: keyof ConditionInput, value: any) => void;
  onRemove: (id: string) => void;
  onDuplicate: (id: string) => void;
  onAddValue: (conditionId: string, value: string) => void;
  onRemoveValue: (conditionId: string, valueIndex: number) => void;
  boxes: SelectOption[];
  warehouses: SelectOption[];
}

export function Condition({
  condition,
  onUpdate,
  onRemove,
  onDuplicate,
  onAddValue,
  onRemoveValue,
  boxes,
  warehouses,
}: Props) {
  const [isEditing, setIsEditing] = useState(false);
  const [newValue, setNewValue] = useState("");

  const conditionOptions = useMemo(
    () =>
      conditionTypes.map((c) => ({
        ...c,
        options: c.value === "box" ? boxes : c.value === "warehouse" ? warehouses : c.options,
      })),
    [boxes, warehouses]
  );
  const conditionType = useMemo(
    () => conditionOptions.find((t) => t.value === condition.type) || conditionOptions[0],
    [condition, conditionOptions]
  );

  const conditionValues = useMemo(() => {
    const conditionTypeConfig = conditionOptions.find((t) => t.value === condition.type);

    if (conditionTypeConfig?.type === "input") {
      // For input types, return the values as simple objects
      return condition.values.map((value) => ({ value, label: value }));
    } else {
      // For select types, find the corresponding options
      const options = conditionTypeConfig?.options;
      const selectedOptions = options?.filter((o) => condition.values.includes(o.value));
      return selectedOptions ?? [];
    }
  }, [condition, conditionOptions]);

  function handleAddValue() {
    if (newValue.trim()) {
      onAddValue(condition.id, newValue.trim());
      setNewValue("");
    }
  }

  function handleSelectValue(value: string) {
    onAddValue(condition.id, value);
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddValue();
    }
  }

  return (
    <div>
      <Card>
        <EntityHeader
          title={condition.name}
          description={`${condition.values.length} values`}
          isEditing={isEditing}
          onToggleEdit={() => setIsEditing(!isEditing)}
          onDuplicate={() => onDuplicate(condition.id)}
          onRemove={() => onRemove(condition.id)}
          duplicateTooltip="Duplicate Condition"
          removeTooltip="Remove Condition"
        />
        <CardContent className="p-4 pt-0">
          {isEditing ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 [&_label]:mb-2">
              <TextInput
                label="Name"
                value={condition.name}
                onChange={(value) => onUpdate(condition.id, "name", value)}
                placeholder="e.g., Mumbai Warehouse Only"
              />

              <SelectField
                label="Type"
                value={condition.type}
                onValueChange={(value) => onUpdate(condition.id, "type", value)}
                options={conditionTypes}
              />

              <SelectField
                label="Operator"
                value={condition.operator}
                onValueChange={(value) => onUpdate(condition.id, "operator", value)}
                options={conditionOperators}
              />

              <AddValueField
                conditionType={conditionType}
                newValue={newValue}
                onAddValue={handleAddValue}
                onSelectValue={handleSelectValue}
                onNewValueChange={setNewValue}
                onKeyDown={handleKeyDown}
              />
            </div>
          ) : (
            <ConditionViewer condition={condition} />
          )}
          {conditionValues.length > 0 && (
            <ConditionValues values={conditionValues} onRemoveValue={(index) => onRemoveValue(condition.id, index)} />
          )}
        </CardContent>
      </Card>
    </div>
  );
}

interface ConditionViewerProps {
  condition: ConditionInput;
}

function ConditionViewer({ condition }: ConditionViewerProps) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Label className="text-sm font-medium text-muted-foreground">Type:</Label>
          <Badge variant="secondary" className="font-mono">
            {condition.type}
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <Label className="text-sm font-medium text-muted-foreground">Operator:</Label>
          <Badge variant="outline" className="font-mono">
            {condition.operator}
          </Badge>
        </div>
      </div>
    </div>
  );
}

interface ConditionValuesProps {
  values: SelectOption[];
  onRemoveValue: (index: number) => void;
}

function ConditionValues({ values, onRemoveValue }: ConditionValuesProps) {
  return (
    <div className="mt-3">
      <Label className="mb-2">Values</Label>
      <div className="flex flex-wrap gap-2">
        {values.map((option, index) => (
          <Badge key={index} variant="outline" className="flex items-center gap-1 bg-muted hover:bg-muted/80">
            {option.label}
            <IconX className="h-3 w-3 cursor-pointer hover:text-destructive" onClick={() => onRemoveValue(index)} />
          </Badge>
        ))}
      </div>
    </div>
  );
}

interface AddValueFieldProps {
  conditionType: any;
  newValue: string;
  onAddValue: () => void;
  onSelectValue: (value: string) => void;
  onNewValueChange: (value: string) => void;
  onKeyDown: (e: React.KeyboardEvent) => void;
}

function AddValueField({
  conditionType,
  newValue,
  onAddValue,
  onSelectValue,
  onNewValueChange,
  onKeyDown,
}: AddValueFieldProps) {
  return (
    <div>
      <Label>Add Values</Label>
      <div className="flex gap-2">
        {conditionType.type === "input" && (
          <>
            <Input
              placeholder={conditionType.placeholder}
              value={newValue}
              onChange={(e) => onNewValueChange(e.target.value)}
              onKeyDown={onKeyDown}
            />
            <Button onClick={onAddValue} size="sm">
              <IconPlus />
            </Button>
          </>
        )}
        {conditionType.type === "select" && (
          <Select onValueChange={onSelectValue}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {conditionType?.options?.map((option: any) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>
    </div>
  );
}
