"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useMemo, useState } from "react";
import { SlabInput } from "../../_types/editor";
import { NumberInput } from "./number-input";
import { DEFAULT_WEIGHT } from "./rate-constants";

interface Props {
  slabs: SlabInput[];
  configurationName: string;
}

interface RateBreakdown {
  baseRate: number;
  additionalCharges: number;
  totalRate: number;
}

interface SlabRateResult {
  slab: SlabInput;
  localRate: RateBreakdown;
  regionalRate: RateBreakdown;
  metroRate: RateBreakdown;
  restOfIndiaRate: RateBreakdown;
  northEastRate: RateBreakdown;
}

export function RateVisualization({ slabs, configurationName }: Props) {
  const [weight, setWeight] = useState(DEFAULT_WEIGHT);

  const slabResults = useMemo(() => {
    // Validate inputs
    if (!slabs || slabs.length === 0) {
      return [];
    }

    const weightValue = parseFloat(weight) || 0;

    // Validate weight
    if (weightValue <= 0 || isNaN(weightValue)) {
      return [];
    }

    const applicableSlabs = findApplicableSlabs(slabs, weightValue);

    return applicableSlabs.map((slab) => ({
      slab,
      localRate: calculateSlabRate(slab, weightValue, "local"),
      regionalRate: calculateSlabRate(slab, weightValue, "regional"),
      metroRate: calculateSlabRate(slab, weightValue, "metro"),
      restOfIndiaRate: calculateSlabRate(slab, weightValue, "rest-of-india"),
      northEastRate: calculateSlabRate(slab, weightValue, "north-east"),
    }));
  }, [weight, slabs]);

  return (
    <Card className="border-none">
      <CardHeader className="px-0">
        <CardTitle>Rate Visualization</CardTitle>
        <CardDescription>All applicable slabs for {configurationName}</CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <div className="space-y-4">
          <WeightInput weight={weight} onWeightChange={setWeight} />
          <RateResults slabResults={slabResults} weight={weight} />
        </div>
      </CardContent>
    </Card>
  );
}

interface WeightInputProps {
  weight: string;
  onWeightChange: (weight: string) => void;
}

function WeightInput({ weight, onWeightChange }: WeightInputProps) {
  return (
    <div className="max-w-xs">
      <NumberInput
        label="Package Weight (kg)"
        value={parseFloat(weight) || 0}
        onChange={(value) => onWeightChange(value.toString())}
        placeholder={DEFAULT_WEIGHT}
      />
    </div>
  );
}

interface RateResultsProps {
  slabResults: SlabRateResult[];
  weight: string;
}

function RateResults({ slabResults, weight }: RateResultsProps) {
  if (!slabResults || slabResults.length === 0) {
    const weightValue = parseFloat(weight) || 0;
    let message = "No rates available. ";

    if (weightValue <= 0 || isNaN(weightValue)) {
      message += "Please enter a valid weight greater than 0.";
    } else {
      message += `No applicable slab found for ${weight}kg. Check your rate slabs configuration.`;
    }

    return (
      <div className="text-center py-6 border border-dashed rounded-lg text-muted-foreground">
        <p className="text-sm font-medium">{message}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {slabResults.map((slabResult, index) => (
        <SlabRateDisplay key={`${slabResult.slab.slabName}-${index}`} slabResult={slabResult} />
      ))}
    </div>
  );
}

interface SlabRateDisplayProps {
  slabResult: SlabRateResult;
}

function SlabRateDisplay({ slabResult }: SlabRateDisplayProps) {
  const { slab } = slabResult;

  const zoneRates = [
    { label: "Local", rate: slabResult.localRate },
    { label: "Regional", rate: slabResult.regionalRate },
    { label: "Metro", rate: slabResult.metroRate },
    { label: "Rest of India", rate: slabResult.restOfIndiaRate },
    { label: "North East", rate: slabResult.northEastRate },
  ].filter((zone) => zone.rate.totalRate > 0);

  if (zoneRates.length === 0) {
    return null;
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-sm font-medium">{slab.slabName}</h4>
          <p className="text-xs text-muted-foreground">
            {slab.minWeight}kg - {slab.maxWeight === 0 ? "∞" : `${slab.maxWeight}kg`}
            {slab.additionalUnit > 0 && ` • Additional unit: ${slab.additionalUnit}kg`}
            {slab.additionalMaxWeight > 0 && ` • Max additional: ${slab.additionalMaxWeight}kg`}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {zoneRates.map((zone) => (
          <RateCard key={zone.label} label={zone.label} rate={zone.rate} />
        ))}
      </div>
    </div>
  );
}

interface RateCardProps {
  label: string;
  rate: RateBreakdown;
}

function RateCard({ label, rate }: RateCardProps) {
  return (
    <Card>
      <CardContent className="p-3">
        <div className="space-y-1">
          <div className="text-xs font-medium text-muted-foreground">{label}</div>
          <div className="text-xl font-semibold">₹{rate.totalRate.toFixed(2)}</div>
          {rate.additionalCharges > 0 && (
            <div className="text-xs text-muted-foreground">
              Base: ₹{rate.baseRate.toFixed(2)} + Additional: ₹{rate.additionalCharges.toFixed(2)}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Find all applicable slabs for the given weight
function findApplicableSlabs(slabs: SlabInput[], weight: number): SlabInput[] {
  // Validate inputs
  if (!slabs || slabs.length === 0 || weight <= 0 || isNaN(weight)) {
    return [];
  }

  // Sort slabs by minWeight to ensure we check them in the correct order
  const sortedSlabs = [...slabs].sort((a, b) => a.minWeight - b.minWeight);
  const applicableSlabs: SlabInput[] = [];

  for (const slab of sortedSlabs) {
    // Validate slab properties
    if (!slab || typeof slab.minWeight !== "number" || typeof slab.maxWeight !== "number") {
      console.warn("Invalid slab configuration:", slab);
      continue;
    }

    const minWeight = slab.minWeight;
    const maxWeight = slab.maxWeight;
    const additionalUnit = slab.additionalUnit;
    const additionalMaxWeight = slab.additionalMaxWeight;

    // Handle case where maxWeight is 0 (meaning unlimited) by treating it as Infinity
    const effectiveMaxWeight = maxWeight === 0 ? Infinity : maxWeight;

    // For slabs with additionalUnit > 0, they can handle weights beyond maxWeight
    // but only up to the additionalMaxWeight absolute limit
    const canExtendBeyondMax = additionalUnit > 0;
    const maxAllowedWeight = canExtendBeyondMax ? additionalMaxWeight : effectiveMaxWeight;
    const weightInRange =
      weight >= minWeight &&
      (weight <= effectiveMaxWeight || (canExtendBeyondMax && weight > maxWeight && weight <= maxAllowedWeight));

    if (weightInRange) {
      applicableSlabs.push(slab);
    }
  }

  return applicableSlabs;
}

// Calculate rate for a slab using the same logic as the calculate API
function calculateSlabRate(slab: SlabInput, weight: number, zone: string): RateBreakdown {
  // Get zone-specific rates from the slab
  const { baseRate, additionalRate } = getZoneRates(slab, zone);
  const additionalUnit = slab.additionalUnit;
  const maxWeight = slab.maxWeight;

  // Validate inputs
  if (baseRate === 0 || isNaN(baseRate)) {
    return {
      baseRate: 0,
      additionalCharges: 0,
      totalRate: 0,
    };
  }

  if (weight < 0 || isNaN(weight)) {
    return {
      baseRate: 0,
      additionalCharges: 0,
      totalRate: 0,
    };
  }

  let additionalCharges = 0;

  // Calculate additional charges based on slab configuration
  // Logic:
  // 1. If additionalUnit is 0, this is a flat rate slab (no additional charges)
  // 2. If weight is within the slab's base capacity (determined by slab design), use base rate only
  // 3. Additional charges apply only when weight exceeds the base weight threshold

  // For "Upto X" slabs, typically the base rate covers the full range, additional charges shouldn't apply
  // unless specifically configured differently
  if (additionalUnit === 0) {
    // Flat rate slab - no additional charges regardless of weight within the slab
  } else if (weight > maxWeight && additionalRate > 0 && additionalUnit > 0) {
    // Weight exceeds base capacity - calculate additional charges
    const excessWeight = weight - maxWeight;
    const additionalUnits = Math.ceil(excessWeight / additionalUnit);
    additionalCharges = additionalUnits * additionalRate;
  } else {
    // Weight is within base capacity, no additional charges
  }

  const totalRate = baseRate + additionalCharges;

  return {
    baseRate: baseRate,
    additionalCharges: additionalCharges,
    totalRate: totalRate,
  };
}

// Get zone-specific rates from the slab (matches calculate API logic)
function getZoneRates(slab: SlabInput, zone: string): { baseRate: number; additionalRate: number } {
  switch (zone) {
    case "local":
      return { baseRate: slab.localBaseRate, additionalRate: slab.localAdditionalRate };
    case "regional":
      return { baseRate: slab.regionalBaseRate, additionalRate: slab.regionalAdditionalRate };
    case "metro":
      return { baseRate: slab.metroBaseRate, additionalRate: slab.metroAdditionalRate };
    case "rest-of-india":
      return { baseRate: slab.restOfIndiaBaseRate, additionalRate: slab.restOfIndiaAdditionalRate };
    case "north-east":
      return { baseRate: slab.northEastBaseRate, additionalRate: slab.northEastAdditionalRate };
    default:
      console.warn(`Unknown zone: ${zone}, defaulting to rest-of-india rates`);
      return { baseRate: slab.restOfIndiaBaseRate, additionalRate: slab.restOfIndiaAdditionalRate };
  }
}
