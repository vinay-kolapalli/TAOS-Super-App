"use client";
import { Button } from "@/components/ui/button";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { IconCopy, IconEdit, IconEye, IconTrash } from "@tabler/icons-react";

interface Props {
  title: React.ReactNode;
  description: React.ReactNode;
  isEditing: boolean;
  onToggleEdit: () => void;
  onDuplicate: () => void;
  onRemove: () => void;
  editTooltip?: string;
  duplicateTooltip?: string;
  removeTooltip?: string;
}

export function EntityHeader({
  title,
  description,
  isEditing,
  onToggleEdit,
  onDuplicate,
  onRemove,
  editTooltip = "Edit Mode",
  duplicateTooltip = "Duplicate",
  removeTooltip = "Remove",
}: Props) {
  return (
    <CardHeader className="flex flex-row justify-between *:w-fit p-4">
      <div>
        <CardTitle>{title}</CardTitle>
        <CardDescription className="mt-1">{description}</CardDescription>
      </div>
      <div className="flex items-center gap-1">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={onToggleEdit}
          title={isEditing ? "View Mode" : editTooltip}
        >
          {isEditing ? <IconEye /> : <IconEdit />}
        </Button>
        <Button type="button" variant="ghost" size="sm" onClick={onDuplicate} title={duplicateTooltip}>
          <IconCopy />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={onRemove}
          className="text-destructive hover:text-destructive"
          title={removeTooltip}
        >
          <IconTrash />
        </Button>
      </div>
    </CardHeader>
  );
}
