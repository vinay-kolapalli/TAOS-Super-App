import { courierPlatforms, courierServices, weightTypes } from "@/data/shipping";
import { z } from "zod";

export const editRateSchema = z.object({
  courier: z.string().min(1, "Courier is required"),
  service: z.enum(courierServices),
  displayName: z.string().min(1, "Display name is required"),
  description: z.string(),
  weightType: z.enum(weightTypes),
  isActive: z.boolean(),
  platform: z
    .enum([...courierPlatforms, "none"])
    .nullable()
    .optional(),
});

export type EditRateSchema = z.infer<typeof editRateSchema>;
