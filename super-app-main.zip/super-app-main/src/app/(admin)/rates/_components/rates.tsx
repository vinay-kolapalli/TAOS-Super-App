"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { columns, RateWithCourier } from "./columns";

interface Props {
  rates: RateWithCourier[];
  totalRates: number;
  isLoading?: boolean;
}

export function Rates({ rates, totalRates, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });

  const table = useReactTable({
    data: rates,
    columns,
    pageCount: Math.ceil(totalRates / pagination.pageSize),
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    state: {
      pagination,
    },
  });

  return <DataTable table={table} isLoading={isLoading} paginationType="numeric" />;
}
