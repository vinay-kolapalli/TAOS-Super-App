"use client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Rate } from "@/db/types";
import { getSignedUrl } from "@/lib/s3";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import Image from "next/image";
import { RateMenu } from "./rate-menu";

export interface RateWithCourier extends Omit<Rate, "courier"> {
  courier: {
    id: string;
    name: string;
    image: string;
  };
}

export const columns: ColumnDef<RateWithCourier>[] = [
  {
    accessorKey: "courier",
    header: "Courier",
    cell: ({ row }) => {
      const courier = row.original.courier;
      if (!courier) return <div>-</div>;

      return (
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 relative">
            <Image src={getSignedUrl(courier.image)} alt={courier.name} fill className="object-contain rounded-md" />
          </div>
          <span className="font-medium">{courier.name}</span>
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "displayName",
    header: "Configuration",
    cell: ({ row }) => {
      return (
        <div>
          <div className="font-medium">{row.original.displayName}</div>
          <div className="text-sm text-muted-foreground capitalize">
            {row.original.service}
            {row.original.platform && ` • ${row.original.platform}`}
          </div>
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "isActive",
    header: "Status",
    cell: ({ row }) => {
      return (
        <Badge variant={row.original.isActive ? "default" : "secondary"}>
          {row.original.isActive ? "Active" : "Inactive"}
        </Badge>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "description",
    header: "Description",
    cell: ({ row }) => {
      return (
        <div className="text-sm text-muted-foreground line-clamp-2 w-[30ch] text-wrap">
          {row.original.description || "-"}
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "createdAt",
    header: "Created At",
    cell: ({ row }) => {
      return row.original.createdAt ? <div>{format(row.original.createdAt, "MMM d, yyyy")}</div> : <div>-</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "actions",
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <RateMenu id={row.original.id}>
            <Button variant="ghost" size="icon">
              <IconDots />
            </Button>
          </RateMenu>
        </div>
      );
    },
    enableSorting: false,
  },
];
