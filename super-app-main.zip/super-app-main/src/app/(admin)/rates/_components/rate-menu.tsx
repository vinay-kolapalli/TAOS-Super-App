"use client";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { orpc } from "@/lib/orpc/client";
import { safe } from "@orpc/client";
import { IconEdit, IconTrash } from "@tabler/icons-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "react-hot-toast";

interface RateConfigurationMenuProps {
  id: string;
  children?: React.ReactNode;
}

export function RateMenu({ id, children }: RateConfigurationMenuProps) {
  const router = useRouter();

  async function handleDelete() {
    const { error, data } = await safe(orpc.rates.delete({ id }));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    router.refresh();
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>{children}</DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem asChild>
          <Link href={`/rates/${id}`} className="flex items-center gap-2">
            <IconEdit className="h-4 w-4" />
            Edit
          </Link>
        </DropdownMenuItem>
        <AlertDialogDeleteConfiguration onConfirm={handleDelete}>
          <DropdownMenuItem
            onSelect={(e) => e.preventDefault()}
            className="flex items-center gap-2 text-destructive focus:text-destructive"
          >
            <IconTrash className="h-4 w-4" />
            Delete
          </DropdownMenuItem>
        </AlertDialogDeleteConfiguration>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function AlertDialogDeleteConfiguration({ onConfirm, children }: { onConfirm: () => void; children: React.ReactNode }) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>{children}</AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
          <AlertDialogDescription>
            This action cannot be undone. This will permanently delete the rate and all associated rate slabs and
            conditions.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm}>Delete</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
