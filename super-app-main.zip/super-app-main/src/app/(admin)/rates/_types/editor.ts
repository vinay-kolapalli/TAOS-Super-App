import { RateCondition, RateSlab } from "@/db/types";

export type SlabInput = Omit<RateSlab, "createdAt" | "updatedAt" | "rate">;
export type ConditionInput = Omit<RateCondition, "createdAt" | "updatedAt" | "rate">;
