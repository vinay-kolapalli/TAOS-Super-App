import { Search } from "@/components/search";
import { Button } from "@/components/ui/button";
import { db } from "@/db";
import { rates } from "@/db/schema/rates";
import { asc, count, ilike, or } from "drizzle-orm";
import { nanoid } from "nanoid";
import Link from "next/link";
import { Suspense } from "react";
import { Rates } from "./_components/rates";

interface Props {
  searchParams: Promise<{
    page: string;
    per_page: string;
    search: string;
  }>;
}

export default function Page(props: Props) {
  return (
    <div className="w-full space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-lg font-bold">Rates</h2>
        <div className="flex gap-4 flex-wrap">
          <Search shallow={false} />
          <Link href="/rates/new">
            <Button>Create</Button>
          </Link>
        </div>
      </div>
      <Suspense key={nanoid()} fallback={<Rates rates={[]} totalRates={0} isLoading={true} />}>
        <PageWithFetch {...props} />
      </Suspense>
    </div>
  );
}

async function PageWithFetch({ searchParams }: Props) {
  const searchParamsList = await searchParams;
  const page = Number(searchParamsList.page ?? 1);
  const per_page = Number(searchParamsList.per_page ?? 10);
  const search = searchParamsList.search ?? "";

  const where = search
    ? or(ilike(rates.displayName, `%${search}%`), ilike(rates.description, `%${search}%`))
    : undefined;

  const ratesData = await db.query.rates.findMany({
    limit: per_page,
    offset: (page - 1) * per_page,
    where,
    orderBy: [asc(rates.courier)],
    with: {
      courier: {
        columns: {
          id: true,
          name: true,
          image: true,
        },
      },
    },
  });

  const [totalRates] = await db.select({ count: count() }).from(rates).where(where);

  return <Rates rates={ratesData} totalRates={totalRates.count} />;
}
