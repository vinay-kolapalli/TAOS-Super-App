export interface DashboardFilter {
  dateRange: {
    from: Date;
    to: Date;
  };
  warehouseId?: number;
}

export interface DashboardSummary {
  shippedOrders: number;
  pickedPlants: number;
  pickedOther: number;
  orderReviews: number;
  totalBoxes: number;
}

export interface BoxUsage {
  box: string;
  count: number;
}
