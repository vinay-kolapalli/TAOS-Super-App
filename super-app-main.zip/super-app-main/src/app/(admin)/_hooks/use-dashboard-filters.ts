"use client";
import { getEndOfDay, getStartOfDay } from "@/utils/date";
import { useQueryState } from "nuqs";
import { useMemo } from "react";

export function useDashboardFilters() {
  const [from, setFrom] = useQueryState("from", {
    shallow: false,
  });
  const [to, setTo] = useQueryState("to", {
    shallow: false,
  });
  const [warehouseId, setWarehouseId] = useQueryState("warehouse_id", {
    defaultValue: "",
    shallow: false,
  });

  const filters = useMemo(
    () => ({
      dateRange: {
        from: getStartOfDay(from || new Date()),
        to: getEndOfDay(to || new Date()),
      },
      warehouseId: warehouseId ? Number(warehouseId) : undefined,
    }),
    [from, to, warehouseId]
  );

  return { filters, setFrom, setTo, setWarehouseId };
}
