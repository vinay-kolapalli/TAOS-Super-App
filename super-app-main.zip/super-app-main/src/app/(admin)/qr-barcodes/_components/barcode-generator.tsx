"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { generateBarcodeLabels } from "@/lib/label";
import { tryCatch } from "@/lib/try-catch";
import { printBuffer } from "@/utils/print";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { barcodeFormSchema, BarcodeFormSchema } from "./schema";

export function BarcodeGenerator() {
  const form = useForm<BarcodeFormSchema>({
    resolver: zodResolver(barcodeFormSchema),
    defaultValues: {
      values: "",
      widthInches: 2,
      heightInches: 1,
      margin: 2,
      includeText: true,
    },
  });

  function cleanAndProcessValues(input: string): string[] {
    return input
      .split("\n")
      .map((value) => value.trim())
      .filter((value) => value.length > 0);
  }

  async function printBarcodes(data: BarcodeFormSchema) {
    const values = cleanAndProcessValues(data.values);

    if (values.length === 0) {
      toast.error("No values to print");
      return;
    }

    const buffer = await tryCatch(
      generateBarcodeLabels(values, {
        includeText: data.includeText,
        styleOptions: {
          widthInches: data.widthInches,
          heightInches: data.heightInches,
          margin: data.margin,
        },
      })
    );
    if (buffer.error) {
      toast.error(buffer.error.message);
      return;
    }

    const print = await tryCatch(printBuffer(buffer.data));
    if (print.error) {
      toast.error(print.error.message);
      return;
    }
  }

  function reset() {
    form.reset();
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Barcode Generator</CardTitle>
        <CardDescription className="mt-1">Generate multiple Barcodes efficiently</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(printBarcodes)} className="space-y-4">
            <FormField
              control={form.control}
              name="values"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Values (One per line)</FormLabel>
                  <FormControl>
                    <Textarea {...field} className="w-full" placeholder="Enter values, one per line..." rows={8} />
                  </FormControl>
                </FormItem>
              )}
            />

            <div className="space-y-4 border-t pt-4">
              <FormLabel className="text-sm font-medium">Options</FormLabel>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="widthInches"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Width (inches)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 2)}
                          step="0.1"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="heightInches"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Height (inches)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 1)}
                          step="0.1"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="margin"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Margin (mm)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 2)}
                          step="1"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <FormField
              control={form.control}
              name="includeText"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between">
                  <FormLabel>Include Text</FormLabel>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Button type="submit">Print</Button>
              <Button type="button" variant="secondary" onClick={reset}>
                Reset
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
