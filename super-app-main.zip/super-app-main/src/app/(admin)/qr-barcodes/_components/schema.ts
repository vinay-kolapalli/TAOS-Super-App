import { z } from "zod";

export const barcodeFormSchema = z.object({
  values: z.string().min(1, "At least one value is required"),
  widthInches: z.number().min(0.5),
  heightInches: z.number().min(0.3),
  margin: z.number().min(2).max(25),
  includeText: z.boolean(),
});

export const qrFormSchema = z.object({
  values: z.string().min(1, "At least one value is required"),
  widthInches: z.number().min(0.5),
  heightInches: z.number().min(0.5),
  margin: z.number().min(2).max(25),
  includeText: z.boolean(),
});

export type BarcodeFormSchema = z.infer<typeof barcodeFormSchema>;
export type QRFormSchema = z.infer<typeof qrFormSchema>;
