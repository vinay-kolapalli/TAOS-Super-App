"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { useStoreProducts } from "@/hooks/product";
import { generateQRProductLabels } from "@/lib/label";
import { tryCatch } from "@/lib/try-catch";
import { GetProductsOutputSchema } from "@/router/store/products/schema";
import { printBuffer } from "@/utils/print";
import { IconQrcode } from "@tabler/icons-react";
import toast from "react-hot-toast";

export function Products() {
  const { data, isLoading } = useStoreProducts();

  async function handleBulkPrintQR() {
    if (!data?.length) return;
    const toastId = toast.loading("Generating QR codes...");
    const qrData = data
      .filter((product) => product.name && product.url)
      .map((product) => ({
        productName: product.name,
        value: product.url,
      }));

    const qrCode = await generateQRProductLabels(qrData);
    const print = await tryCatch(printBuffer(qrCode));
    if (print.error) {
      toast.error(print.error.message, { id: toastId });
      return;
    }
    toast.dismiss(toastId);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Product Labels</CardTitle>
        <CardDescription className="mt-1">
          Generate QR codes for all products. Use <kbd className="rounded-md bg-muted px-1 py-0.5">Ctrl/Cmd + F</kbd> to
          search.
        </CardDescription>
        <div className="flex gap-2 pt-2">
          <Button variant="outline" size="sm" onClick={handleBulkPrintQR} disabled={isLoading || !data?.length}>
            <IconQrcode className="h-4 w-4 mr-2" />
            Print All QR Codes
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[calc(100vh-200px)]">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {isLoading
              ? Array.from({ length: 18 }).map((_, index) => <ProductItemSkeleton key={index} />)
              : data?.map((product) => <ProductItem key={product.id} product={product} />)}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function ProductItem({ product }: { product: GetProductsOutputSchema["data"][number] }) {
  async function handlePrintQR() {
    const qrCode = await generateQRProductLabels([
      {
        productName: product.name,
        value: product.url,
      },
    ]);
    const print = await tryCatch(printBuffer(qrCode));
    if (print.error) {
      toast.error(print.error.message);
      return;
    }
  }

  return (
    <div className="border rounded-lg p-2 flex items-center justify-between gap-4" key={product.id}>
      <p className="text-sm font-medium truncate">{product.name}</p>
      <div className="flex gap-2">
        <Button size="icon" variant="outline" className="h-7 px-1.5" onClick={handlePrintQR}>
          <IconQrcode />
        </Button>
      </div>
    </div>
  );
}

function ProductItemSkeleton() {
  return (
    <div className="border rounded-lg p-2 flex items-center justify-between gap-4 h-[46px]">
      <Skeleton className="size-full" />
      <div className="flex gap-2">
        <Skeleton className="h-7 w-7" />
        <Skeleton className="h-7 w-7" />
      </div>
    </div>
  );
}
