import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarcodeGenerator } from "./_components/barcode-generator";
import { Products } from "./_components/products";
import { QRGenerator } from "./_components/qr-generator";

export default function Page() {
  return (
    <div className="w-full space-y-4">
      <Tabs defaultValue="create">
        <TabsList>
          <TabsTrigger value="create">Create</TabsTrigger>
          <TabsTrigger value="print">Print</TabsTrigger>
        </TabsList>
        <TabsContent value="create">
          <div className="grid lg:grid-cols-2 gap-4">
            <BarcodeGenerator />
            <QRGenerator />
          </div>
        </TabsContent>
        <TabsContent value="print">
          <Products />
        </TabsContent>
      </Tabs>
    </div>
  );
}
