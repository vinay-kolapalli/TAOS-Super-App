import { employees } from "@/data/employee";

interface PickingData {
  orderNumber: number;
  employee: string;
  image?: string | null;
  type: "plants" | "other";
}

export async function sendPickingDataToForm(data: PickingData) {
  try {
    if (data.type === "plants") {
      const formData = new FormData();
      formData.append("orderNumber", String(data.orderNumber));
      const employee = employees.get(Number(data.employee));
      formData.append("filledBy", employee?.name ?? data.employee);
      if (data.image) {
        formData.append("imageData", data.image?.split(",")[1]);
      }
      const res = await fetch(
        "https://script.google.com/macros/s/AKfycbyA7PlaJq6aIJNko5dlUzp5739DPFRC7gPkr5AIbLrt5UZnFloDbH4rHnK003cyRv613A/exec",
        {
          method: "POST",
          body: formData,
        },
      );
    } else {
      const formUrl = new URL(
        "https://docs.google.com/forms/d/e/1FAIpQLSd4fZWJ36QRK6rAR05gjVqMgsB3x8043gU2Sp5FdE_j7zMW9w/formResponse",
      );
      formUrl.searchParams.set("usp", "pp_formUrl");
      const employee = employees.get(Number(data.employee));
      formUrl.searchParams.set(
        "entry.1406130673",
        employee?.name ?? data.employee,
      );
      formUrl.searchParams.set("entry.125291979", String(data.orderNumber));
      await fetch(formUrl);
    }
  } catch (error) {}
}
