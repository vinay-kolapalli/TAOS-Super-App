import { PickingForm } from "./_components/picking-form";

export default function Page() {
  return (
    <div className="flex-1">
      <PickingForm />
    </div>
  );
}
