import { PageContainer, PageHeader } from "@/components/page";
import { db } from "@/db";
import { notFound } from "next/navigation";
import { ProductForm } from "../_components/product-form";

interface Props {
  params: Promise<{ id: string }>;
}

export default async function Page({ params }: Props) {
  const { id } = await params;

  const product = await db.query.products.findFirst({
    where(fields, operators) {
      return operators.eq(fields.id, Number(id));
    },
  });

  if (!product) {
    notFound();
  }

  return (
    <PageContainer>
      <PageHeader title="Edit Product" description={`Update details for ${product.name}.`} />
      <ProductForm defaultValues={product} />
    </PageContainer>
  );
}
