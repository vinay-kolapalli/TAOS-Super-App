import { PageContainer, PageHeader } from "@/components/page";
import { ProductForm } from "../_components/product-form";

export default function Page() {
  return (
    <PageContainer>
      <PageHeader title="Create Product" description="Add a new product to the system." />
      <ProductForm
        defaultValues={{
          name: "",
          image: "",
          description: "",
          sku: "",
        }}
      />
    </PageContainer>
  );
}
