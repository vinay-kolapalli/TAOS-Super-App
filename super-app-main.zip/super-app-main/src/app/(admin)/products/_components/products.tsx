"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { Product } from "@/db/types";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { columns } from "./columns";

interface Props {
  products: Product[];
  totalProducts: number;
  isLoading?: boolean;
}

export function Products({ products, totalProducts, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });

  const table = useReactTable({
    data: products,
    columns,
    pageCount: Math.ceil(totalProducts / pagination.pageSize),
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    state: {
      pagination,
    },
  });

  return <DataTable table={table} isLoading={isLoading} paginationType="numeric" />;
}
