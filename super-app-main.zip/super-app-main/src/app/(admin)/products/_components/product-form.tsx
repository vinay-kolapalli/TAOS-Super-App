"use client";
import { FileUploader, OnUploadFiles } from "@/components/file-upload/file-uploader";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Product } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { createProductInputSchema, CreateProductInputSchema } from "@/router/products/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "react-hot-toast";

interface Props {
  defaultValues?: Partial<Product>;
}

export function ProductForm({ defaultValues }: Props) {
  const [isUploading, setIsUploading] = useState(false);
  const form = useForm<CreateProductInputSchema>({
    resolver: zodResolver(createProductInputSchema),
    defaultValues,
  });
  const { isSubmitting } = form.formState;
  const router = useRouter();

  async function onSubmit(values: CreateProductInputSchema) {
    const rpc = defaultValues?.id ? orpc.products.update : orpc.products.create;
    const { error, data } = await safe(
      rpc({
        id: defaultValues?.id!,
        ...values,
      })
    );
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    router.push("/products");
  }

  function handleFileUpload(files: OnUploadFiles, error?: string) {
    if (error) {
      toast.error(error);
      return;
    }
    form.setValue("image", files[0].path);
  }

  function handleFileDelete() {
    form.setValue("image", "");
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
      <Form {...form}>
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input placeholder="Seed" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="sku"
          render={({ field }) => (
            <FormItem>
              <FormLabel>SKU</FormLabel>
              <FormControl>
                <Input placeholder="A1001" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea placeholder="Write a description about the product..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="image"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Image</FormLabel>
              <FormControl>
                <FileUploader
                  files={[field.value]}
                  folder="products"
                  onUpload={handleFileUpload}
                  onDelete={handleFileDelete}
                  isUploading={isUploading}
                  setIsUploading={setIsUploading}
                  accept="image/*"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button isLoading={isSubmitting} disabled={isSubmitting}>
          Submit
        </Button>
      </Form>
    </form>
  );
}
