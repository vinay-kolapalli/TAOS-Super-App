import { z } from "zod";

export const createProductSchema = z.object({
  name: z.string().min(1, "Product name is required"),
  description: z.string(),
  sku: z.string(),
  image: z.string().optional().nullable(),
});

export type CreateProductSchema = z.infer<typeof createProductSchema>;

export const updateProductSchema = createProductSchema.extend({
  id: z.number(),
});

export type UpdateProductSchema = z.infer<typeof updateProductSchema>;
