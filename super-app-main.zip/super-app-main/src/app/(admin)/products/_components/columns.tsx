"use client";
import { Button } from "@/components/ui/button";
import { Product } from "@/db/types";
import { getSignedUrl } from "@/lib/s3";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import Image from "next/image";
import { ProductMenu } from "./product-menu";

export const columns: ColumnDef<Product>[] = [
  {
    accessorKey: "id",
    header: "ID",
    cell: ({ row }) => {
      return <div className="font-mono text-sm">{row.original.id}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "name",
    header: "Name",
    cell: ({ row }) => {
      return (
        <div className="grid grid-cols-[40px_auto] gap-4 items-center">
          <div className="w-10 h-10 relative">
            <Image
              src={row.original.image ? getSignedUrl(row.original.image) : "/images/placeholder.png"}
              alt={row.original.name}
              width={100}
              height={100}
              className="object-cover rounded-md aspect-square"
            />
          </div>
          <div className="font-medium">{row.original.name}</div>
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "description",
    header: "Description",
    cell: ({ row }) => {
      return (
        <div className="text-sm text-muted-foreground line-clamp-2 w-[30ch] text-wrap">
          {row.original.description || "-"}
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "sku",
    header: "SKU",
    cell: ({ row }) => {
      return <div className="font-medium">{row.original.sku}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "actions",
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <ProductMenu id={row.original.id}>
            <Button variant="ghost" size="icon">
              <IconDots />
            </Button>
          </ProductMenu>
        </div>
      );
    },
    enableSorting: false,
  },
];
