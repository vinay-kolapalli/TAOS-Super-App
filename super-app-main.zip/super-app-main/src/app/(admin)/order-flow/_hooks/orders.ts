import { orpc } from "@/lib/orpc/client";
import { useQuery } from "@tanstack/react-query";

export function useOrderPickings(orderNumber: number | null | undefined) {
  return useQuery({
    queryKey: ["order-pickings", orderNumber],
    queryFn: async () => {
      if (!orderNumber) return null;
      const { data } = await orpc.orders.pickings.list({ orderNumber });
      return data;
    },
    enabled: !!orderNumber,
  });
}

export function useOrderReview(orderNumber: number | null | undefined) {
  return useQuery({
    queryKey: ["order-review", orderNumber],
    queryFn: async () => {
      if (!orderNumber) return null;
      const { data } = await orpc.orders.reviews.list({ orderNumber });
      return data;
    },
    enabled: !!orderNumber,
  });
}

export function useOrderPackings(orderNumber: number | null | undefined) {
  return useQuery({
    queryKey: ["order-packings", orderNumber],
    queryFn: async () => {
      if (!orderNumber) return null;
      const { data } = await orpc.orders.packings.list({ orderNumber });
      return data;
    },
    enabled: !!orderNumber,
  });
}

export function useOrderCourierChecks(orderNumber: number | null | undefined) {
  return useQuery({
    queryKey: ["order-courier-checks", orderNumber],
    queryFn: async () => {
      if (!orderNumber) return null;
      const { data } = await orpc.orders.shipments.list({ orderNumber });
      return data;
    },
    enabled: !!orderNumber,
  });
}
