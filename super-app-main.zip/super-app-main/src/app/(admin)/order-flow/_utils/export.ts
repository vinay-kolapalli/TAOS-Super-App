import { orpc } from "@/lib/orpc/client";

interface ExportDataOptions {
  from: Date;
  to: Date;
  warehouse?: number;
  type: string;
}

export async function exportData(data: ExportDataOptions) {
  if (data.type === "plant-pickings") {
    return orpc.orders.pickings.export({
      ...data,
      type: "plants",
    });
  }
  if (data.type === "other-pickings") {
    orpc.orders.pickings.export({
      ...data,
      type: "other",
    });
  }
  if (data.type === "reviews") {
    return orpc.orders.reviews.export(data);
  }
  if (data.type === "packings") {
    return orpc.orders.packings.export(data);
  }
  if (data.type === "order-shipments") {
    return orpc.orders.shipments.export(data);
  }
  if (data.type === "order-shipment-with-rates") {
    return orpc.orders.shipments.exportWithRates(data);
  }
  if (data.type === "products-report") {
    return orpc.store.products.report(data);
  }
  if (data.type === "boxes-report") {
    return orpc.boxes.report(data);
  }
  if (data.type === "pincode-report") {
    return orpc.pincodes.report(data);
  }
}
