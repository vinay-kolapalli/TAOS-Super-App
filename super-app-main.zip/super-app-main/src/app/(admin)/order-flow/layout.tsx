import { NotAllowed } from "@/components/not-allowed";
import { permissionsList } from "@/data/permissions";
import { isUserAllowed } from "@/lib/auth";
import React from "react";

type Props = {
  children: React.ReactNode;
};

export default async function Layout({ children }: Props) {
  const { isAllowed } = await isUserAllowed(permissionsList.orderFlow.read);
  if (!isAllowed) {
    return <NotAllowed />;
  }

  return children;
}
