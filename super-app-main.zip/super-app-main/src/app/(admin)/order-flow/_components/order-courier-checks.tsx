import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { useOrderCourierChecks } from "../_hooks/orders";
import { RatesTable } from "./rates-table";

interface Props {
  orderNumber: number;
}

export function OrderCourierChecks({ orderNumber }: Props) {
  const { data, isLoading } = useOrderCourierChecks(orderNumber);

  if (isLoading) {
    return <Skeleton className="h-24 w-full rounded-lg" />;
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-center py-6 bg-secondary/30 rounded-lg">
        <p className="text-muted-foreground">No courier check data available</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {data.map((item, index) => (
        <article key={item.id || index} className="bg-secondary/20 rounded-lg p-4 border">
          <header className="flex justify-between mb-3">
            <h3 className="font-medium text-sm">
              Shipment {index + 1} • {format(item.createdAt, "dd MMM yyyy")}
            </h3>
          </header>

          <div className="grid md:grid-cols-2 gap-4">
            <dl className="space-y-2">
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Order Number:</dt>
                <dd className="text-sm font-medium">{item.orderNumber}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Box:</dt>
                <dd className="text-sm font-medium">{item.box?.name || "Unknown Box"}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Weight:</dt>
                <dd className="text-sm font-medium">{item.weight / 1000} kg</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Pincode:</dt>
                <dd className="text-sm font-medium">{item.pincode}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Service:</dt>
                <dd className="text-sm font-medium text-primary capitalize">{item.rate?.courierService}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Platform:</dt>
                <dd className="text-sm font-medium text-primary capitalize">{item.rate?.platform ?? "-"}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Priority:</dt>
                <dd className="text-sm font-medium text-primary capitalize">{item.rate?.priority ?? "-"}</dd>
              </div>
            </dl>

            <dl className="space-y-2">
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Packed By:</dt>
                <dd className="text-sm font-medium capitalize">{item.packedBy}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Scanned By:</dt>
                <dd className="text-sm font-medium capitalize">{item.scannedBy}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Courier:</dt>
                <dd className="text-sm font-medium">{item.rate?.courier?.name || "Unknown Courier"}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Tracking:</dt>
                <dd className="text-sm font-medium text-primary">{item.trackingNumber}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Rate:</dt>
                <dd className="text-sm font-medium text-primary">₹{item.rate?.rate}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Warehouse:</dt>
                <dd className="text-sm font-medium text-primary">{item.warehouse?.name}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Zone:</dt>
                <dd className="text-sm font-medium text-primary capitalize">{item.rate?.zone}</dd>
              </div>
            </dl>
          </div>
          <div className="mt-2 space-y-2">
            <dt className="text-sm text-muted-foreground">Non-Priority Reason:</dt>
            <dd className="text-sm font-medium capitalize">{item.nonPriorityReason}</dd>
          </div>

          <Collapsible>
            <CollapsibleTrigger className="w-full">
              <div className="border border-dashed p-2 rounded-lg w-full">Rates list</div>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2">
              <RatesTable rates={item.rates} />
            </CollapsibleContent>
          </Collapsible>
        </article>
      ))}
    </div>
  );
}
