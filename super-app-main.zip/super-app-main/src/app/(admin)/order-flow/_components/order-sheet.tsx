import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { OrderFlow } from "@/db/types";
import { format } from "date-fns";
import { OrderCourierChecks } from "./order-courier-checks";
import { OrderPacking } from "./order-packings";
import { OrderPickings } from "./order-pickings";
import { OrderReviews } from "./order-reviews";

interface Props {
  children: React.ReactNode;
  orderFlow: OrderFlow;
  asChild?: boolean;
}

export function OrderSheet({ children, orderFlow, asChild }: Props) {
  return (
    <Sheet>
      <SheetTrigger asChild={asChild}>{children}</SheetTrigger>
      <SheetContent className="w-full !max-w-2xl p-0">
        <ScrollArea className="h-dvh p-6">
          <SheetHeader>
            <SheetTitle className="text-lg flex gap-2 items-center">
              Order #{orderFlow.orderNumber}{" "}
              <Badge variant="default" className="rounded-full w-fit">
                Reviewed
              </Badge>
            </SheetTitle>
            {orderFlow.reviewedAt && (
              <p className="text-sm text-muted-foreground">Reviewed at {format(orderFlow.reviewedAt, "dd MMM yyyy")}</p>
            )}
          </SheetHeader>
          <Separator className="my-4" />
          <Accordion type="single" defaultValue="review" collapsible>
            <AccordionItem value="picking">
              <AccordionTrigger>Picking</AccordionTrigger>
              <AccordionContent>
                <OrderPickings orderNumber={orderFlow.orderNumber} />
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="review">
              <AccordionTrigger>Review</AccordionTrigger>
              <AccordionContent>
                <OrderReviews orderNumber={orderFlow.orderNumber} />
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="packing">
              <AccordionTrigger>Packing</AccordionTrigger>
              <AccordionContent>
                <OrderPacking orderNumber={orderFlow.orderNumber} />
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="courier-checks">
              <AccordionTrigger>Courier Checks</AccordionTrigger>
              <AccordionContent>
                <OrderCourierChecks orderNumber={orderFlow.orderNumber} />
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
