import { z } from "zod";

export const exportFormSchema = z.object({
  type: z.string(),
  warehouse: z.string().optional(),
  from: z.date(),
  to: z.date(),
});

export type ExportForm = z.infer<typeof exportFormSchema>;
