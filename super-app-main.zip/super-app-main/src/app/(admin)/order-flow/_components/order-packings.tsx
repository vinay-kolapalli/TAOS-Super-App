import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { useOrderPackings } from "../_hooks/orders";

interface Props {
  orderNumber: number;
}

export function OrderPacking({ orderNumber }: Props) {
  const { data, isLoading } = useOrderPackings(orderNumber);

  if (isLoading) {
    return <Skeleton className="h-24 w-full rounded-lg" />;
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-center py-6 bg-secondary/30 rounded-lg">
        <p className="text-muted-foreground">No packing data available</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {data.map((item, index) => (
        <article key={item.id || index} className="bg-secondary/20 rounded-lg p-4 border">
          <header className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-sm">
              Package {index + 1} • {format(item.createdAt, "dd MMM yyyy")}
            </h3>
          </header>

          <dl className="space-y-2">
            <div className="flex justify-between">
              <dt className="text-sm text-muted-foreground">Order Number:</dt>
              <dd className="text-sm font-medium">{item.orderNumber}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm text-muted-foreground">Employee:</dt>
              <dd className="text-sm font-medium capitalize">{item.employee}</dd>
            </div>
          </dl>
        </article>
      ))}
    </div>
  );
}
