"use client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { OrderFlow } from "@/db/types";
import { IconEye } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import Link from "next/link";
import { OrderSheet } from "./order-sheet";

export const columns: ColumnDef<OrderFlow & { warehouse: { id: number; name: string } }>[] = [
  {
    accessorKey: "orderNumber",
    header: "Order Number",
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "status",
    header: "Status",
    enableSorting: false,
    enableHiding: false,
    cell: ({ row }) => {
      const status = row.original.status;
      return (
        <Badge variant="outline" className="capitalize">
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "warehouse",
    header: "Warehouse",
    enableSorting: false,
    enableHiding: false,
    cell: ({ row }) => {
      const warehouse = row.original.warehouse.name;
      return (
        <div>
          <Link href={`/warehouses/${row.original.warehouse.id}`} className="hover:underline">
            {warehouse}
          </Link>
        </div>
      );
    },
  },
  {
    accessorKey: "plantsPickedAt",
    header: "Plants Picked At",
    cell: ({ row }) => {
      const plantsPickedAt = row.original.plantsPickedAt;
      return <div>{plantsPickedAt ? format(plantsPickedAt, "dd MMM yyyy HH:mm") : "-"}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "otherPickedAt",
    header: "Other Picked At",
    cell: ({ row }) => {
      const othersPickedAt = row.original.othersPickedAt;
      return <div>{othersPickedAt ? format(othersPickedAt, "dd MMM yyyy HH:mm") : "-"}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "reviewedAt",
    header: "Reviewed At",
    cell: ({ row }) => {
      const reviewedAt = row.original.reviewedAt;
      return <div>{reviewedAt ? format(reviewedAt, "dd MMM yyyy HH:mm") : "-"}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "packedAt",
    header: "Packed At",
    cell: ({ row }) => {
      const packedAt = row.original.packedAt;
      return <div>{packedAt ? format(packedAt, "dd MMM yyyy HH:mm") : "-"}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "courierCheckedAt",
    header: "Courier Checked At",
    cell: ({ row }) => {
      const courierCheckedAt = row.original.courierCheckedAt;
      return <div>{courierCheckedAt ? format(courierCheckedAt, "dd MMM yyyy HH:mm") : "-"}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    header: "Actions",
    cell: ({ row }) => {
      return (
        <OrderSheet orderFlow={row.original} asChild>
          <Button type="button" size="icon" variant="ghost">
            <IconEye />
          </Button>
        </OrderSheet>
      );
    },
  },
];
