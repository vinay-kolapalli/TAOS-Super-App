import { CourierPlatforms, CourierServices, Zones } from "@/data/shipping";
import { getSignedUrl } from "@/lib/s3";
import Image from "next/image";

interface Props {
  rates: {
    id: string;
    courier: { id: string; name: string; image: string };
    courierService: CourierServices;
    priority: number;
    platform: CourierPlatforms | null;
    zone: Zones;
    rate: number;
  }[];
}

export function RatesTable({ rates }: Props) {
  return (
    <div className="space-y-2">
      {rates.map((rate) => (
        <div key={rate.id} className="bg-background border rounded-lg p-2 hover:shadow-sm transition-shadow">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <div className="flex-shrink-0 hidden sm:block">
                <Image
                  src={getSignedUrl(rate.courier.image)}
                  width={50}
                  height={50}
                  alt={rate.courier.name}
                  className="size-10 rounded-md object-cover border"
                  onError={(e) => {
                    e.currentTarget.style.display = "none";
                  }}
                />
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="inline-flex items-center justify-center w-5 h-5 text-xs font-bold bg-primary/10 text-primary rounded-full">
                    {rate.priority}
                  </span>
                  <h4 className="font-medium text-sm truncate">{rate.courier.name}</h4>
                </div>

                <div className="flex items-center gap-x-2 text-xs text-muted-foreground flex-wrap">
                  <span className="capitalize">{rate.courierService}</span>
                  <span>•</span>
                  <span className="capitalize">{rate.platform ?? "Direct"}</span>
                  <span>•</span>
                  <span className="capitalize">{rate.zone}</span>
                </div>
              </div>
            </div>

            <div className="flex-shrink-0 text-right">
              <div className="text-lg font-bold text-primary">₹{rate.rate}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
