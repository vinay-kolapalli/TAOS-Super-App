"use client";
import { DatePickerWithRange } from "@/components/date-picker";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserWarehouseSelect } from "@/components/warehouse-select";
import { downloadCsv } from "@/utils/csv";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { endOfMonth, format, startOfMonth } from "date-fns";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "react-hot-toast";
import { exportData } from "../_utils/export";
import { exportFormSchema, type ExportForm } from "./schema";

export function ExportOptions() {
  const [open, setOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const form = useForm<ExportForm>({
    resolver: zodResolver(exportFormSchema),
    defaultValues: {
      type: "order-shipments",
      from: startOfMonth(new Date()),
      to: endOfMonth(new Date()),
      warehouse: "",
    },
  });

  const fromDate = form.watch("from");
  const toDate = form.watch("to");

  async function handleExport(values: ExportForm) {
    setIsExporting(true);
    const { data, error } = await safe(
      exportData({
        ...values,
        warehouse: values.warehouse ? Number(values.warehouse) : undefined,
      })
    );

    if (error) {
      toast.error(error.message);
      setIsExporting(false);
      return;
    }

    let fileName = `${values.type}-${format(values.from!, "yyyy-MM-dd")}-to-${format(values.to!, "yyyy-MM-dd")}.csv`;
    downloadCsv(data?.data ?? "", fileName);
    setIsExporting(false);
    setOpen(false);
  }

  return (
    <div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button>Export</Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Download Data</DialogTitle>
            <DialogDescription>Extract order data to a CSV file.</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleExport)} className="space-y-4">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="plant-pickings">Plant Pickings</SelectItem>
                        <SelectItem value="other-pickings">Other Pickings</SelectItem>
                        <SelectItem value="reviews">Reviews</SelectItem>
                        <SelectItem value="packings">Packings</SelectItem>
                        <SelectItem value="order-shipments">Order Shipments</SelectItem>
                        <SelectItem value="order-shipment-with-rates">Order Shipment With Rates</SelectItem>
                        <SelectItem value="products-report">Products Report</SelectItem>
                        <SelectItem value="boxes-report">Boxes Report</SelectItem>
                        <SelectItem value="pincode-report">Pincode Report</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="warehouse"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Warehouse</FormLabel>
                    <UserWarehouseSelect className="w-full" value={field.value} onValueChange={field.onChange} />
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="from"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date Range</FormLabel>
                    <FormControl>
                      <DatePickerWithRange
                        className="*:w-full"
                        value={{
                          from: fromDate,
                          to: toDate,
                        }}
                        onValueChange={(range) => {
                          form.setValue("from", range?.from!);
                          form.setValue("to", range?.to!);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={isExporting} isLoading={isExporting}>
                Export
              </Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
