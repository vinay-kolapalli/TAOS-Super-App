"use client";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserWarehouseSelect } from "@/components/warehouse-select";
import { orderFlowStatusOptions } from "@/data/order-flow";
import { IconSearch } from "@tabler/icons-react";
import { useQueryState } from "nuqs";

export function OrderFlowFilters() {
  const [status, setStatus] = useQueryState("status", {
    defaultValue: orderFlowStatusOptions.map((option) => option.value),
    parse: (value) => value.split(",").filter(Boolean),
    serialize: (value) => value.join(","),
    shallow: false,
  });
  const [warehouse, setWarehouse] = useQueryState("warehouse", {
    defaultValue: "",
    shallow: false,
  });
  const [search, setSearch] = useQueryState("search", {
    defaultValue: "",
    shallow: false,
  });

  function handleStatusChange(value: string) {
    if (value === "all") {
      setStatus(orderFlowStatusOptions.map((option) => option.value));
    } else {
      setStatus(status.includes(value) ? status.filter((s) => s !== value) : [...status, value]);
    }
  }

  function handleSearch(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const search = formData.get("search") as string;
    setSearch(search);
  }

  return (
    <div className="w-fit flex gap-2">
      <Select onValueChange={handleStatusChange}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Select status">
            {status.length === 0 ? "All" : `${status.length} selected`}
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All</SelectItem>
          {orderFlowStatusOptions.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              <div className="flex items-center gap-2">
                <Checkbox checked={status.includes(option.value)} className="pointer-events-none" />
                {option.label}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <UserWarehouseSelect value={warehouse} onValueChange={setWarehouse} />
      <form className="flex gap-2" onSubmit={handleSearch}>
        <Input type="number" name="search" placeholder="Order number" defaultValue={search || ""} />
        <Button variant="outline" size="icon">
          <IconSearch />
        </Button>
      </form>
    </div>
  );
}
