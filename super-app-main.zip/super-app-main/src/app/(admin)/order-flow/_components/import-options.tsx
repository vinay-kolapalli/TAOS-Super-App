"use client";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { orpc } from "@/lib/orpc/client";
import { safe } from "@orpc/client";
import { IconChevronDown } from "@tabler/icons-react";
import Link from "next/link";
import { useState } from "react";
import { toast } from "react-hot-toast";

export function ImportOptions() {
  const [open, setOpen] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [type, setType] = useState<string>("courier-checks");

  async function handleImport(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setIsImporting(false);
    const formData = new FormData(e.currentTarget);
    const file = formData.get("file") as File;
    const { error, data } = await safe(orpc.orders.shipments.import({ file }));
    setIsImporting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    setOpen(false);
  }

  return (
    <div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="outline">Import</Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import Data</DialogTitle>
            <DialogDescription>Import order data from a CSV file.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleImport} className="space-y-4">
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="courier-checks">Courier Checks</SelectItem>
              </SelectContent>
            </Select>
            <div>
              <Input type="file" accept=".csv" name="file" required />
            </div>
            <ImportInstructions type={type} />
            <Button className="w-full" disabled={isImporting} isLoading={isImporting}>
              Import
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ImportInstructions({ type }: { type: string }) {
  let content = null;
  if (type === "courier-checks") {
    content = (
      <div>
        <Link
          href="/files/samples/order-flow-courier-checks-import.csv"
          className="text-[10px] text-muted-foreground"
          target="_blank"
        >
          Click here to download sample CSV
        </Link>
        <div className="text-xs text-muted-foreground bg-muted p-2 rounded-md space-y-2 mt-2">
          <p>The CSV file should have the following columns:</p>
          <ul className="list-disc pl-4 space-y-1 *:text-xs">
            <li>tracking_number</li>
            <li>picked_at (Optional)</li>
            <li>delivered_at (Optional)</li>
            <li>status (pending, delivered, rto, expired, unknown)</li>
          </ul>
        </div>
      </div>
    );
  }

  return (
    <Collapsible>
      <CollapsibleTrigger className="text-xs text-muted-foreground flex justify-between items-center gap-1 w-full data-[state=open]:[&>svg]:rotate-180">
        Instructions <IconChevronDown size={16} />
      </CollapsibleTrigger>
      <CollapsibleContent className="space-y-2">{content}</CollapsibleContent>
    </Collapsible>
  );
}
