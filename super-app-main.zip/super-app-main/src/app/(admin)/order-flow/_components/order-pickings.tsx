import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { ExternalLink } from "lucide-react";
import Link from "next/link";
import { useOrderPickings } from "../_hooks/orders";

interface Props {
  orderNumber: number;
}

export function OrderPickings({ orderNumber }: Props) {
  const { data, isLoading } = useOrderPickings(orderNumber);

  if (isLoading) {
    return <Skeleton className="h-24 w-full rounded-lg" />;
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-center py-6 bg-secondary/30 rounded-lg">
        <p className="text-muted-foreground">No picking data available</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {data.map((item, index) => (
        <article key={item.id || index} className="bg-secondary/20 rounded-lg p-4 border">
          <header className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-sm">
              Package {index + 1} • {format(item.createdAt, "dd MMM yyyy")}
            </h3>
            <Badge variant="secondary" className="capitalize">
              {item.type}
            </Badge>
          </header>

          <div className="grid md:grid-cols-2 gap-4 items-start">
            <dl className="space-y-2">
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Order Number:</dt>
                <dd className="text-sm font-medium">{item.orderNumber}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-muted-foreground">Employee:</dt>
                <dd className="text-sm font-medium capitalize">{item.employee}</dd>
              </div>
            </dl>

            {item.image && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Image:</span>
                <Link href={item.image} target="_blank" className="flex items-center gap-2">
                  <ExternalLink className="h-4 w-4" /> Preview
                </Link>
              </div>
            )}
          </div>
        </article>
      ))}
    </div>
  );
}
