import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { useOrderReview } from "../_hooks/orders";

interface Props {
  orderNumber: number;
}

export function OrderReviews({ orderNumber }: Props) {
  const { data, isLoading } = useOrderReview(orderNumber);

  if (isLoading) {
    return <Skeleton className="h-24 w-full rounded-lg" />;
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-center py-4 bg-secondary/30 rounded-lg">
        <p className="text-muted-foreground">No review data available</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {data.map((review, index) => (
        <article key={review.id} className="bg-secondary/20 rounded-lg p-4 border">
          <header className="flex justify-between mb-3">
            <h3 className="text-sm font-medium">
              Review {index + 1} • {format(review.createdAt, "dd MMM yyyy")}
            </h3>
            <p className="text-sm">
              <span className="text-muted-foreground mr-2">Reviewed by:</span>
              <span className="font-medium capitalize">{review.reviewedBy}</span>
            </p>
          </header>

          <section>
            <h4 className="text-sm font-medium mb-2 text-muted-foreground">Products:</h4>
            <ol className="space-y-2 list-decimal list-inside">
              {review.scannedProducts.map((product) => (
                <li className="text-sm" key={product}>
                  {product}
                </li>
              ))}
            </ol>
          </section>
        </article>
      ))}
    </div>
  );
}
