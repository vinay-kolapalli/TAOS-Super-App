"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { OrderFlow } from "@/db/types";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { columns } from "./columns";

interface Props {
  orders: (OrderFlow & { warehouse: { id: number; name: string } })[];
  totalOrders: number;
  isLoading?: boolean;
}

export function OrdersFlows({ orders, totalOrders, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });

  const table = useReactTable({
    data: orders,
    pageCount: Math.ceil(totalOrders / pagination.pageSize),
    columns,
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    state: {
      pagination,
    },
  });

  return (
    <DataTable
      table={table}
      paginationType="numeric"
      isLoading={isLoading}
      extraPaginationOptions={[150, 200, 250, 500]}
    />
  );
}
