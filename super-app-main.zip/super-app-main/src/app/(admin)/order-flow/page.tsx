import { db } from "@/db";
import { orderFlows } from "@/db/schema/order-flow";
import { getSession } from "@/lib/auth";
import { and, count, desc, eq, inArray } from "drizzle-orm";
import { nanoid } from "nanoid";
import { Suspense } from "react";
import { ExportOptions } from "./_components/export-options";
import { ImportOptions } from "./_components/import-options";
import { OrderFlowFilters } from "./_components/order-flow-filters";
import { OrdersFlows } from "./_components/order-flows";

interface Props {
  searchParams: Promise<{
    page: string;
    per_page: string;
    search: string;
    status: string;
    warehouse: string;
  }>;
}

export default function Page(props: Props) {
  return (
    <div className="space-y-4 w-full">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-lg font-bold">Order Flow</h2>
        <div className="flex gap-4 justify-between flex-wrap">
          <OrderFlowFilters />
          <ImportOptions />
          <ExportOptions />
        </div>
      </div>
      <Suspense key={nanoid()} fallback={<OrdersFlows orders={[]} totalOrders={0} isLoading={true} />}>
        <PageWithFetch {...props} />
      </Suspense>
    </div>
  );
}

async function PageWithFetch({ searchParams }: Props) {
  const searchParamsList = await searchParams;
  const page = Number(searchParamsList.page ?? 1);
  const per_page = Number(searchParamsList.per_page ?? 10);
  const status = searchParamsList.status ? searchParamsList.status.split(",") : [];
  const search = searchParamsList.search ?? "";
  const warehouse = searchParamsList.warehouse ? Number(searchParamsList.warehouse) : undefined;

  const session = await getSession();
  if (!session) throw new Error("Unauthorized");

  const userWarehouses = [session.user.primaryWarehouse, ...session.user.otherWarehouses];
  const validWarehouses = warehouse && userWarehouses.includes(warehouse) ? [warehouse] : userWarehouses;

  const where = and(
    status.length > 0 ? inArray(orderFlows.status, status) : undefined,
    search ? eq(orderFlows.orderNumber, parseInt(search)) : undefined,
    inArray(orderFlows.warehouse, validWarehouses)
  );

  const orderFlowData = await db.query.orderFlows.findMany({
    limit: per_page,
    offset: (page - 1) * per_page,
    where,
    orderBy: desc(orderFlows.orderNumber),
    with: {
      warehouse: {
        columns: {
          id: true,
          name: true,
        },
      },
    },
  });

  const [totalOrderFlows] = await db.select({ count: count() }).from(orderFlows).where(where);

  return <OrdersFlows orders={orderFlowData} totalOrders={totalOrderFlows.count} />;
}
