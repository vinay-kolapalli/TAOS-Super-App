import { PackingForm } from "./_components/packing-form";

export default function Page() {
  return (
    <div className="flex-1">
      <PackingForm />
    </div>
  );
}
