"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { orpc } from "@/lib/orpc/client";
import { createPackingInputSchema, CreatePackingInputSchema } from "@/router/orders/packings/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { useRef } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { sendPackingDataToForm } from "../_utils/send-data-to-form";

export function PackingForm() {
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const orderNumberInputRef = useRef<HTMLInputElement | null>(null);

  const form = useForm<CreatePackingInputSchema>({
    resolver: zodResolver(createPackingInputSchema),
    defaultValues: {
      orderNumber: 0,
      employee: "",
    },
  });
  const { isSubmitting } = form.formState;

  async function handleSubmit(values: CreatePackingInputSchema) {
    safe(orpc.orders.packings.create(values)).then(({ error }) => {
      if (error) {
        toast.error(error.message);
        return;
      }
    });
    sendPackingDataToForm({
      employee: values.employee,
      orderNumber: values.orderNumber,
    });
    toast.success("Packing recorded successfully");
    form.reset({
      orderNumber: undefined,
      employee: values.employee,
    });
    // Focus back on the order number input after successful submission
    setTimeout(() => orderNumberInputRef.current?.focus(), 100);
  }

  function handleInputError(e: React.KeyboardEvent<HTMLInputElement>) {
    e.currentTarget.focus();
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Packing Form</CardTitle>
        <CardDescription>Record product packing.</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form className="space-y-4" onSubmit={form.handleSubmit(handleSubmit)}>
            <FormField
              control={form.control}
              name="orderNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Order number</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      value={field.value || ""}
                      disabled={isSubmitting}
                      ref={orderNumberInputRef}
                      onError={handleInputError}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="employee"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Employee</FormLabel>
                  <FormControl>
                    <Input {...field} value={field.value || ""} disabled={isSubmitting} onError={handleInputError} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button ref={buttonRef} type="submit" disabled={isSubmitting} isLoading={isSubmitting}>
              Submit
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
