import { employees } from "@/data/employee";

interface PackingData {
  orderNumber: number;
  employee: string;
}

export async function sendPackingDataToForm(data: PackingData) {
  try {
    const formUrl = new URL(
      "https://docs.google.com/forms/d/e/1FAIpQLSekrMzS_9IMwQ5r9ZIlX0EXLQMUDNrJL8eiVi_sWbGjly8PRw/formResponse",
    );
    formUrl.searchParams.set("usp", "pp_formUrl");
    const employee = employees.get(Number(data.employee));
    formUrl.searchParams.set(
      "entry.1406130673",
      employee?.name ?? data.employee,
    );
    formUrl.searchParams.set("entry.125291979", String(data.orderNumber));
    await fetch(formUrl);
  } catch (error) {}
}
