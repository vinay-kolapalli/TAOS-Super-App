"use client";
import { DatePickerWithRange } from "@/components/date-picker";
import { Button } from "@/components/ui/button";
import { UserWarehouseSelect } from "@/components/warehouse-select";
import { RefreshCw } from "lucide-react";
import { useRouter } from "next/navigation";
import { DateRange } from "react-day-picker";
import { useDashboardFilters } from "../_hooks/use-dashboard-filters";

export function DashboardFilters() {
  const { filters, setFrom, setTo, setWarehouseId } = useDashboardFilters();
  const router = useRouter();

  function handleDateChange(date: DateRange | undefined) {
    if (date?.from && date?.to) {
      setFrom(date.from.toISOString());
      setTo(date.to.toISOString());
    }
  }

  function handleRefresh() {
    router.refresh();
  }

  return (
    <div className="flex items-center gap-4 flex-wrap">
      <Button variant="outline" size="icon" onClick={handleRefresh}>
        <RefreshCw className="h-4 w-4" />
      </Button>
      <UserWarehouseSelect value={filters.warehouseId} onValueChange={setWarehouseId} />
      <DatePickerWithRange value={filters.dateRange} onValueChange={handleDateChange} />
    </div>
  );
}
