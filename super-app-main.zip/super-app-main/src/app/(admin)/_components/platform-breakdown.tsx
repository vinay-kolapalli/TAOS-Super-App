import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { courierPlatformsOptions } from "@/data/shipping";
import { db } from "@/db";
import { orderShipmentRates, orderShipments } from "@/db/schema/courier-checker";
import { and, count, desc, eq, gte, inArray, lte, sum } from "drizzle-orm";
import { Globe } from "lucide-react";
import { nanoid } from "nanoid";
import { Suspense } from "react";
import { DashboardFilter } from "../_types/dashboard";

interface Props {
  filters: DashboardFilter;
  userWarehouses: number[];
}

export function PlatformBreakdown({ filters, userWarehouses }: Props) {
  return (
    <Suspense key={nanoid()} fallback={<Skeleton className="h-60 w-full" />}>
      <PlatformBreakdownWithFetch filters={filters} userWarehouses={userWarehouses} />
    </Suspense>
  );
}

export async function PlatformBreakdownWithFetch({ filters, userWarehouses }: Props) {
  const warehousesToFilter = filters.warehouseId ? [filters.warehouseId] : userWarehouses;

  const platformData = await db
    .select({
      platform: orderShipmentRates.platform,
      shipmentCount: count(),
      totalExpense: sum(orderShipmentRates.rate),
    })
    .from(orderShipments)
    .leftJoin(orderShipmentRates, eq(orderShipments.rate, orderShipmentRates.id))
    .where(
      and(
        gte(orderShipments.createdAt, filters.dateRange.from),
        lte(orderShipments.createdAt, filters.dateRange.to),
        inArray(orderShipments.warehouse, warehousesToFilter)
      )
    )
    .groupBy(orderShipmentRates.platform)
    .orderBy(desc(count()));

  if (platformData.length === 0) {
    return <EmptyState />;
  }

  return (
    <Card className="p-4">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 p-0 pb-1">
        <CardTitle className="text-base font-medium">Platform Breakdown</CardTitle>
        <Globe className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent className="space-y-3 p-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
          {platformData.map((platform) => (
            <PlatformItem key={platform.platform || "direct"} platform={platform} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

interface PlatformData {
  platform: string | null;
  shipmentCount: number;
  totalExpense: string | null;
}

interface PlatformItemProps {
  platform: PlatformData;
}

function PlatformItem({ platform }: PlatformItemProps) {
  const platformValue = platform.platform || "direct";
  const platformOption = courierPlatformsOptions.find((option) => option.value === platformValue);
  const platformDisplayName = platformOption?.label || (platformValue === "direct" ? "Direct" : platformValue);

  return (
    <div
      key={platformValue}
      className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 border rounded-lg hover:bg-muted/50 transition-colors"
    >
      <div className="flex items-center gap-2.5 mb-2.5 sm:mb-0 sm:flex-1">
        <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center">
          <Globe className="h-4 w-4 text-primary" />
        </div>
        <div>
          <h4 className="font-medium text-sm">{platformDisplayName}</h4>
          <div className="text-xs text-muted-foreground sm:hidden">
            {platform.shipmentCount.toLocaleString()} shipments • ₹{Number(platform.totalExpense || 0).toLocaleString()}
          </div>
        </div>
      </div>

      <div className="hidden sm:flex items-center gap-6">
        <div className="text-center min-w-0">
          <div className="font-semibold text-base">{platform.shipmentCount.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">shipments</div>
        </div>
        <div className="text-center min-w-0">
          <div className="font-semibold text-base text-red-400">
            ₹{Number(platform.totalExpense || 0).toLocaleString()}
          </div>
          <div className="text-xs text-muted-foreground">expense</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:hidden">
        <div className="text-center p-2 bg-muted/50 rounded">
          <div className="font-semibold">{platform.shipmentCount.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">shipments</div>
        </div>
        <div className="text-center p-2 bg-muted/50 rounded">
          <div className="font-semibold text-red-400">₹{Number(platform.totalExpense || 0).toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">expense</div>
        </div>
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Platform Breakdown</CardTitle>
        <Globe className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">No shipments found in this date range</p>
      </CardContent>
    </Card>
  );
}
