import { Skeleton } from "@/components/ui/skeleton";
import { db } from "@/db";
import { orderShipments } from "@/db/schema/courier-checker";
import { orderPickings } from "@/db/schema/pick-and-pack";
import { orderReviews } from "@/db/schema/review-desk";
import { getOrderCount } from "@/lib/shopify/orders";
import { and, eq, gte, inArray, lte } from "drizzle-orm";
import { ClipboardCheck, IndianRupee, Package, Truck } from "lucide-react";
import { nanoid } from "nanoid";
import { Suspense } from "react";
import { DashboardFilter } from "../_types/dashboard";
import { MetricCard } from "./metric-card";

interface Props {
  filters: DashboardFilter;
  userWarehouses: number[];
}

export function DashboardSummary({ filters, userWarehouses }: Props) {
  return (
    <Suspense
      key={nanoid()}
      fallback={
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {Array.from({ length: 6 }).map((_, index) => (
            <Skeleton key={index} className="h-[98px] w-full" />
          ))}
        </div>
      }
    >
      <DashboardSummaryWithFetch filters={filters} userWarehouses={userWarehouses} />
    </Suspense>
  );
}

export async function DashboardSummaryWithFetch({ filters, userWarehouses }: Props) {
  const warehousesToFilter = filters.warehouseId ? [filters.warehouseId] : userWarehouses;

  const [
    shippedOrderNumbers,
    pickedPlantsOrderNumbers,
    pickedOtherOrderNumbers,
    reviewedOrderNumbers,
    totalPendingOrders,
  ] = await Promise.all([
    db
      .selectDistinct({ orderNumber: orderShipments.orderNumber })
      .from(orderShipments)
      .where(
        and(
          gte(orderShipments.createdAt, filters.dateRange.from),
          lte(orderShipments.createdAt, filters.dateRange.to),
          inArray(orderShipments.warehouse, warehousesToFilter)
        )
      ),
    db
      .selectDistinct({ orderNumber: orderPickings.orderNumber })
      .from(orderPickings)
      .where(
        and(
          gte(orderPickings.createdAt, filters.dateRange.from),
          lte(orderPickings.createdAt, filters.dateRange.to),
          eq(orderPickings.type, "plants"),
          inArray(orderPickings.warehouse, warehousesToFilter)
        )
      ),
    db
      .selectDistinct({ orderNumber: orderPickings.orderNumber })
      .from(orderPickings)
      .where(
        and(
          gte(orderPickings.createdAt, filters.dateRange.from),
          lte(orderPickings.createdAt, filters.dateRange.to),
          eq(orderPickings.type, "other"),
          inArray(orderPickings.warehouse, warehousesToFilter)
        )
      ),
    db
      .selectDistinct({ orderNumber: orderReviews.orderNumber })
      .from(orderReviews)
      .where(
        and(
          gte(orderReviews.createdAt, filters.dateRange.from),
          lte(orderReviews.createdAt, filters.dateRange.to),
          inArray(orderReviews.warehouse, warehousesToFilter)
        )
      ),
    getOrderCount(
      `tag:'status:processing' OR tag:'status:on-hold' OR tag:'status:previewed' OR tag:'status:printed' AND ${warehousesToFilter.map((warehouse) => `tag:'warehouse:${warehouse}'`).join(" OR ")}`
    ),
  ]);

  const shippedCount = new Set(shippedOrderNumbers.map((item) => item.orderNumber)).size;
  const pickedPlantsCount = new Set(pickedPlantsOrderNumbers.map((item) => item.orderNumber)).size;
  const pickedOtherCount = new Set(pickedOtherOrderNumbers.map((item) => item.orderNumber)).size;
  const reviewedCount = new Set(reviewedOrderNumbers.map((item) => item.orderNumber)).size;

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
      <MetricCard title="Pending Orders" value={totalPendingOrders} icon={Truck} subtitle="Awaiting processing" />
      <MetricCard title="Plants Picked" value={pickedPlantsCount} icon={Package} subtitle="Plant orders ready" />
      <MetricCard title="Other Picked" value={pickedOtherCount} icon={Package} subtitle="Non-plant orders ready" />
      <MetricCard title="Orders Reviewed" value={reviewedCount} icon={ClipboardCheck} subtitle="Quality checked" />
      <MetricCard title="Shipped Orders" value={shippedCount} icon={Truck} subtitle="Successfully dispatched" />
      <MetricCard
        title="Packing Revenue"
        value={`₹${(shippedCount * 18).toLocaleString()}`}
        icon={IndianRupee}
        subtitle="Revenue from packing fees"
      />
    </div>
  );
}
