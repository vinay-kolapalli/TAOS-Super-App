import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { db } from "@/db";
import { orderShipments } from "@/db/schema/courier-checker";
import { boxes } from "@/db/schema/shipping";
import { and, count, desc, eq, gte, inArray, lte } from "drizzle-orm";
import { Package2 } from "lucide-react";
import { nanoid } from "nanoid";
import { Suspense } from "react";
import { DashboardFilter } from "../_types/dashboard";

interface Props {
  filters: DashboardFilter;
  userWarehouses: number[];
}

export function BoxesBreakdown({ filters, userWarehouses }: Props) {
  return (
    <Suspense key={nanoid()} fallback={<Skeleton className="h-72 w-full" />}>
      <BoxesBreakdownWithFetch filters={filters} userWarehouses={userWarehouses} />
    </Suspense>
  );
}

export async function BoxesBreakdownWithFetch({ filters, userWarehouses }: Props) {
  const warehousesToFilter = filters.warehouseId ? [filters.warehouseId] : userWarehouses;

  const boxesData = await db
    .select({
      boxId: orderShipments.box,
      boxName: boxes.name,
      count: count(),
    })
    .from(orderShipments)
    .leftJoin(boxes, eq(orderShipments.box, boxes.id))
    .where(
      and(
        gte(orderShipments.createdAt, filters.dateRange.from),
        lte(orderShipments.createdAt, filters.dateRange.to),
        inArray(orderShipments.warehouse, warehousesToFilter)
      )
    )
    .groupBy(orderShipments.box, boxes.name)
    .orderBy(desc(count()));

  const totalBoxes = boxesData.reduce((sum, box) => sum + box.count, 0);

  if (totalBoxes === 0) {
    return <EmptyState />;
  }

  return (
    <Card className="p-4">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 p-0 pb-1">
        <CardTitle className="text-base font-medium">Box Usage</CardTitle>
        <Package2 className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent className="space-y-3 p-0">
        <SummaryStats totalBoxes={totalBoxes} uniqueBoxes={boxesData.length} />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
          {boxesData.map((box) => (
            <BoxItem key={box.boxId} box={box} totalBoxes={totalBoxes} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

interface BoxData {
  boxId: string;
  boxName: string | null;
  count: number;
}

interface SummaryStatsProps {
  totalBoxes: number;
  uniqueBoxes: number;
}

function SummaryStats({ totalBoxes, uniqueBoxes }: SummaryStatsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-muted/30 rounded-lg">
      <div className="text-center sm:text-left">
        <div className="text-xl font-semibold text-primary">{totalBoxes.toLocaleString()}</div>
        <div className="text-xs text-muted-foreground">Total Boxes Used</div>
      </div>
      <div className="text-center sm:text-right">
        <div className="text-xl font-semibold text-blue-600">{uniqueBoxes}</div>
        <div className="text-xs text-muted-foreground">Unique Boxes</div>
      </div>
    </div>
  );
}

interface BoxItemProps {
  box: BoxData;
  totalBoxes: number;
}

function BoxItem({ box, totalBoxes }: BoxItemProps) {
  const percentage = (box.count / totalBoxes) * 100;
  const boxDisplayName = box.boxName || box.boxId || "Unknown Box";

  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 border rounded-lg hover:bg-muted/50 transition-colors">
      <div className="flex items-center gap-2.5 mb-2.5 sm:mb-0 sm:flex-1">
        <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
          <Package2 className="w-4 h-4 text-primary" />
        </div>
        <div>
          <h4 className="font-medium text-sm">{boxDisplayName}</h4>
          <div className="text-xs text-muted-foreground sm:hidden">
            {box.count.toLocaleString()} boxes • {percentage.toFixed(1)}%
          </div>
        </div>
      </div>

      <div className="hidden sm:flex items-center gap-6">
        <div className="text-center min-w-0">
          <div className="font-semibold text-base">{box.count.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">{percentage.toFixed(1)}% of total</div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-2 sm:hidden">
        <div className="text-center p-2 bg-muted/50 rounded">
          <div className="font-semibold">{box.count.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">{percentage.toFixed(1)}% of total</div>
        </div>
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Box Usage</CardTitle>
        <Package2 className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">No boxes used in this date range</p>
      </CardContent>
    </Card>
  );
}
