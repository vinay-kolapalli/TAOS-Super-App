import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { db } from "@/db";
import { orderShipmentRates, orderShipments } from "@/db/schema/courier-checker";
import { couriers } from "@/db/schema/shipping";
import { getSignedUrl } from "@/lib/s3";
import { and, count, desc, eq, gte, inArray, lte, sum } from "drizzle-orm";
import { Truck } from "lucide-react";
import { nanoid } from "nanoid";
import Image from "next/image";
import { Suspense } from "react";
import { DashboardFilter } from "../_types/dashboard";

interface Props {
  filters: DashboardFilter;
  userWarehouses: number[];
}

export function CourierBreakdown({ filters, userWarehouses }: Props) {
  return (
    <Suspense key={nanoid()} fallback={<Skeleton className="h-72 w-full" />}>
      <CourierBreakdownWithFetch filters={filters} userWarehouses={userWarehouses} />
    </Suspense>
  );
}

export async function CourierBreakdownWithFetch({ filters, userWarehouses }: Props) {
  const warehousesToFilter = filters.warehouseId ? [filters.warehouseId] : userWarehouses;

  const courierData = await db
    .select({
      courierId: orderShipmentRates.courier,
      courierName: couriers.name,
      courierImage: couriers.image,
      shipmentCount: count(),
      totalExpense: sum(orderShipmentRates.rate),
    })
    .from(orderShipments)
    .leftJoin(orderShipmentRates, eq(orderShipments.rate, orderShipmentRates.id))
    .leftJoin(couriers, eq(orderShipmentRates.courier, couriers.id))
    .where(
      and(
        gte(orderShipments.createdAt, filters.dateRange.from),
        lte(orderShipments.createdAt, filters.dateRange.to),
        inArray(orderShipments.warehouse, warehousesToFilter)
      )
    )
    .groupBy(orderShipmentRates.courier, couriers.name, couriers.image)
    .orderBy(desc(count()));

  const totalShipments = courierData.reduce((sum, courier) => sum + courier.shipmentCount, 0);
  const totalExpense = courierData.reduce((sum, courier) => sum + (Number(courier.totalExpense) || 0), 0);

  if (totalShipments === 0) {
    return <EmptyState />;
  }

  return (
    <Card className="p-4">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 p-0 pb-1">
        <CardTitle className="text-base font-medium">Courier Breakdown</CardTitle>
        <Truck className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent className="space-y-3 p-0">
        <SummaryStats totalShipments={totalShipments} totalExpense={totalExpense} />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
          {courierData.map((courier) => (
            <CourierItem
              key={courier.courierId}
              courier={courier}
              totalShipments={totalShipments}
              totalExpense={totalExpense}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

interface CourierData {
  courierId: string | null;
  courierName: string | null;
  courierImage: string | null;
  shipmentCount: number;
  totalExpense: string | null;
}

interface SummaryStatsProps {
  totalShipments: number;
  totalExpense: number;
}

function SummaryStats({ totalShipments, totalExpense }: SummaryStatsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-muted/30 rounded-lg">
      <div className="text-center sm:text-left">
        <div className="text-xl font-semibold text-primary">{totalShipments.toLocaleString()}</div>
        <div className="text-xs text-muted-foreground">Total Shipments</div>
      </div>
      <div className="text-center sm:text-right">
        <div className="text-xl font-semibold text-red-400">₹{totalExpense.toLocaleString()}</div>
        <div className="text-xs text-muted-foreground">Total Expense</div>
      </div>
    </div>
  );
}

interface CourierItemProps {
  courier: CourierData;
  totalShipments: number;
  totalExpense: number;
}

function CourierItem({ courier, totalShipments, totalExpense }: CourierItemProps) {
  const courierDisplayName = courier.courierName || courier.courierId || "Unknown Courier";
  const shipmentPercentage = (courier.shipmentCount / totalShipments) * 100;
  const expensePercentage = totalExpense > 0 ? ((Number(courier.totalExpense) || 0) / totalExpense) * 100 : 0;

  return (
    <div
      key={courier.courierId}
      className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 border rounded-lg hover:bg-muted/50 transition-colors"
    >
      <div className="flex items-center gap-2.5 mb-2.5 sm:mb-0 sm:flex-1">
        {courier.courierImage && (
          <Image
            src={getSignedUrl(courier.courierImage)}
            alt={courierDisplayName}
            className="size-8 rounded-lg object-cover"
            width={32}
            height={32}
          />
        )}
        <div>
          <h4 className="font-medium text-sm">{courierDisplayName}</h4>
          <div className="text-xs text-muted-foreground sm:hidden">
            {courier.shipmentCount.toLocaleString()} shipments • ₹{Number(courier.totalExpense || 0).toLocaleString()}
          </div>
        </div>
      </div>

      <div className="hidden sm:flex items-center gap-6">
        <div className="text-center min-w-0">
          <div className="font-semibold text-base">{courier.shipmentCount.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">{shipmentPercentage.toFixed(1)}% of shipments</div>
        </div>
        <div className="text-center min-w-0">
          <div className="font-semibold text-base text-red-400">
            ₹{Number(courier.totalExpense || 0).toLocaleString()}
          </div>
          <div className="text-xs text-muted-foreground">{expensePercentage.toFixed(1)}% of expense</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:hidden">
        <div className="text-center p-2 bg-muted/50 rounded">
          <div className="font-semibold">{courier.shipmentCount.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">{shipmentPercentage.toFixed(1)}% shipments</div>
        </div>
        <div className="text-center p-2 bg-muted/50 rounded">
          <div className="font-semibold text-red-400">₹{Number(courier.totalExpense || 0).toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">{expensePercentage.toFixed(1)}% expense</div>
        </div>
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-medium">Courier Breakdown</CardTitle>
        <Truck className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">No shipments found in this date range</p>
      </CardContent>
    </Card>
  );
}
