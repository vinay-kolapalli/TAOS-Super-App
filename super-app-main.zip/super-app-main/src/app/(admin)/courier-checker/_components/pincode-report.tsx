"use client";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import usePincodeReport from "@/hooks/pincode";
import { ShipmentReportOutputSchema } from "@/router/orders/shipments/schema";
import {
  IconClock,
  IconCurrencyRupee,
  IconPackage,
  IconTruck,
  IconTruckDelivery,
  IconTruckReturn,
} from "@tabler/icons-react";
import { useCourierChecker } from "../_context/courier-checker";

export default function PincodeReport() {
  const { activeOrder } = useCourierChecker();
  const { data, isLoading } = usePincodeReport(activeOrder?.shipping.postcode);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-32" />
        </CardHeader>
        <CardContent>
          <Skeleton className="w-full h-40" />
        </CardContent>
      </Card>
    );
  }

  if (!data || !activeOrder) {
    return (
      <div className="border border-dashed rounded-lg p-4 min-h-28 flex items-center justify-center">
        <p className="text-sm text-muted-foreground">Enter order number to view pincode report</p>
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <IconPackage stroke={1.5} size={20} />
          Pincode Report
        </CardTitle>
        <CardDescription>Insights based on last 500 shipments shipped to this pincode.</CardDescription>

        {/* Legend */}
        <div className="flex flex-wrap gap-4 pt-2 text-xs">
          <div className="flex items-center gap-1">
            <IconTruckDelivery size={12} className="text-green-600" />
            <span className="text-muted-foreground">Delivery Rate</span>
          </div>
          <div className="flex items-center gap-1">
            <IconTruckReturn size={12} className="text-red-600" />
            <span className="text-muted-foreground">RTO Rate</span>
          </div>
          <div className="flex items-center gap-1">
            <IconClock size={12} className="text-blue-600" />
            <span className="text-muted-foreground">Avg Delivery Days</span>
          </div>
          <div className="flex items-center gap-1">
            <IconCurrencyRupee size={12} className="text-orange-600" />
            <span className="text-muted-foreground">Avg Rate</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-60">
          <div className="w-[calc(100dvw-80px)] md:w-full space-y-4">
            {data.couriers.map((courier) => (
              <ReportCard key={courier.id} {...courier} />
            ))}
            {data.couriers.length === 0 && (
              <div className="text-sm text-muted-foreground text-center py-8">
                No shipment data available for this pincode
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function ReportCard({
  id,
  name,
  totalShipments,
  averageDeliveryTimeInDays,
  deliveredCount,
  rtoCount,
  averageRate,
  platformBookings,
}: ShipmentReportOutputSchema["data"]["couriers"][number]) {
  const deliveryRate = totalShipments > 0 ? ((deliveredCount / totalShipments) * 100).toFixed(1) : 0;
  const rtoRate = totalShipments > 0 ? ((rtoCount / totalShipments) * 100).toFixed(1) : 0;

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-3">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 min-w-0">
            <div className="min-w-0 flex-1">
              <h3 className="font-medium text-sm whitespace-nowrap">{name}</h3>
              <div className="flex items-center gap-1">
                <IconTruck size={12} className="text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{totalShipments} shipments</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:gap-4 text-sm flex-wrap flex-1 sm:justify-end">
            <div className="flex items-center gap-1">
              <IconTruckDelivery size={14} className="text-green-600" />
              <span className="font-medium text-green-600">{deliveryRate}%</span>
            </div>
            <div className="flex items-center gap-1">
              <IconTruckReturn size={14} className="text-red-600" />
              <span className="font-medium text-red-600">{rtoRate}%</span>
            </div>
            <div className="flex items-center gap-1">
              <IconClock size={14} className="text-blue-600" />
              <span className="font-medium">
                {averageDeliveryTimeInDays !== null ? `${averageDeliveryTimeInDays}d` : "N/A"}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <IconCurrencyRupee size={14} className="text-orange-600" />
              <span className="font-medium">{averageRate}</span>
            </div>
          </div>
        </div>

        {Object.keys(platformBookings).length > 0 && (
          <div className="mt-2 pt-2 border-t">
            <div className="flex flex-wrap gap-1">
              {Object.entries(platformBookings).map(
                ([platform, count]) =>
                  count > 0 && (
                    <Badge key={platform} variant="secondary" className="text-xs px-1.5 py-0 capitalize">
                      {platform}: {count}
                    </Badge>
                  )
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
