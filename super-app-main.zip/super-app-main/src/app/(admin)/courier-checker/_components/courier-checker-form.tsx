"use client";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useRef, useState } from "react";
import toast from "react-hot-toast";
import { useCourierChecker } from "../_context/courier-checker";
import { packgedBy, scannedBy, shippingTypes } from "../_data/options";
import { useCourierOperations } from "../_hooks/use-courier-operations";
import { NotFirstPriorityCourierAlert } from "./alert";
import { CourierCheckerSchema } from "./schema";

export function CourierCheckerForm() {
  const [nonPriorityAlertOpen, setNonPriorityAlertOpen] = useState(false);
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const { form, activeOrder, rates, boxes } = useCourierChecker();
  const { processOrderFlow } = useCourierOperations();

  async function handleSubmit(values: CourierCheckerSchema) {
    if (!activeOrder?.id) {
      toast.error(`Please select an order`);
      return;
    }

    if (values.priorityNumber > 1 && rates.length > 0 && !values.nonPriorityReason) {
      setNonPriorityAlertOpen(true);
      return;
    }

    await processOrderFlow(rates, values.priorityNumber);
  }

  function handleAlertConfirm(reason: string) {
    form.setValue("nonPriorityReason", reason);
    setNonPriorityAlertOpen(false);
    setTimeout(() => {
      buttonRef.current?.click();
    }, 500);
  }

  return (
    <Form {...form}>
      <form className="flex flex-col gap-3" onSubmit={form.handleSubmit(handleSubmit)}>
        <FormField
          control={form.control}
          name="orderNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Order number</FormLabel>
              <FormControl>
                <Input type="text" inputMode="numeric" pattern="[0-9]*" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Label>Pincode</Label>
        <Input readOnly disabled value={activeOrder?.shipping?.postcode ?? ""} />
        <FormField
          control={form.control}
          name="box"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Box</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {boxes.map((box) => (
                    <SelectItem key={box.id} value={box.id}>
                      {box.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="weight"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Box weight (in kg)</FormLabel>
              <FormControl>
                <Input type="text" inputMode="decimal" pattern="[0-9]*\.?[0-9]*" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="trackingNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Tracking number</FormLabel>
              <FormControl>
                <Input {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="priorityNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Priority Number</FormLabel>
              <Select onValueChange={field.onChange} value={String(field.value)}>
                <FormControl>
                  <SelectTrigger className="capitalize">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {rates.map((rate, index) => (
                    <SelectItem className="capitalize" key={rate.courier.id + index} value={String(index + 1)}>
                      {index + 1}. {rate.courier.name} ({rate.courier.service}) - {rate.courier.platform ?? "Direct"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="packedBy"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Packed by</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {packgedBy.map((packged) => (
                    <SelectItem key={packged.value} value={packged.value}>
                      {packged.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="shippingType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Shipping type</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {shippingTypes.map((shipping) => (
                    <SelectItem key={shipping.name} value={shipping.id}>
                      {shipping.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="scannedBy"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Scanned by</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {scannedBy.map((scanned) => (
                    <SelectItem key={scanned.value} value={scanned.value}>
                      {scanned.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button ref={buttonRef} className="w-fit" disabled={!activeOrder?.isPaid}>
          Submit
        </Button>
        {!activeOrder?.isPaid && (
          <p className="text-sm text-muted-foreground">Note: Unpaid orders cannot be marked as shipped.</p>
        )}
        <NotFirstPriorityCourierAlert
          open={nonPriorityAlertOpen}
          onOpenChange={setNonPriorityAlertOpen}
          onConfirm={handleAlertConfirm}
        />
      </form>
    </Form>
  );
}
