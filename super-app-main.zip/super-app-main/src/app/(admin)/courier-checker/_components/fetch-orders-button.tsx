"use client";
import { Button } from "@/components/ui/button";
import { tryCatch } from "@/lib/try-catch";
import { useEffect, useRef, useState } from "react";
import toast from "react-hot-toast";
import { useCourierChecker } from "../_context/courier-checker";
import { fetchLatestOrders } from "../_utils/fetch";

export function FetchOrdersButton() {
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { setOrders } = useCourierChecker();

  async function handleFetchOrders() {
    setIsLoading(true);
    const toastId = toast.loading("Fetching orders...");
    const orders = await tryCatch(fetchLatestOrders());
    setIsLoading(false);
    if (orders.error) {
      toast.error("Failed to fetch orders", { id: toastId });
      return;
    }
    setOrders(orders.data);
    toast.success("Orders fetched successfully", { id: toastId });

    // Set interval after manual fetch
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    intervalRef.current = setInterval(() => {
      handleFetchOrders();
    }, 3600000);
  }

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return (
    <Button className="w-full" variant="outline" onClick={handleFetchOrders} disabled={isLoading}>
      Fetch Orders
    </Button>
  );
}
