"use client";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";
import { useCourierChecker } from "../_context/courier-checker";
import { AvailableCouriers } from "./available-couriers";
import { CourierMetadata } from "./courier-metadata";
import { CourierPriorityList } from "./courier-priority-list";

export function OrderCourierDetails() {
  const { activeOrder, courierData, rates, isLoadingCourierData, isLoadingRates } = useCourierChecker();

  if (!activeOrder) {
    return (
      <div className="border border-dashed rounded-lg p-4 min-h-[200px] flex items-center justify-center">
        <p className="text-sm text-muted-foreground">Enter order number to view courier details</p>
      </div>
    );
  }

  return (
    <Card className="overflow-hidden">
      <CardContent className="flex flex-col gap-4 pt-5">
        <AvailableCouriers isLoading={isLoadingCourierData} couriers={courierData} />
        <Accordion type="single" collapsible defaultValue="courier-priority-list">
          {courierData.map((courier) =>
            courier.metadata && courier.metadata.length > 0 ? (
              <AccordionItem key={courier.id + courier.platform + courier.platformId} value={`${courier.id}-metadata`}>
                <AccordionTrigger className="bg-secondary p-3 rounded-lg mb-2">
                  {courier.name} ({courier.service}) Metadata
                </AccordionTrigger>
                <AccordionContent>
                  <CourierMetadata key={courier.id} metadata={courier.metadata} />
                </AccordionContent>
              </AccordionItem>
            ) : null
          )}
          <AccordionItem value="courier-priority-list">
            <AccordionTrigger className="bg-secondary p-3 rounded-lg mb-2">Courier Priority List</AccordionTrigger>
            <AccordionContent className="pb-0">
              <CourierPriorityList rates={rates} isLoading={isLoadingRates} />
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}
