import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMemo, useState } from "react";
import { nonPriorityReasons } from "../_data/options";

interface Props {
  open: boolean;
  onOpenChange: React.Dispatch<React.SetStateAction<boolean>>;
  onConfirm?: (reason: string) => void;
}

export function NotFirstPriorityCourierAlert({ open, onOpenChange, onConfirm }: Props) {
  const [otherReason, setOtherReason] = useState("");
  const [nonPriorityReason, setNonPriorityReason] = useState(nonPriorityReasons[0]);
  const resolvedReason = useMemo(
    () => (nonPriorityReason === "other" ? otherReason : nonPriorityReason),
    [nonPriorityReason, otherReason]
  );

  function handleConfirm() {
    setNonPriorityReason(resolvedReason);
    onConfirm?.(resolvedReason);
  }

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Non-Priority Courier Selection</AlertDialogTitle>
          <AlertDialogDescription>
            You have selected a courier that is not the most cost-effective option based on our priority list. Please
            provide a reason to proceed with this selection.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <Select value={nonPriorityReason} onValueChange={setNonPriorityReason}>
          <SelectTrigger>
            <SelectValue placeholder="Select a reason" />
          </SelectTrigger>
          <SelectContent>
            {nonPriorityReasons.map((reason) => (
              <SelectItem key={reason} value={reason}>
                {reason}
              </SelectItem>
            ))}
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
        {nonPriorityReason === "other" && (
          <Input value={otherReason} onChange={(e) => setOtherReason(e.target.value)} placeholder="Enter your reason" />
        )}
        <AlertDialogFooter>
          <AlertDialogCancel type="button">Cancel</AlertDialogCancel>
          <AlertDialogAction type="button" disabled={!resolvedReason} onClick={handleConfirm}>
            Confirm
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
