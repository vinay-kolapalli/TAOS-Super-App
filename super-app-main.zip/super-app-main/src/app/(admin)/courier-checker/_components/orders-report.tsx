"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Courier } from "@/db/types";
import { useOrderReport } from "../_hooks/use-order-report";

interface Props {
  couriers: Pick<Courier, "id" | "name">[];
}

export function OrdersReport({ couriers }: Props) {
  const { isLoading, selectedCourier, setSelectedCourier, downloadReport } = useOrderReport();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Order Report</CardTitle>
        <CardDescription>Download the orders report in CSV format. </CardDescription>
      </CardHeader>
      <CardContent className="flex items-center gap-2">
        <Select value={selectedCourier} onValueChange={setSelectedCourier}>
          <SelectTrigger>
            <SelectValue placeholder="Select a courier" />
          </SelectTrigger>
          <SelectContent>
            {couriers.map((courier) => (
              <SelectItem key={courier.id} value={courier.id}>
                {courier.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button onClick={downloadReport} disabled={isLoading} isLoading={isLoading}>
          Download
        </Button>
      </CardContent>
    </Card>
  );
}
