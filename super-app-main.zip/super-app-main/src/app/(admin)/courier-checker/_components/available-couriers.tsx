import { Skeleton } from "@/components/ui/skeleton";
import { Courier } from "@/db/types";
import { getSignedUrl } from "@/lib/s3";
import Image from "next/image";
import { useMemo } from "react";

interface Props {
  isLoading?: boolean;
  couriers: Pick<Courier, "id" | "name" | "image">[];
}

export function AvailableCouriers({ isLoading, couriers }: Props) {
  const uniqueCouriers = useMemo(
    () => couriers.filter((courier, index, array) => array.findIndex((c) => c.name === courier.name) === index),
    [couriers]
  );

  if (isLoading) {
    return (
      <div>
        <div className="flex flex-wrap gap-2">
          {Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="border bg-secondary rounded-md p-1 flex gap-2 items-center">
              <Skeleton className="rounded-md w-10 h-10" />
              <Skeleton className="h-4 w-20" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {uniqueCouriers.map((courier) => {
          return (
            <div key={courier.id} className="border bg-secondary rounded-md p-1 flex gap-2 items-center">
              <Image
                className="rounded-md"
                src={getSignedUrl(courier.image)}
                alt={courier.name}
                width={40}
                height={40}
              />
              <h4 className="text-sm p-1">{courier.name}</h4>
            </div>
          );
        })}
      </div>
      {uniqueCouriers.length === 0 && (
        <div className="border border-dashed px-4 py-10 w-full rounded-lg text-center">
          <h4 className="text-sm p-1">No couriers available</h4>
        </div>
      )}
    </div>
  );
}
