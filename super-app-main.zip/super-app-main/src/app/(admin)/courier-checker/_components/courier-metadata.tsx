"use client";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CourierServiceData } from "@/types/shipping";

interface Props {
  metadata: CourierServiceData["metadata"];
}

export function CourierMetadata({ metadata }: Props) {
  if (!metadata || metadata.length === 0) return null;

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Key</TableHead>
          <TableHead>Value</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {metadata.map((meta, index) => (
          <TableRow key={meta.key + index}>
            <TableCell>{meta.key}</TableCell>
            <TableCell>{meta.value}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
