import { z } from "zod";

export const courierCheckerSchema = z
  .object({
    orderNumber: z.string(),
    box: z.string(),
    weight: z.coerce.number<number>(),
    trackingNumber: z.string().optional(),
    packedBy: z.string(),
    shippingType: z.string(),
    scannedBy: z.string(),
    nonPriorityReason: z.string().nullable(),
    priorityNumber: z.coerce.number<number>().min(1, { message: "Priority number must be at least 1" }),
  })
  .superRefine((values, form) => {
    if (values.trackingNumber?.length && (values.trackingNumber.length < 5 || values.trackingNumber.length > 15)) {
      form.addIssue({
        code: "custom",
        message: "Tracking number must be between 5 and 15 characters long",
      });
    }
    if (values.trackingNumber && !/^[A-Za-z0-9]+$/.test(values.trackingNumber)) {
      form.addIssue({
        code: "custom",
        message: "Tracking number can only contain letters and numbers",
      });
    }
  });

export type CourierCheckerSchema = z.infer<typeof courierCheckerSchema>;

export const defaultFormValues: Partial<CourierCheckerSchema> = {
  weight: 0,
  box: "",
  trackingNumber: "",
  packedBy: undefined,
  shippingType: "normal",
  scannedBy: undefined,
  priorityNumber: undefined,
  orderNumber: "",
  nonPriorityReason: null,
};
