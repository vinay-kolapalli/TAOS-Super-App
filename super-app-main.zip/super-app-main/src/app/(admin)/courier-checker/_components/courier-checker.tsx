import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CourierCheckerForm } from "./courier-checker-form";
import { FetchOrdersButton } from "./fetch-orders-button";

export function CourierChecker() {
  return (
    <Card>
      <CardHeader className="flex md:flex-row gap-5 justify-between">
        <div>
          <CardTitle>Courier Checker</CardTitle>
          <CardDescription className="mt-1">Find the best courier for printed and reship orders.</CardDescription>
        </div>
        <div>
          <FetchOrdersButton />
        </div>
      </CardHeader>
      <CardContent>
        <CourierCheckerForm />
      </CardContent>
    </Card>
  );
}
