import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CalculatedRate } from "@/types/shipping";

interface Props {
  rates: CalculatedRate[];
  isLoading: boolean;
}

export function CourierPriorityList({ rates, isLoading }: Props) {
  if (!isLoading && rates.length === 0) {
    return (
      <div className="border border-dashed rounded-lg p-8 text-center">
        <p className="text-sm text-muted-foreground">
          Select an order, choose a box, add weight, and wait for rates to load.
        </p>
      </div>
    );
  }

  return (
    <div className="w-[calc(100dvw-80px)] md:w-full">
      <Table>
        <TableHeader>
          <TableRow className="*:whitespace-nowrap">
            <TableHead>#</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Slab</TableHead>
            <TableHead>Rate</TableHead>
            <TableHead>Platform</TableHead>
            <TableHead>Zone</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading
            ? Array.from({ length: 5 }).map((_, index) => (
                <TableRow key={index}>
                  <TableCell>
                    <Skeleton className="h-4 w-8" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-20" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-16" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-12" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-14" />
                  </TableCell>
                  <TableCell>
                    <Skeleton className="h-4 w-14" />
                  </TableCell>
                </TableRow>
              ))
            : rates.map((rate, index) => (
                <TableRow key={rate.key} className="*:whitespace-nowrap">
                  <TableCell>{index + 1}</TableCell>
                  <TableCell>{rate.displayName}</TableCell>
                  <TableCell>{rate.slab}</TableCell>
                  <TableCell>{rate.rate.toFixed(1)}</TableCell>
                  <TableCell className="capitalize">{rate.courier.platform ?? "-"}</TableCell>
                  <TableCell className="capitalize">{rate.zone}</TableCell>
                </TableRow>
              ))}
        </TableBody>
      </Table>
    </div>
  );
}
