export const shippingTypes = [
  {
    id: "normal",
    name: "Normal",
  },
  {
    id: "reship",
    name: "Reship",
  },
];

export const packgedBy = [
  {
    name: "Akshaya",
    value: "akshaya",
  },
  {
    name: "Anapurna",
    value: "anapurna",
  },
  {
    name: "Priti",
    value: "priti",
  },
  {
    name: "Latha 2",
    value: "latha2",
  },
  {
    name: "Krishnaveni",
    value: "krishnaveni",
  },
  {
    name: "Ratna",
    value: "ratna",
  },
];

export const scannedBy = [
  {
    name: "Aravind",
    value: "aravind",
  },
  {
    name: "Manish",
    value: "manish",
  },
  {
    name: "Rahul",
    value: "rahul",
  },
  {
    name: "Srimukh",
    value: "srimukh",
  },
  {
    name: "Naveen",
    value: "naveen",
  },
  {
    name: "Mahesh",
    value: "mahesh",
  },
  {
    name: "Manoj",
    value: "manoj",
  },
  {
    name: "Santosh",
    value: "santosh",
  },
  {
    name: "Manohar",
    value: "manohar",
  },
];

export const nonPriorityReasons = [
  "Reship Order",
  "No Service Available with Priority Courier",
  "Customer Requested Specific Courier",
  "Weekly 3 days service only in TCS",
  "Weekly 2 days service only in TCS",
  "Postal address so shipping through Amazon",
  "Amazon pick is done for the day",
  "Volumetric Issue",
  "Aggregator Error",
  "Above Category Weight",
  "Last option India Post",
];
