import { db } from "@/db";
import { getSession } from "@/lib/auth";
import { CourierChecker } from "./_components/courier-checker";
import { OrderCourierDetails } from "./_components/order-courier-details";
import { OrdersReport } from "./_components/orders-report";
import PincodeReport from "./_components/pincode-report";
import { CourierCheckerContextProvider } from "./_context/courier-checker";

async function Page() {
  const { boxes, warehouse, couriers } = await getCourierCheckerData();

  return (
    <CourierCheckerContextProvider boxes={boxes} warehouse={warehouse} couriers={couriers}>
      <div className="grid flex-1 items-start gap-4 lg:grid-cols-2">
        <div className="space-y-5">
          <CourierChecker />
          <OrdersReport couriers={couriers} />
        </div>
        <div className="space-y-5">
          <PincodeReport />
          <OrderCourierDetails />
        </div>
      </div>
    </CourierCheckerContextProvider>
  );
}

export default Page;

async function getCourierCheckerData() {
  const session = await getSession();

  const boxes = await db.query.boxes.findMany({
    limit: 500,
    columns: {
      id: true,
      name: true,
      length: true,
      breadth: true,
      height: true,
      volumetricWeight: true,
    },
    where(fields, operators) {
      return operators.eq(fields.isActive, true);
    },
  });

  const warehouse = await db.query.warehouses.findFirst({
    columns: {
      id: true,
      name: true,
    },
    where(fields, operators) {
      return operators.eq(fields.id, session?.user.primaryWarehouse!);
    },
  });
  if (!warehouse) {
    throw new Error("Warehouse not found");
  }

  const couriers = await db.query.couriers.findMany({
    limit: 500,
    columns: {
      id: true,
      name: true,
    },
    where(fields, operators) {
      return operators.eq(fields.isActive, true);
    },
  });

  return { boxes, warehouse, couriers };
}
