import { escapeCSVField } from "@/lib/utils";
import { Order } from "@/types/order";
import { format } from "date-fns";

export const courierCSVFormats: Partial<Record<string | "default", { header: string; formatRow: Function }>> = {
  "shree-maruti-courier": {
    header:
      "Order Number,Order Id,Awb No.,Name,Addess1,Address2,City,Pin,State,Country,Tel,Landline,Weight,Value,Courier Name,Service Type,Parcel By,Item Count,Payment,Pod Required,Content\n",
    formatRow: (order: Order, trackingNumber: string, weight: string, name: string) =>
      [
        order.number,
        order.id,
        trackingNumber,
        name,
        order.shipping.address1,
        order.shipping.address2,
        order.shipping.city,
        order.shipping.postcode,
        order.shipping.state,
        order.shipping.country,
        order.billing.phone,
        "",
        weight,
        order.calculations.total,
        "",
        "",
        "",
        "SURFACE",
        "1",
        "DP",
        "Y",
        "",
      ]
        .map(escapeCSVField)
        .join(","),
  },
  dtdc: {
    header:
      "Order Number,Customer Reference Number,Consignment Number,Consignee Name,Destination Address Line 1,Destination Address Line 2,Destination Pincode,Consignee Phone,Weight(KG) (non-document),Courier Type,Service Type,Number of Pieces (non-document),Content Type,Declared Price (non-document),Risk Surcharge (YES/NO) (non-document),Eway Bill\n",
    formatRow: (order: Order, trackingNumber: string, weight: string, name: string, box: string) => {
      const courierType = box === "env" ? "DOCUMENT" : "NON-DOCUMENT";
      const serviceType = trackingNumber.startsWith("D") ? "GROUND EXPRESS" : "STD EXP-A";
      const addressLine1 = `${order.shipping.address1}, ${order.shipping.address2}`;

      return [
        order.number,
        order.id,
        trackingNumber,
        name,
        addressLine1,
        order.shipping.state,
        order.shipping.postcode,
        order.billing.phone,
        weight,
        courierType,
        serviceType,
        "1",
        "SEEDS",
        "1",
        "NO",
        "",
      ]
        .map(escapeCSVField)
        .join(",");
    },
  },
  default: {
    header:
      "Order Number,Order Id,Tracking Number,Name,Address Line 1,Address Line 2,State,City,Pincode,Phone,Weight\n",
    formatRow: (order: Order, trackingNumber: string, weight: string, name: string) =>
      [
        order.number,
        order.id,
        trackingNumber,
        name,
        order.shipping.address1,
        order.shipping.address2,
        order.shipping.state,
        order.shipping.city,
        order.shipping.postcode,
        order.billing.phone,
        weight,
      ]
        .map(escapeCSVField)
        .join(","),
  },
};

export async function downloadOrdersReport(orders: Order[], selectedCourier: string) {
  // Get the appropriate CSV format for the selected courier
  const csvFormat = courierCSVFormats[selectedCourier as keyof typeof courierCSVFormats] || courierCSVFormats.default;
  const currentDate = format(new Date(), "yyyy-MM-dd");

  if (!csvFormat) throw new Error("No CSV format found for the selected courier");

  // Format rows for CSV
  const formatOrderRow = (order: Order) => {
    const name = `${order.shipping.firstName} ${order.shipping.lastName}`;
    return csvFormat.formatRow(
      order,
      String(order.tracking?.trackingNumber),
      String(order.tracking?.weight),
      name,
      order.tracking?.box
    );
  };

  // Generate CSV content
  const csvRows = orders.map(formatOrderRow).join("\n");

  // Download the CSV file
  const blob = new Blob([csvFormat.header + csvRows], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${selectedCourier}-orders-${currentDate}.csv`;
  link.click();
}
