import { tryCatch } from "@/lib/try-catch";
import { fetchShippingOrders } from "@/utils/orders";

export async function fetchLatestOrders() {
  const printedOrders = await tryCatch(
    fetchShippingOrders({
      status: "printed",
      perPage: 250,
    })
  );
  if (printedOrders.error) {
    throw new Error("Failed to fetch printed orders");
  }

  const reshippedOrders = await tryCatch(
    fetchShippingOrders({
      status: "reship",
      perPage: 250,
    })
  );
  if (reshippedOrders.error) {
    throw new Error("Failed to fetch reshipped orders");
  }

  return [...printedOrders.data.orders, ...reshippedOrders.data.orders];
}
