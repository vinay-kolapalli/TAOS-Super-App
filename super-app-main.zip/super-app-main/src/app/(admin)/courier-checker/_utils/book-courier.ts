import { CourierPlatforms } from "@/data/shipping";
import { orpc } from "@/lib/orpc/client";
import { CreateAmazonOrderPayload } from "@/schema/shipping/amazon";
import { CreateDelhiveryOrderPayload } from "@/schema/shipping/delhivery";
import { CreateFshipOrderPayload } from "@/schema/shipping/fship";
import { CreateIThinkLogisticsOrderPayload } from "@/schema/shipping/ithink-logistics";
import { CreateShiphereOrderPayload } from "@/schema/shipping/shiphere";
import { CreateShiprocketOrderPayload } from "@/schema/shipping/shiprocket";
import { CreateShipwayOrderPayload } from "@/schema/shipping/shipway";
import { ShippingOrder } from "@/types/order";
import { splitTextWithoutBreakingWords } from "@/utils/text";
import { safe } from "@orpc/client";

interface Courier {
  id: string;
  length: number;
  breadth: number;
  height: number;
  weight: number;
  platformId?: string;
}

interface Data {
  courier: Courier;
  order: ShippingOrder;
}

export async function bookShiprocketCourier({ courier, order }: Data) {
  const shiprocketPayload: CreateShiprocketOrderPayload = {
    order_id: String(order.number),
    order_date: order.createdAt,
    pickup_location: "1ST",
    sub_total: order.calculations.total,
    payment_method: order.isPaid ? "Prepaid" : "COD",
    billing_customer_name: order.shipping.firstName,
    billing_last_name: order.shipping.lastName,
    billing_address: order.shipping.address1,
    billing_address_2: order.shipping.address2,
    billing_city: order.shipping.city,
    billing_pincode: order.shipping.postcode,
    billing_state: order.shipping.state,
    billing_country: order.shipping.country,
    billing_email: order.shipping.email,
    billing_phone: order.shipping.phone,
    shipping_is_billing: true,
    order_items: [
      {
        name: "Live Plants",
        sku: "Live plants",
        units: 1,
        selling_price: Number(order.calculations.total),
      },
    ],
    length: courier.length,
    breadth: courier.breadth,
    height: courier.height,
    weight: courier.weight,
  };

  const response = await safe(
    orpc.shipping.shiprocket.ship({
      ...shiprocketPayload,
      courierId: Number(courier.platformId),
    })
  );

  return response;
}

export async function bookShipwayCourier({ courier, order }: Data) {
  const shipwayPayload: CreateShipwayOrderPayload = {
    carrier_id: Number(courier.platformId),
    warehouse_id: 0,
    return_warehouse_id: 0,
    order_id: String(order.number),
    products: order.lineItems.map((item) => ({
      product: item.name,
      product_code: item.sku,
      product_quantity: String(item.quantity),
      price: String(item.price),
    })),
    shipping_address: order.shipping.address1,
    shipping_address2: order.shipping.address2,
    shipping_city: order.shipping.city,
    shipping_state: order.shipping.state,
    shipping_country: order.shipping.country,
    shipping_firstname: order.shipping.firstName,
    shipping_lastname: order.shipping.lastName,
    shipping_phone: String(order.shipping.phone),
    shipping_zipcode: String(order.shipping.postcode),
    order_weight: courier.weight,
    box_length: courier.length,
    box_breadth: courier.breadth,
    box_height: courier.height,
    order_date: order.createdAt,
    payment_type: order.isPaid ? "P" : "C",
    email: order.shipping.email,
    order_total: String(order.calculations.total),
  };

  const response = await safe(orpc.shipping.shipway.ship(shipwayPayload));
  return response;
}

export async function bookShiphereCourier({ courier, order }: Data) {
  const shipherePayload: CreateShiphereOrderPayload = {
    customerName: `${order.shipping.firstName} ${order.shipping.lastName}`,
    customerEmail: order.shipping.email,
    pincode: String(order.shipping.postcode),
    city: order.shipping.city,
    productName: "Live Plants",
    productPrice: order.calculations.total,
    orderId: String(order.number),
    customerPhone: String(order.shipping.phone),
    address: `${order.shipping.address1} ${order.shipping.address2}`,
    landMark: "",
    state: order.shipping.state,
    quantity: 1,
    sku: "LIVE_PLANT",
    length: courier.length,
    breadth: courier.breadth,
    height: courier.height,
    weight: courier.weight,
    paymentMethod: "prepaid",
    warehouseId: "",
    courierCode: Number(courier.platformId),
  };
  const response = await safe(orpc.shipping.shiphere.ship(shipherePayload));
  return response;
}

export async function bookDelhiveryCourier({ courier, order }: Data) {
  const delhiveryPayload: CreateDelhiveryOrderPayload = {
    shipments: [
      {
        name: `${order.shipping.firstName} ${order.shipping.lastName}`,
        order: String(order.number),
        phone: String(order.shipping.phone),
        add: `${order.shipping.company} ${order.shipping.address1} ${order.shipping.address2}`,
        city: order.shipping.city,
        state: order.shipping.state,
        country: order.shipping.country,
        pin: order.shipping.postcode,
        shipping_mode: "Surface",
        weight: courier.weight * 1000,
        shipment_height: courier.height,
        shipment_width: courier.breadth,
        shipment_length: courier.length,
        total_amount: order.calculations.total,
        payment_mode: "Prepaid",
      },
    ],
    pickup_location: {
      name: "",
    },
  };
  const response = await safe(orpc.shipping.delhivery.ship(delhiveryPayload));
  return response;
}

export async function bookFshipCourier({ courier, order }: Data) {
  const fshipPayload: CreateFshipOrderPayload = {
    customer_Name: `${order.shipping.firstName} ${order.shipping.lastName}`,
    customer_Mobile: String(order.shipping.phone),
    customer_Emailid: order.shipping.email,
    customer_Address: `${order.shipping.company} ${order.shipping.address1} ${order.shipping.address2}`,
    customer_Address_Type: "Home",
    customer_PinCode: String(order.shipping.postcode),
    customer_City: order.shipping.city,
    orderId: String(order.number),
    payment_Mode: 2,
    express_Type: "surface",
    total_Amount: order.calculations.total,
    shipment_Weight: courier.weight,
    shipment_Length: courier.length,
    shipment_Width: courier.breadth,
    shipment_Height: courier.height,
    pick_Address_ID: 0,
    products: [
      {
        productName: "Live Plants",
        productId: "LIVE_PLANT",
        unitPrice: order.calculations.total,
        quantity: 1,
      },
    ],
    courierId: Number(courier.platformId),
  };
  const response = await safe(orpc.shipping.fship.ship(fshipPayload));
  return response;
}

export async function bookIThinkLogisticsCourier({ courier, order }: Data) {
  const iThinkLogisticsPayload: CreateIThinkLogisticsOrderPayload = {
    access_token: "",
    secret_key: "",
    logistics: courier.platformId as any,
    pickup_address_id: 0,
    order_type: "forward",
    s_type: "surface",
    shipments: [
      {
        waybill: "",
        order: String(order.number),
        sub_order: "",
        order_date: order.createdAt,
        total_amount: order.calculations.total,
        name: `${order.shipping.firstName} ${order.shipping.lastName}`,
        company_name: order.shipping.company,
        add: order.shipping.address1,
        add2: order.shipping.address2,
        add3: "",
        pin: order.shipping.postcode,
        city: order.shipping.city,
        state: order.shipping.state,
        country: order.shipping.country,
        phone: order.shipping.phone,
        alt_phone: order.shipping.phone,
        email: order.shipping.email,
        is_billing_same_as_shipping: "yes",
        billing_name: `${order.shipping.firstName} ${order.shipping.lastName}`,
        billing_company_name: order.shipping.company,
        billing_add: order.shipping.address1,
        billing_add2: order.shipping.address2,
        billing_add3: "",
        billing_pin: order.shipping.postcode,
        billing_city: order.shipping.city,
        billing_state: order.shipping.state,
        billing_country: order.shipping.country,
        billing_phone: order.shipping.phone,
        billing_alt_phone: order.shipping.phone,
        billing_email: order.shipping.email,
        products: [
          {
            product_name: "Live plants",
            product_sku: "",
            product_discount: 0,
            product_hsn_code: "",
            product_img_url: "",
            product_tax_rate: 0,
            product_quantity: 1,
            product_price: order.calculations.total,
          },
        ],
        shipment_length: courier.length,
        shipment_width: courier.breadth,
        shipment_height: courier.height,
        weight: courier.weight,
        payment_mode: "prepaid",
        return_address_id: 0,
        advance_amount: 0,
        cod_amount: 0,
        cod_charges: 0,
        eway_bill_number: "",
        first_attemp_discount: 0,
        giftwrap_charges: 0,
        gst_number: "",
        reseller_name: "",
        shipping_charges: 0,
        total_discount: 0,
        transaction_charges: 0,
        what3words: "",
      },
    ],
  };
  const response = await safe(orpc.shipping.iThinkLogistics.ship(iThinkLogisticsPayload));
  return response;
}

export async function bookAmazonCourier({ courier, order }: Data) {
  const completeAddress = `${order.shipping.address1} ${order.shipping.address2}`.trim();
  const addressLines = splitTextWithoutBreakingWords(completeAddress, 60);

  const address = {
    name: `${order.shipping.firstName} ${order.shipping.lastName}`,
    addressLine1: addressLines[0] || "",
    addressLine2: addressLines[1] || "",
    addressLine3: addressLines[2] || "",
    city: order.shipping.city,
    countryCode: "IN",
    postalCode: String(order.shipping.postcode),
    stateOrRegion: order.shipping.state,
    email: order.shipping.email,
    phoneNumber: String(order.shipping.phone),
  };
  const amazonPayload: CreateAmazonOrderPayload = {
    shipFrom: address,
    shipTo: address,
    packages: [
      {
        dimensions: {
          length: courier.length,
          width: courier.breadth,
          height: courier.height,
          unit: "CENTIMETER",
        },
        weight: {
          unit: "KILOGRAM",
          value: courier.weight,
        },
        insuredValue: {
          value: order.calculations.total,
          unit: "INR",
        },
        sellerDisplayName: "The Affordable Organic Store",
        packageClientReferenceId: String(order.number),
        items: [
          {
            itemValue: {
              value: order.calculations.total,
              unit: "INR",
            },
            description: "Live Plants",
            itemIdentifier: "LIVE_PLANT",
            quantity: 1,
            weight: {
              unit: "KILOGRAM",
              value: courier.weight,
            },
          },
        ],
      },
    ],
    shipmentType: "FORWARD",
    channelDetails: {
      channelType: "EXTERNAL",
    },
  };

  const response = await safe(orpc.shipping.amazon.ship(amazonPayload));
  return response;
}

export async function bookCourier({ courier, order, platform }: Data & { platform: CourierPlatforms }) {
  switch (platform) {
    case "shiprocket":
      return bookShiprocketCourier({ courier, order });
    case "shipway":
      return bookShipwayCourier({ courier, order });
    case "shiphere":
      return bookShiphereCourier({ courier, order });
    case "delhivery":
      return bookDelhiveryCourier({ courier, order });
    case "fship":
      return bookFshipCourier({ courier, order });
    case "ithink-logistics":
      return bookIThinkLogisticsCourier({ courier, order });
    case "amazon":
      return bookAmazonCourier({ courier, order });
  }
}
