import { CalculatedRate } from "@/types/shipping";

interface FormData {
  orderId: number;
  orderNumber: number;
  pincode: number;
  packedBy: string;
  scannedBy: string;
  trackingNumber: string;
  weight: number;
  box: string;
  shippingType: string;
  priority: number;
  rates: CalculatedRate[];
  warehouseId: number;
}

export async function sendDataToForm({
  orderId,
  orderNumber,
  pincode,
  packedBy,
  scannedBy,
  trackingNumber,
  weight,
  box,
  shippingType,
  rates,
  priority,
  warehouseId,
}: FormData): Promise<void> {
  try {
    const selectedRate = rates[priority - 1];
    const firstPriorityRate = rates[0];
    const rateDiff = selectedRate.rate - firstPriorityRate.rate;

    const formUrl = new URL(
      "https://docs.google.com/forms/d/e/1FAIpQLSfRFdmrL_c9fDOAw15eTbT-9kAPVMQa_zzvMIsFqOosk23utQ/formResponse"
    );
    formUrl.searchParams.set("usp", "pp_url");
    formUrl.searchParams.set("entry.1867316051", String(orderNumber));
    formUrl.searchParams.set("entry.1450255535", packedBy);
    formUrl.searchParams.set("entry.979971854", scannedBy);
    formUrl.searchParams.set("entry.646037410", selectedRate.courier.id);
    formUrl.searchParams.set("entry.1205827284", trackingNumber);
    formUrl.searchParams.set("entry.1474917235", String(weight));
    formUrl.searchParams.set("entry.1836512347", box);
    formUrl.searchParams.set("entry.1137411062", shippingType);
    formUrl.searchParams.set("entry.415037483", String(orderId));
    formUrl.searchParams.set("entry.1554558461", String(priority));
    formUrl.searchParams.set("entry.1102743531", String(rateDiff));
    formUrl.searchParams.set("entry.101343128", String(pincode));
    formUrl.searchParams.set("entry.853058517", String(warehouseId));
    formUrl.searchParams.set("entry.1640254056", String(firstPriorityRate.courier.platform));
    formUrl.searchParams.set("entry.197968048", String(firstPriorityRate.rate));
    formUrl.searchParams.set("entry.1322002959", String(firstPriorityRate.courier.id));
    formUrl.searchParams.set("entry.305180163", String(selectedRate.rate));
    formUrl.searchParams.set("entry.1446118071", String(firstPriorityRate.courier.platform));

    await fetch(formUrl);
  } catch (error) {}
}
