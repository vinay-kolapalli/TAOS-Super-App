"use client";
import {
  courierCheckerSchema,
  CourierCheckerSchema,
  defaultFormValues,
} from "@/app/(admin)/courier-checker/_components/schema";
import { Box, Courier, Warehouse } from "@/db/types";
import { useCourierService } from "@/hooks/courier-service";
import { useRateCalculation } from "@/hooks/rates";
import { ShippingOrder } from "@/types/order";
import { CalculatedRate, CourierServiceData } from "@/types/shipping";
import { zodResolver } from "@hookform/resolvers/zod";
import { createContext, useContext, useMemo, useState } from "react";
import { useForm, UseFormReturn } from "react-hook-form";

type BoxData = Pick<Box, "id" | "name" | "length" | "breadth" | "height" | "volumetricWeight">;
type WarehouseData = Pick<Warehouse, "id" | "name">;
type CourierData = Pick<Courier, "id" | "name">;

interface CourierCheckerContextType {
  form: UseFormReturn<CourierCheckerSchema>;
  orders: ShippingOrder[];
  setOrders: (orders: ShippingOrder[]) => void;
  activeOrder: ShippingOrder | null | undefined;
  rates: CalculatedRate[];
  courierData: CourierServiceData[];
  boxData: BoxData | null | undefined;
  reset: () => void;
  isLoadingCourierData: boolean;
  isLoadingRates: boolean;
  boxes: BoxData[];
  warehouse: WarehouseData;
  couriers: CourierData[];
}

interface Props {
  children: React.ReactNode;
  boxes: BoxData[];
  warehouse: WarehouseData;
  couriers: CourierData[];
}

export const CourierCheckerContext = createContext<CourierCheckerContextType>({
  form: {} as UseFormReturn<CourierCheckerSchema>,
  orders: [],
  setOrders: () => {},
  activeOrder: null,
  rates: [],
  courierData: [],
  boxData: null,
  reset: () => {},
  isLoadingCourierData: false,
  isLoadingRates: false,
  boxes: [],
  warehouse: { id: 0, name: "" },
  couriers: [],
});

export const useCourierChecker = () => useContext(CourierCheckerContext);

export function CourierCheckerContextProvider({ children, boxes, warehouse, couriers }: Props) {
  const [orders, setOrders] = useState<ShippingOrder[]>([]);

  const form = useForm<CourierCheckerSchema>({
    resolver: zodResolver(courierCheckerSchema),
    defaultValues: defaultFormValues,
  });
  const weight = Number(form.watch("weight"));
  const box = form.watch("box");
  const orderNumber = form.watch("orderNumber");

  const activeOrder = useMemo(
    () => orders.find((order) => order.number === Number(orderNumber)),
    [orders, orderNumber]
  );

  const { courierData, isLoading: isLoadingCourierData } = useCourierService({
    pincode: activeOrder?.shipping.postcode,
  });

  const boxData = useMemo(() => boxes.find((b) => b.id === box), [boxes, box]);

  const { data: rates, isFetching: isLoadingRates } = useRateCalculation({
    pincode: activeOrder?.shipping.postcode,
    weight,
    box,
    state: activeOrder?.shipping.stateCode,
    city: activeOrder?.shipping.city,
    shippingMethod: activeOrder?.shippingMethod,
    couriers: courierData,
  });

  function reset() {
    const scannedBy = form.getValues("scannedBy");
    const packedBy = form.getValues("packedBy");
    form.reset({
      ...defaultFormValues,
      nonPriorityReason: null,
      scannedBy: scannedBy,
      packedBy: packedBy,
    });
  }

  return (
    <CourierCheckerContext.Provider
      value={{
        form,
        orders,
        setOrders,
        activeOrder,
        rates: rates || [],
        courierData,
        boxData,
        reset,
        isLoadingCourierData,
        isLoadingRates,
        boxes,
        warehouse,
        couriers,
      }}
    >
      {children}
    </CourierCheckerContext.Provider>
  );
}
