import { orpc } from "@/lib/orpc/client";
import { CalculatedRate } from "@/types/shipping";
import { safe } from "@orpc/client";
import { useRef } from "react";
import toast from "react-hot-toast";
import { useCourierChecker } from "../_context/courier-checker";
import { bookCourier } from "../_utils/book-courier";
import { sendDataToForm } from "../_utils/send-data-to-form";

export function useCourierOperations() {
  const toastIdRef = useRef<string | undefined>(undefined);
  const { activeOrder, form, boxes, boxData, reset, warehouse } = useCourierChecker();

  async function handleCourierBooking(rate: CalculatedRate) {
    const values = form.getValues();
    if (!rate.courier.platform || values.trackingNumber) {
      return values.trackingNumber;
    }

    if (!boxData) {
      toast.error("Box not found", { id: toastIdRef.current });
      return null;
    }

    toastIdRef.current = toast.loading(`Booking ${rate.courier.platform} courier...`, { id: toastIdRef.current });

    const { error, data } = await bookCourier({
      courier: {
        id: rate.courier.id,
        length: boxData.length,
        breadth: boxData.breadth,
        height: boxData.height,
        weight: Math.max(Number(values.weight), boxData.volumetricWeight),
        platformId: rate.courier.platformId,
      },
      order: activeOrder!,
      platform: rate.courier.platform,
    });

    if (error) {
      toast.error(error.message, { id: toastIdRef.current });
      return null;
    }

    window.open(data.data.shippingLabel, "_blank");

    const trackingNumber = data.data.trackingNumber;
    return trackingNumber;
  }

  async function handleOrderShipping(rates: CalculatedRate[], priority: number, trackingNumber: string) {
    const values = form.getValues();

    toastIdRef.current = toast.loading(`Marking order as shipped...`, { id: toastIdRef.current });

    const ratesData = rates.map((r, index) => ({
      courier: r.courier.id,
      courierService: r.courier.service,
      platform: r.courier.platform,
      zone: r.zone,
      priority: index + 1,
      rate: r.rate,
    }));

    const { error, data } = await safe(
      orpc.orders.ship({
        orderId: activeOrder!.id,
        orderNumber: Number(activeOrder!.number),
        pincode: Number(activeOrder!.shipping.postcode),
        trackingNumber,
        isReshipped: values.shippingType === "reship",
        weight: Number(values.weight),
        box: values.box,
        packedBy: values.packedBy,
        scannedBy: values.scannedBy,
        nonPriorityReason: values.nonPriorityReason,
        rates: ratesData,
        priority,
      })
    );

    if (error) {
      toast.error(error.message, { id: toastIdRef.current });
      return;
    }

    await sendDataToForm({
      orderId: activeOrder!.id,
      orderNumber: activeOrder!.number,
      pincode: activeOrder!.shipping.postcode,
      packedBy: values.packedBy,
      scannedBy: values.scannedBy,
      trackingNumber,
      weight: values.weight,
      box: values.box,
      shippingType: values.shippingType === "reship" ? "Reshipped" : "Normal",
      rates,
      priority: values.priorityNumber,
      warehouseId: warehouse.id,
    });

    toast.success(data.message, { id: toastIdRef.current });
    reset();
  }

  async function processOrderFlow(rates: CalculatedRate[], priority: number) {
    toastIdRef.current = toast.loading(`Updating order #${activeOrder!.number}...`, { id: toastIdRef.current });

    const trackingNumber = await handleCourierBooking(rates[priority - 1]);
    if (!trackingNumber) {
      form.setError("trackingNumber", {
        type: "required",
        message: "Tracking number is required",
      });
      return false;
    }
    form.setValue("trackingNumber", trackingNumber);

    await handleOrderShipping(rates, priority, trackingNumber);
  }

  return {
    handleCourierBooking,
    handleOrderShipping,
    processOrderFlow,
  };
}
