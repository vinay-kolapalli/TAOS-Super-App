import { orpc } from "@/lib/orpc/client";
import { tryCatch } from "@/lib/try-catch";
import { fetchOrders } from "@/utils/orders";
import { useState } from "react";
import toast from "react-hot-toast";
import { downloadOrdersReport } from "../_utils/report";

export function useOrderReport() {
  const [selectedCourier, setSelectedCourier] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);

  async function fetchReportOrders(courierId: string) {
    const response = await orpc.orders.shipments.dailyReport({
      courier: courierId,
    });

    if (response.data.length === 0) throw new Error("No orders found");

    const orders = await fetchOrders({
      fetchAllPages: true,
      perPage: 100,
      include: response.data.map((order) => Number(order.orderId)),
    });

    return orders;
  }

  async function downloadReport() {
    setIsLoading(true);
    const { data, error } = await tryCatch(fetchReportOrders(selectedCourier));
    if (error) {
      toast.error(error.message);
      setIsLoading(false);
      return;
    }

    const downloadResponse = await tryCatch(downloadOrdersReport(data?.orders ?? [], selectedCourier));
    if (downloadResponse.error) {
      const parsedError = downloadResponse.error;
      toast.error(parsedError.message);
      setIsLoading(false);
      return;
    }
    setIsLoading(false);
  }

  return {
    downloadReport,
    selectedCourier,
    setSelectedCourier,
    isLoading,
  };
}
