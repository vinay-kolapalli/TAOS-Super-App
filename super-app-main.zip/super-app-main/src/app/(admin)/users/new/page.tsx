import { PageContainer, PageHeader } from "@/components/page";
import { db } from "@/db";
import { UserForm } from "../_components/user-form";

export default async function Page() {
  const warehouses = await db.query.warehouses.findMany({ limit: 500, columns: { id: true, name: true } });

  return (
    <PageContainer>
      <PageHeader title="Create user" description="Create a new user to manage your team and permissions." />
      <UserForm defaultValues={{ permissions: [], otherWarehouses: [] }} warehouses={warehouses} />
    </PageContainer>
  );
}
