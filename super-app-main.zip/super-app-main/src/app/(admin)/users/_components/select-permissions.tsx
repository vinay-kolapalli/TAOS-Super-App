import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { permissionsList } from "@/data/permissions";

interface SelectPermissionsProps {
  permissions: string[];
  setPermissions: (permissions: string[]) => void;
}

export function SelectPermissions({
  permissions,
  setPermissions,
}: SelectPermissionsProps) {
  const handlePermissionChange = (permission: string, checked: boolean) => {
    if (checked) {
      setPermissions([...permissions, permission]);
    } else {
      setPermissions(permissions.filter((p) => p !== permission));
    }
  };

  return (
    <div className="space-y-6">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[200px]">Category</TableHead>
            <TableHead>Permissions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {Object.entries(permissionsList).map(
            ([category, categoryPermissions]) => (
              <TableRow key={category}>
                <TableCell className="font-medium capitalize">
                  {category}
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-4">
                    {Object.entries(categoryPermissions).map(
                      ([action, permission]) => (
                        <div
                          key={permission}
                          className="flex items-center space-x-2"
                        >
                          <Checkbox
                            id={permission}
                            checked={permissions?.includes(permission)}
                            onCheckedChange={(checked) =>
                              handlePermissionChange(
                                permission,
                                checked as boolean,
                              )
                            }
                            className="h-4 w-4"
                          />
                          <Label
                            htmlFor={permission}
                            className="capitalize text-sm text-muted-foreground"
                          >
                            {action}
                          </Label>
                        </div>
                      ),
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ),
          )}
        </TableBody>
      </Table>
    </div>
  );
}
