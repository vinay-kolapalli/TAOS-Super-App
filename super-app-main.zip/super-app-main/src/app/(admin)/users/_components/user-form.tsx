"use client";
import { MultiSelect } from "@/components/multi-select";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { User, Warehouse } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { createUserInputSchema, CreateUserInputSchema } from "@/router/users/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { useRouter } from "next/navigation";
import { useMemo } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { SelectPermissions } from "./select-permissions";

interface Props {
  defaultValues?: Partial<User>;
  warehouses: Pick<Warehouse, "id" | "name">[];
}

export function UserForm({ defaultValues, warehouses }: Props) {
  const router = useRouter();
  const form = useForm<CreateUserInputSchema>({
    resolver: zodResolver(createUserInputSchema),
    defaultValues,
  });

  const role = form.watch("role");
  const permissions = form.watch("permissions") ?? [];

  const warehousesOptions = useMemo(() => {
    return warehouses.map((warehouse) => ({
      label: warehouse.name,
      value: warehouse.id,
    }));
  }, [warehouses]);

  async function onSubmit(values: CreateUserInputSchema) {
    const rpc = defaultValues?.id ? orpc.users.update : orpc.users.create;
    const { error, data } = await safe(
      rpc({
        id: defaultValues?.id!,
        ...values,
      })
    );
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    router.push("/users");
  }

  return (
    <form className="space-y-4" onSubmit={form.handleSubmit(onSubmit)}>
      <Form {...form}>
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input placeholder="John Doe" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input placeholder="demo@example.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="role"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Role</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="primaryWarehouse"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Primary Warehouse</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={String(field.value)}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a warehouse" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {warehousesOptions.map((option) => (
                    <SelectItem value={String(option.value)} key={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="otherWarehouses"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Other Warehouses</FormLabel>
              <MultiSelect
                options={warehousesOptions}
                value={field.value}
                onValueChange={field.onChange}
                placeholder="Select warehouses"
              />
              <FormMessage />
            </FormItem>
          )}
        />
        {role !== "admin" && (
          <SelectPermissions
            permissions={permissions}
            setPermissions={(permissions) => form.setValue("permissions", permissions)}
          />
        )}
        <Button type="submit" disabled={form.formState.isSubmitting} isLoading={form.formState.isSubmitting}>
          Submit
        </Button>
      </Form>
    </form>
  );
}
