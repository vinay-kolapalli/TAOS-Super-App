"use client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { User } from "@/db/types";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import Link from "next/link";
import { UserMenu } from "./user-menu";

export const columns: ColumnDef<User & { primaryWarehouse: { id: number; name: string } }>[] = [
  {
    accessorKey: "name",
    header: "Name",
    cell: ({ row }) => {
      return <div>{row.original.name}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "email",
    header: "Email",
    cell: ({ row }) => {
      return <div>{row.original.email}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "role",
    header: "Role",
    cell: ({ row }) => {
      return (
        <Badge variant={row.original.role === "admin" ? "default" : "secondary"} className="capitalize">
          {row.original.role}
        </Badge>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "createdAt",
    header: "Created At",
    cell: ({ row }) => {
      return <div>{format(row.original.createdAt, "MMM d, yyyy")}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "updatedAt",
    header: "Updated At",
    cell: ({ row }) => {
      return <div>{format(row.original.updatedAt, "MMM d, yyyy")}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "primaryWarehouse",
    header: "Warehouse",
    cell: ({ row }) => {
      return (
        <div>
          {
            <Link className="hover:underline" href={`/warehouses/${row.original.primaryWarehouse.id}`}>
              {row.original.primaryWarehouse.name}
            </Link>
          }
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "actions",
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <UserMenu id={row.original.id}>
            <Button variant="ghost" size="icon">
              <IconDots />
            </Button>
          </UserMenu>
        </div>
      );
    },
    enableSorting: false,
  },
];
