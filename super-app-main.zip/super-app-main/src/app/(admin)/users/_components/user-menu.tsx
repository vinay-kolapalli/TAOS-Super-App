"use client";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { orpc } from "@/lib/orpc/client";
import { safe } from "@orpc/client";
import { IconEdit, IconTrash } from "@tabler/icons-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";

interface UserMenuProps {
  id: string;
  children?: React.ReactNode;
}

export function UserMenu({ id, children }: UserMenuProps) {
  const router = useRouter();

  async function deleteUser() {
    const toastId = toast.loading("Deleting user...");
    const { error, data } = await safe(orpc.users.delete({ id }));
    if (error) {
      toast.error(error.message, { id: toastId });
      return;
    }
    toast.success(data.message, { id: toastId });
    router.refresh();
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>{children}</DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem asChild>
          <Link href={`/users/${id}`}>
            <IconEdit /> Edit
          </Link>
        </DropdownMenuItem>
        <AlertDialogDeleteUser onConfirm={deleteUser}>
          <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
            <IconTrash />
            Delete
          </DropdownMenuItem>
        </AlertDialogDeleteUser>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function AlertDialogDeleteUser({ onConfirm, children }: { onConfirm: () => void; children: React.ReactNode }) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>{children}</AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
          <AlertDialogDescription>
            This action cannot be undone. This will permanently delete the user from the database.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm}>Delete</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
