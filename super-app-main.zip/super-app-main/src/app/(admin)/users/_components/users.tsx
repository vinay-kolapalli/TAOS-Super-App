"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { User } from "@/db/types";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { columns } from "./columns";

interface Props {
  users: (User & { primaryWarehouse: { id: number; name: string } })[];
  totalUsers: number;
  isLoading?: boolean;
}

export function Users({ users, totalUsers, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });

  const table = useReactTable({
    data: users,
    columns,
    pageCount: Math.ceil(totalUsers / pagination.pageSize),
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    state: {
      pagination,
    },
  });

  return <DataTable table={table} isLoading={isLoading} paginationType="numeric" />;
}
