import { PageContainer, PageHeader } from "@/components/page";
import { db } from "@/db";
import { users } from "@/db/schema/auth";
import { eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { UserForm } from "../_components/user-form";

interface Props {
  params: Promise<{
    id: string;
  }>;
}

export default async function Page({ params }: Props) {
  const paramsList = await params;
  const user = await db.query.users.findFirst({
    where: eq(users.id, paramsList.id),
  });

  if (!user) {
    return redirect("/users");
  }

  const warehouses = await db.query.warehouses.findMany({ limit: 500, columns: { id: true, name: true } });

  return (
    <PageContainer>
      <PageHeader title="Edit user" description="Modify and update the user's details." />
      <UserForm defaultValues={user} warehouses={warehouses} />
    </PageContainer>
  );
}
