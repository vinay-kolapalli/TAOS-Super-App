import { Card, CardContent } from "@/components/ui/card";
import { File } from "lucide-react";

export default function Page() {
  return (
    <Card className="w-full h-fit">
      <CardContent className="text-center py-12">
        <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-muted flex items-center justify-center">
          <File className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold mb-2">Select a record</h3>
        <p className="text-muted-foreground mb-6 max-w-md mx-auto">Choose a record to view and manage their data.</p>
      </CardContent>
    </Card>
  );
}
