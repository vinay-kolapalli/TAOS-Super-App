"use client";
import { Button } from "@/components/ui/button";
import { RecoveredProductsRecord } from "@/db/types";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import { RecordMenu } from "./record-menu";

export interface RecoveredProductsRecordWithProduct extends Omit<RecoveredProductsRecord, "product"> {
  product: {
    id: number;
    name: string;
  };
}

export const columns: ColumnDef<RecoveredProductsRecordWithProduct>[] = [
  {
    accessorKey: "date",
    header: "Date",
    cell: ({ row }) => {
      return <div>{format(row.original.date, "dd MMM yyyy HH:mm")}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "name",
    header: "Name",
    cell: ({ row }) => {
      return <div>{row.original.name}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "email",
    header: "Email",
    cell: ({ row }) => {
      return <div>{row.original.email}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "productName",
    header: "Product Name",
    cell: ({ row }) => {
      return (
        <div>
          {row.original.product.name} x {row.original.quantity}
        </div>
      );
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "comments",
    header: "Comments",
    cell: ({ row }) => {
      return (
        <div className="text-sm text-muted-foreground line-clamp-2 w-[30ch] text-wrap">
          {row.original.comments || "-"}
        </div>
      );
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <RecordMenu id={row.original.id}>
            <Button type="button" size="icon" variant="ghost">
              <IconDots />
            </Button>
          </RecordMenu>
        </div>
      );
    },
  },
];
