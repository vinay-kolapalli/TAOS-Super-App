"use client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { IconSearch } from "@tabler/icons-react";
import { useQueryState } from "nuqs";

export function Filters() {
  const [search, setSearch] = useQueryState("search", {
    defaultValue: "",
    shallow: false,
  });

  function handleSearch(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const search = formData.get("search") as string;
    setSearch(search);
  }

  return (
    <div className="w-fit flex gap-2">
      <form className="flex gap-2" onSubmit={handleSearch}>
        <Input type="number" name="search" placeholder="Search" defaultValue={search || ""} />
        <Button variant="outline" size="icon">
          <IconSearch />
        </Button>
      </form>
    </div>
  );
}
