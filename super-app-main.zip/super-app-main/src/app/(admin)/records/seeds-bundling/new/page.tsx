import { PageContainer, PageHeader } from "@/components/page";
import { RecordForm } from "../_components/record-form";

export default function Page() {
  return (
    <PageContainer>
      <PageHeader title="Create Record" description="Add a new seeds data record to the system." />
      <RecordForm />
    </PageContainer>
  );
}
