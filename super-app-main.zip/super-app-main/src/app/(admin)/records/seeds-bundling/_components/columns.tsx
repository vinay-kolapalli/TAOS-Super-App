"use client";
import { Button } from "@/components/ui/button";
import { SeedsBundlingRecord } from "@/db/types";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { format } from "date-fns";
import { RecordMenu } from "./record-menu";

export interface SeedsBundlingRecordWithProduct extends Omit<SeedsBundlingRecord, "product"> {
  product: {
    id: number;
    name: string;
  };
}

export const columns: ColumnDef<SeedsBundlingRecordWithProduct>[] = [
  {
    accessorKey: "date",
    header: "Date",
    cell: ({ row }) => {
      return <div>{format(row.original.date, "dd MMM yyyy HH:mm")}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "name",
    header: "Name",
    cell: ({ row }) => {
      return <div>{row.original.product.name}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "issuedTo",
    header: "Issued To",
    cell: ({ row }) => {
      return <div>{row.original.issuedTo}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "issuedDate",
    header: "Issued Date",
    cell: ({ row }) => {
      return <div>{format(row.original.issuedDate, "dd MMM yyyy HH:mm")}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "weight",
    header: "Weight",
    cell: ({ row }) => {
      return <div>{row.original.weight} kg</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "returnDate",
    header: "Return Date",
    cell: ({ row }) => {
      return <div>{format(row.original.returnDate, "dd MMM yyyy HH:mm")}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "noOfPackets",
    header: "No. of Packets",
    cell: ({ row }) => {
      return <div>{row.original.noOfPackets}</div>;
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <RecordMenu id={row.original.id}>
            <Button type="button" size="icon" variant="ghost">
              <IconDots />
            </Button>
          </RecordMenu>
        </div>
      );
    },
  },
];
