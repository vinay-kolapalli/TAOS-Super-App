import { z } from "zod";

export const upsertRecordSchema = z.object({
  id: z.string().optional(),
  date: z.date(),
  product: z.coerce.number<number>(),
  issuedTo: z.string(),
  issuedDate: z.date(),
  weight: z.coerce.number<number>(),
  returnDate: z.date(),
  noOfPackets: z.coerce.number<number>(),
});
export type UpsertRecordSchema = z.infer<typeof upsertRecordSchema>;
