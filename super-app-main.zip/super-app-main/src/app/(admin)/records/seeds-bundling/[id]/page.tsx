import { PageContainer, PageHeader } from "@/components/page";
import { db } from "@/db";
import { redirect } from "next/navigation";
import { RecordForm } from "../_components/record-form";

interface Props {
  params: Promise<{
    id: string;
  }>;
}

export default async function Page({ params }: Props) {
  const paramsList = await params;
  const record = await db.query.seedsBundlingRecords.findFirst({
    where(fields, operators) {
      return operators.eq(fields.id, paramsList.id);
    },
  });

  if (!record) {
    redirect("/records/seeds-bundling");
  }

  return (
    <PageContainer>
      <PageHeader title="Edit Record" description="Edit a seeds data record in the system." />
      <RecordForm defaultValues={record} />
    </PageContainer>
  );
}
