import { PageContainer, PageHeader } from "@/components/page";
import { db } from "@/db";
import { redirect } from "next/navigation";
import { RecordForm } from "../_components/record-form";

interface Props {
  params: Promise<{
    id: string;
  }>;
}

export default async function Page({ params }: Props) {
  const paramsList = await params;
  const record = await db.query.offlineSalesRecords.findFirst({
    where(fields, operators) {
      return operators.eq(fields.id, paramsList.id);
    },
  });

  if (!record) {
    redirect("/records/offline-sales");
  }

  return (
    <PageContainer>
      <PageHeader title="Edit Record" description="Edit a offline sales record in the system." />
      <RecordForm defaultValues={record} />
    </PageContainer>
  );
}
