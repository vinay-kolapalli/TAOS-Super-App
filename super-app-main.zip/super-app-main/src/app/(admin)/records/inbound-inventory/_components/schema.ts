import { z } from "zod";

export const upsertRecordSchema = z.object({
  id: z.string().optional(),
  date: z.date(),
  name: z.string(),
  email: z.string(),
  product: z.coerce.number<number>(),
  poNumber: z.string(),
  quantityOrdered: z.number(),
  quantityReceived: z.number(),
  quantityUpdated: z.number(),
  reason: z.string(),
  comments: z.string(),
});
export type UpsertRecordSchema = z.infer<typeof upsertRecordSchema>;
