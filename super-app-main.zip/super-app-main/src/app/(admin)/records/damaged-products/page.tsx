import { ExportOptions } from "@/components/export-options";
import { Button } from "@/components/ui/button";
import { db } from "@/db";
import { products } from "@/db/schema/products";
import { damagedProductsRecords } from "@/db/schema/records";
import { and, count, desc, eq, getTableColumns, ilike, or } from "drizzle-orm";
import { nanoid } from "nanoid";
import Link from "next/link";
import { Suspense } from "react";
import { Filters } from "../_components/filters";
import { Records } from "./_components/records";

interface Props {
  searchParams: Promise<{
    page: string;
    per_page: string;
    search: string;
  }>;
}

export default function Page(props: Props) {
  return (
    <div className="space-y-4 w-full">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-lg font-bold">Damaged Products</h2>
        <div className="flex gap-4 justify-between flex-wrap">
          <Filters />
          <ExportOptions type="damaged-products" />
          <Link href="./damaged-products/new">
            <Button>Create</Button>
          </Link>
        </div>
      </div>
      <Suspense key={nanoid()} fallback={<Records records={[]} totalRecords={0} isLoading={true} />}>
        <PageWithFetch {...props} />
      </Suspense>
    </div>
  );
}

async function PageWithFetch({ searchParams }: Props) {
  const searchParamsList = await searchParams;
  const page = Number(searchParamsList.page ?? 1);
  const per_page = Number(searchParamsList.per_page ?? 10);
  const search = searchParamsList.search ?? "";

  const where = and(
    search
      ? or(
          ilike(products.name, `%${search}%`),
          ilike(damagedProductsRecords.email, `%${search}%`),
          ilike(damagedProductsRecords.name, `%${search}%`),
          ilike(damagedProductsRecords.comments, `%${search}%`)
        )
      : undefined
  );

  const recordsData = await db
    .select({
      ...getTableColumns(damagedProductsRecords),
      product: {
        id: products.id,
        name: products.name,
      },
    })
    .from(damagedProductsRecords)
    .innerJoin(products, eq(damagedProductsRecords.product, products.id))
    .where(where)
    .orderBy(desc(damagedProductsRecords.id))
    .limit(per_page)
    .offset((page - 1) * per_page);

  const [totalRecords] = await db
    .select({ count: count() })
    .from(damagedProductsRecords)
    .innerJoin(products, eq(damagedProductsRecords.product, products.id))
    .where(where);

  return <Records records={recordsData} totalRecords={totalRecords.count} />;
}
