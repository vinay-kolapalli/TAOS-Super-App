"use client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { orpc } from "@/lib/orpc/client";
import { safe } from "@orpc/client";
import { IconEdit, IconTrash } from "@tabler/icons-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";

interface Props {
  id: string;
  children: React.ReactNode;
}

export function RecordMenu({ id, children }: Props) {
  const router = useRouter();

  async function handleDelete() {
    const { error, data } = await safe(orpc.records.damagedProducts.delete({ id }));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    router.refresh();
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>{children}</DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem asChild>
          <Link href={`./damaged-products/${id}`} className="flex items-center gap-2">
            <IconEdit className="h-4 w-4" />
            Edit
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleDelete} className="text-destructive">
          <IconTrash />
          Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
