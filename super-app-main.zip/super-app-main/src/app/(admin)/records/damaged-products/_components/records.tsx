"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { columns, DamagedProductsRecordWithProduct } from "./columns";

interface Props {
  records: DamagedProductsRecordWithProduct[];
  totalRecords: number;
  isLoading?: boolean;
}

export function Records({ records, totalRecords, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });

  const table = useReactTable({
    data: records,
    pageCount: Math.ceil(totalRecords / pagination.pageSize),
    columns,
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    state: {
      pagination,
    },
  });

  return (
    <DataTable
      table={table}
      paginationType="numeric"
      isLoading={isLoading}
      extraPaginationOptions={[150, 200, 250, 500]}
    />
  );
}
