import { Zones } from "@/data/shipping";
import { db } from "@/db";
import { zoneMappings } from "@/db/schema/pincodes";
import { getWarehouseOptions } from "@/db/utils/warehouse";
import { and, asc, count, eq } from "drizzle-orm";
import { nanoid } from "nanoid";
import { Suspense } from "react";
import { Actions } from "./_components/actions";
import CourierNotAvailable from "./_components/courier-not-available";
import { Header } from "./_components/header";
import { ZoneMappings } from "./_components/zone-mappings";

interface Props {
  params: Promise<{ id: string }>;
  searchParams: Promise<{
    page?: string;
    per_page?: string;
    search?: string;
    zone?: string;
    warehouse?: string;
  }>;
}

export default async function Page(props: Props) {
  const { id } = await props.params;

  const [courier, warehouses] = await Promise.all([
    db.query.couriers.findFirst({
      where(fields, operators) {
        return operators.eq(fields.id, id);
      },
    }),
    getWarehouseOptions(),
  ]);

  if (
    !courier ||
    (!courier.serviceabilityCheck.includes("pincode") && !courier.serviceabilityCheck.includes("always_available"))
  ) {
    return <CourierNotAvailable />;
  }

  return (
    <div className="w-full space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <Header courier={courier} />
        <Actions courier={courier} warehouses={warehouses} />
      </div>
      <Suspense
        key={nanoid()}
        fallback={<ZoneMappings zoneMappings={[]} warehouses={warehouses} totalZoneMappings={0} isLoading={true} />}
      >
        <PageWithFetch {...props} warehouses={warehouses} />
      </Suspense>
    </div>
  );
}

async function PageWithFetch({ params, searchParams, warehouses }: Props & { warehouses: any }) {
  const { id } = await params;
  const searchParamsList = await searchParams;

  const page = Number(searchParamsList.page || 1);
  const perPage = Number(searchParamsList.per_page || 10);
  const search = searchParamsList.search || "";
  const zone = searchParamsList.zone || "";
  const warehouse = searchParamsList.warehouse || "";

  const offset = (page - 1) * perPage;

  const whereConditions = [eq(zoneMappings.courier, id)];

  if (search) {
    whereConditions.push(eq(zoneMappings.pincode, Number(search)));
  }

  if (zone) {
    whereConditions.push(eq(zoneMappings.zone, zone as Zones));
  }

  if (warehouse) {
    whereConditions.push(eq(zoneMappings.warehouse, Number(warehouse)));
  }

  const [mappings, [{ count: totalCount }]] = await Promise.all([
    db.query.zoneMappings.findMany({
      where: and(...whereConditions),
      limit: perPage,
      offset,
      orderBy: [asc(zoneMappings.pincode)],
      with: {
        warehouse: {
          columns: { id: true, name: true },
        },
      },
    }),
    db
      .select({ count: count() })
      .from(zoneMappings)
      .where(and(...whereConditions)),
  ]);

  return <ZoneMappings zoneMappings={mappings} warehouses={warehouses} totalZoneMappings={totalCount} />;
}
