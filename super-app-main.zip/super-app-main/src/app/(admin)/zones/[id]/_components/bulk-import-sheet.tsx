"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { SelectOption } from "@/types/general";
import { useRouter } from "next/navigation";
import { BulkImportForm } from "./bulk-import-form";

interface Props {
  courierId: string;
  courierName: string;
  warehouses: SelectOption[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function BulkImportSheet({ courierId, courierName, warehouses, open, onOpenChange }: Props) {
  const router = useRouter();

  function handleSuccess() {
    onOpenChange(false);
    router.refresh();
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-md">
        <SheetHeader>
          <SheetTitle>Import Zone Mappings</SheetTitle>
          <SheetDescription>Bulk import zone mappings for {courierName} using a CSV file.</SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          <Instructions />
          <BulkImportForm courierId={courierId} warehouses={warehouses} onSuccess={handleSuccess} />
        </div>
      </SheetContent>
    </Sheet>
  );
}

function Instructions() {
  return (
    <Card>
      <CardHeader className="p-4">
        <CardTitle>CSV Format</CardTitle>
        <CardDescription>
          Upload a CSV file with pincode and zone information. If a record already exists, it will be updated.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <code className="text-xs bg-secondary border p-2 rounded-md block">
          pincode,zone,warehouse_id
          <br />
          110001,local,1
          <br />
          110002,regional,2
        </code>
      </CardContent>
    </Card>
  );
}
