"use client";
import { AlertModal } from "@/components/alert-modal";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Courier } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { safe } from "@orpc/client";
import { IconDots, IconTrash } from "@tabler/icons-react";
import { useRouter } from "next/navigation";
import { toast } from "react-hot-toast";

interface Props {
  courier: Pick<Courier, "id" | "name">;
  pincodesCount: number;
}

export function BulkActions({ courier, pincodesCount }: Props) {
  const router = useRouter();

  async function handleDeleteAll() {
    const toastId = toast.loading(`Deleting ${pincodesCount} pincodes...`);
    const { error, data } = await safe(orpc.zones.deleteCourier({ id: courier.id }));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message, { id: toastId });
    router.refresh();
  }

  if (pincodesCount === 0) {
    return null;
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon">
          <IconDots />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <AlertModal
          onConfirm={handleDeleteAll}
          title="Delete All Pincodes"
          description={`Are you sure you want to delete all ${pincodesCount} pincodes for ${courier.name}? This action cannot be undone.`}
        >
          <DropdownMenuItem className="text-destructive" onSelect={(e) => e.preventDefault()}>
            <IconTrash />
            Delete All
          </DropdownMenuItem>
        </AlertModal>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
