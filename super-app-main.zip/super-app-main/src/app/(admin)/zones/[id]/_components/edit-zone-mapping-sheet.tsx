"use client";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { ZoneMapping } from "@/db/types";
import { SelectOption } from "@/types/general";
import { useRouter } from "next/navigation";
import { ZoneMappingForm } from "./zone-mapping-form";

interface Props {
  zoneMapping: ZoneMapping;
  warehouses: SelectOption[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function EditZoneMappingSheet({ zoneMapping, warehouses, open, onOpenChange }: Props) {
  const router = useRouter();

  function handleSuccess() {
    onOpenChange(false);
    router.refresh();
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Edit Zone Mapping</SheetTitle>
          <SheetDescription>Update the zone mapping for pincode {zoneMapping.pincode}.</SheetDescription>
        </SheetHeader>

        <div className="mt-6">
          <ZoneMappingForm warehouses={warehouses} defaultValues={zoneMapping} onSuccess={handleSuccess} />
        </div>
      </SheetContent>
    </Sheet>
  );
}
