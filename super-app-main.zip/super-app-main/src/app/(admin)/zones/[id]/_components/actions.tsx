import { Search } from "@/components/search";
import { Courier } from "@/db/types";
import { SelectOption } from "@/types/general";
import { AddZoneMappingButton } from "./add-zone-mapping-button";
import { ZoneFilters } from "./zone-filters";

interface Props {
  courier: Pick<Courier, "id" | "name">;
  warehouses: SelectOption[];
}

export function Actions({ courier, warehouses }: Props) {
  return (
    <div className="flex gap-4 flex-wrap">
      <Search shallow={false} />
      <ZoneFilters warehouses={warehouses} />
      <AddZoneMappingButton courier={courier} warehouses={warehouses} />
    </div>
  );
}
