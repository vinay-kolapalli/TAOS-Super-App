"use client";
import { Courier } from "@/db/types";
import { getSignedUrl } from "@/lib/s3";
import Image from "next/image";

interface Props {
  courier: Pick<Courier, "id" | "name" | "image">;
}

export function Header({ courier }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <div className="w-8 h-8 relative">
        <Image src={getSignedUrl(courier.image)} alt={courier.name} fill className="object-contain rounded-md" />
      </div>
      <div>
        <h2 className="text-base md:text-lg font-bold">{courier.name}</h2>
        <p className="text-xs md:text-sm text-muted-foreground">
          Manage pincode to zone mappings • For serviceability, visit{" "}
          <a href={`/pincodes/${courier.id}`} className="text-primary underline">
            Pincodes
          </a>
        </p>
      </div>
    </div>
  );
}
