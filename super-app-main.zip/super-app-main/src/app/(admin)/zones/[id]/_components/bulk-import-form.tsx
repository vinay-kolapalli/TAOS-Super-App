"use client";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { zones } from "@/data/shipping";
import { orpc } from "@/lib/orpc/client";
import { SelectOption } from "@/types/general";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { bulkImportSchema, BulkImportSchema } from "./schema";

interface Props {
  courierId: string;
  warehouses: SelectOption[];
  onSuccess: () => void;
}

export function BulkImportForm({ courierId, warehouses, onSuccess }: Props) {
  const form = useForm<BulkImportSchema>({
    resolver: zodResolver(bulkImportSchema),
  });
  const { isSubmitting } = form.formState;

  function parseCSVFile(text: string) {
    const lines = text
      .trim()
      .split("\n")
      .filter((line) => line.trim());
    if (lines.length === 0) {
      throw new Error("File is empty");
    }

    const headers = lines[0].split(",").map((h) => h.trim());

    // Validate headers
    const requiredHeaders = ["pincode", "zone", "warehouse_id"];
    const missingHeaders = requiredHeaders.filter((h) => !headers.includes(h));
    if (missingHeaders.length > 0) {
      throw new Error(`Missing required columns: ${missingHeaders.join(", ")}`);
    }

    const mappings = [];
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(",").map((v) => v.trim());
      const row: Record<string, string> = {};

      headers.forEach((header, index) => {
        row[header] = values[index] || "";
      });

      // Validate data
      const pincode = parseInt(row.pincode);
      if (isNaN(pincode) || pincode < 100000 || pincode > 999999) {
        throw new Error(`Invalid pincode at row ${i + 1}: ${row.pincode}`);
      }

      if (!zones.includes(row.zone as any)) {
        throw new Error(`Invalid zone at row ${i + 1}: ${row.zone}. Valid zones: ${zones.join(", ")}`);
      }

      const warehouseId = parseInt(row.warehouse_id);
      if (isNaN(warehouseId) || warehouseId < 1) {
        throw new Error(`Invalid warehouse_id at row ${i + 1}: ${row.warehouse_id}`);
      }

      // Check if warehouse exists
      const warehouseExists = warehouses.some((w) => w.value === String(warehouseId));
      if (!warehouseExists) {
        throw new Error(`Warehouse with ID ${warehouseId} not found at row ${i + 1}`);
      }

      mappings.push({
        pincode,
        zone: row.zone as any,
        courier: courierId,
        warehouse: warehouseId,
      });
    }

    if (mappings.length === 0) {
      throw new Error("No valid data found in CSV");
    }

    return mappings;
  }

  async function handleFileUpload(values: BulkImportSchema) {
    try {
      const file = values.file;
      const text = await file.text();

      const mappings = parseCSVFile(text);

      const { error, data } = await safe(orpc.zones.create(mappings));
      if (error) {
        toast.error(error.message);
        return;
      }

      toast.success(data.message);
      onSuccess();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to import zone mappings";
      form.setError("file", { message });
    }
  }

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue("file", file);
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFileUpload)} className="space-y-4">
        <FormField
          control={form.control}
          name="file"
          render={() => (
            <FormItem>
              <FormLabel>CSV File</FormLabel>
              <FormControl>
                <Input type="file" accept=".csv" onChange={handleFileSelect} className="cursor-pointer" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button disabled={isSubmitting} isLoading={isSubmitting} className="w-full">
          Import Zone Mappings
        </Button>
      </form>
    </Form>
  );
}
