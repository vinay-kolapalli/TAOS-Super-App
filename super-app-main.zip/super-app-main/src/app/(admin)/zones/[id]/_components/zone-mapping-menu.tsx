"use client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ZoneMapping } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { SelectOption } from "@/types/general";
import { safe } from "@orpc/client";
import { IconEdit, IconTrash } from "@tabler/icons-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "react-hot-toast";
import { EditZoneMappingSheet } from "./edit-zone-mapping-sheet";

interface Props {
  children: React.ReactNode;
  zoneMapping: ZoneMapping;
  warehouses: SelectOption[];
}

export function ZoneMappingMenu({ children, zoneMapping, warehouses }: Props) {
  const [isEditOpen, setIsEditOpen] = useState(false);
  const router = useRouter();

  async function handleDelete() {
    const { error, data } = await safe(orpc.zones.delete({ ids: [zoneMapping.id] }));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    router.refresh();
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>{children}</DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setIsEditOpen(true)}>
            <IconEdit className="mr-2 h-4 w-4" />
            Edit
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleDelete} className="text-destructive">
            <IconTrash className="mr-2 h-4 w-4" />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <EditZoneMappingSheet
        zoneMapping={zoneMapping}
        warehouses={warehouses}
        open={isEditOpen}
        onOpenChange={setIsEditOpen}
      />
    </>
  );
}
