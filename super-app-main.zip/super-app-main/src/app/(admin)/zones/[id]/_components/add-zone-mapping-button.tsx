"use client";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Courier } from "@/db/types";
import { SelectOption } from "@/types/general";
import { IconFile, IconPlus } from "@tabler/icons-react";
import { useState } from "react";
import { AddZoneMappingSheet } from "./add-zone-mapping-sheet";
import { BulkImportSheet } from "./bulk-import-sheet";

interface Props {
  courier: Pick<Courier, "id" | "name">;
  warehouses: SelectOption[];
}

export function AddZoneMappingButton({ courier, warehouses }: Props) {
  const [showAddSheet, setShowAddSheet] = useState(false);
  const [showImportSheet, setShowImportSheet] = useState(false);

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button>Add Zone Mapping</Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setShowAddSheet(true)}>
            <IconPlus />
            Add Zone Mapping
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setShowImportSheet(true)}>
            <IconFile />
            Bulk Import
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <AddZoneMappingSheet
        courierId={courier.id}
        warehouses={warehouses}
        open={showAddSheet}
        onOpenChange={setShowAddSheet}
      />
      <BulkImportSheet
        courierId={courier.id}
        courierName={courier.name}
        warehouses={warehouses}
        open={showImportSheet}
        onOpenChange={setShowImportSheet}
      />
    </>
  );
}
