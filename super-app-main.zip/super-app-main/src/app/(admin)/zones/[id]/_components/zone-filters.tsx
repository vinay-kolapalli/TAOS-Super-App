"use client";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { zoneOptions } from "@/data/shipping";
import { SelectOption } from "@/types/general";
import { useQueryState } from "nuqs";

interface Props {
  warehouses: SelectOption[];
}

export function ZoneFilters({ warehouses }: Props) {
  const [zone, setZone] = useQueryState("zone", { defaultValue: "all", shallow: false });
  const [warehouse, setWarehouse] = useQueryState("warehouse", { defaultValue: "all", shallow: false });

  function updateZone(value: string) {
    setZone(value === "all" ? null : value);
  }

  function updateWarehouse(value: string) {
    setWarehouse(value === "all" ? null : value);
  }

  return (
    <div className="flex gap-2 items-center">
      <Select value={zone || ""} onValueChange={updateZone}>
        <SelectTrigger className="w-32 ">
          <SelectValue placeholder="Zone" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Zones</SelectItem>
          {zoneOptions.map((zone) => (
            <SelectItem key={zone.value} value={zone.value}>
              {zone.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select value={warehouse || ""} onValueChange={updateWarehouse}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Warehouse" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Warehouses</SelectItem>
          {warehouses.map((warehouse) => (
            <SelectItem key={warehouse.value} value={warehouse.value}>
              {warehouse.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
