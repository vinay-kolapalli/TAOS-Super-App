"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { ZoneMapping } from "@/db/types";
import { SelectOption } from "@/types/general";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { BulkSelectedActions } from "./bulk-selected-actions";
import { getColumns } from "./columns";

interface Props {
  zoneMappings: (ZoneMapping & { warehouse: { id: number; name: string } | null })[];
  warehouses: SelectOption[];
  totalZoneMappings: number;
  isLoading?: boolean;
}

export function ZoneMappings({ zoneMappings, warehouses, totalZoneMappings, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });
  const [rowSelection, setRowSelection] = useState({});
  const router = useRouter();

  const columns = getColumns(warehouses);

  const table = useReactTable({
    data: zoneMappings,
    columns,
    pageCount: Math.ceil(totalZoneMappings / pagination.pageSize),
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    onRowSelectionChange: setRowSelection,
    enableRowSelection: true,
    state: {
      pagination,
      rowSelection,
    },
  });

  const selectedZoneMappings = table.getFilteredSelectedRowModel().rows.map((row) => row.original);

  function handleApply() {
    setRowSelection({});
    table.resetRowSelection();
    router.refresh();
  }

  return (
    <div className="space-y-4">
      {selectedZoneMappings.length > 0 && (
        <BulkSelectedActions selectedZoneMappings={selectedZoneMappings} onApply={handleApply} />
      )}
      <DataTable className="w-full" table={table} isLoading={isLoading} paginationType="numeric" />
    </div>
  );
}
