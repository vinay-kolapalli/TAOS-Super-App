"use client";
import { AlertModal } from "@/components/alert-modal";
import { Button } from "@/components/ui/button";
import { ZoneMapping } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { safe } from "@orpc/client";
import { IconTrash } from "@tabler/icons-react";
import { useRouter } from "next/navigation";
import { toast } from "react-hot-toast";

interface Props {
  selectedZoneMappings: ZoneMapping[];
  onApply: () => void;
}

export function BulkSelectedActions({ selectedZoneMappings, onApply }: Props) {
  const router = useRouter();

  async function handleBulkDelete() {
    const ids = selectedZoneMappings.map((mapping) => mapping.id);
    const { error, data } = await safe(orpc.zones.delete({ ids }));
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    onApply();
  }

  return (
    <div className="flex items-center justify-between p-2 bg-muted rounded-lg">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium">
          {selectedZoneMappings.length} pincode{selectedZoneMappings.length > 1 ? "s" : ""} selected
        </span>
      </div>
      <div className="flex items-center gap-2">
        <AlertModal
          onConfirm={handleBulkDelete}
          title="Delete Zone Mappings"
          description={`Are you sure you want to delete ${selectedZoneMappings.length} zone mapping${
            selectedZoneMappings.length === 1 ? "" : "s"
          }? This action cannot be undone.`}
        >
          <Button variant="destructive" size="sm">
            <IconTrash />
            Delete Selected
          </Button>
        </AlertModal>
      </div>
    </div>
  );
}
