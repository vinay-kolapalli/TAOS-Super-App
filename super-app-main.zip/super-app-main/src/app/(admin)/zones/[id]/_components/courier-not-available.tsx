import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";

export default function CourierNotAvailable() {
  return (
    <Card>
      <CardContent className="text-center py-12">
        <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center">
          <AlertTriangle className="text-destructive" />
        </div>
        <h3 className="text-lg font-semibold mb-2">Courier Not Available</h3>
        <p className="text-muted-foreground mb-6 max-w-md mx-auto">
          This courier is not available or does not support pincode-based serviceability checks. Please select a
          different courier from the sidebar.
        </p>
      </CardContent>
    </Card>
  );
}
