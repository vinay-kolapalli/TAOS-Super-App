"use client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ZoneMapping } from "@/db/types";
import { SelectOption } from "@/types/general";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { ZoneMappingMenu } from "./zone-mapping-menu";

type ZoneMappingWithWarehouse = ZoneMapping & { warehouse: { id: number; name: string } | null };

export const getColumns = (warehouses: SelectOption[]): ColumnDef<ZoneMappingWithWarehouse>[] => [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={table.getIsAllPageRowsSelected() || (table.getIsSomePageRowsSelected() && "indeterminate")}
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "pincode",
    header: "Pincode",
    cell: ({ row }) => {
      return <div className="font-mono text-sm">{row.original.pincode}</div>;
    },
    enableSorting: true,
  },
  {
    accessorKey: "zone",
    header: "Zone",
    cell: ({ row }) => {
      const zone = row.original.zone;
      const zoneColors = {
        local: "bg-green-100 text-green-800",
        regional: "bg-blue-100 text-blue-800",
        metro: "bg-purple-100 text-purple-800",
        "rest-of-india": "bg-orange-100 text-orange-800",
        "north-east": "bg-red-100 text-red-800",
      };

      return (
        <Badge variant="outline" className={zoneColors[zone] || "bg-gray-100 text-gray-800"}>
          {zone.toUpperCase()}
        </Badge>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "warehouse",
    header: "Warehouse",
    cell: ({ row }) => {
      const warehouse = row.original.warehouse;
      if (!warehouse) {
        return <span className="text-muted-foreground">No warehouse</span>;
      }

      return (
        <div className="flex items-center gap-2">
          <span className="text-sm">{warehouse.name}</span>
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "actions",
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <ZoneMappingMenu zoneMapping={row.original} warehouses={warehouses}>
            <Button variant="ghost" size="icon">
              <IconDots />
            </Button>
          </ZoneMappingMenu>
        </div>
      );
    },
    enableSorting: false,
  },
];
