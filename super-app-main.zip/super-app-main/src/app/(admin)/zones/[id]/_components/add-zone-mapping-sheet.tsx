"use client";

import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { SelectOption } from "@/types/general";
import { useRouter } from "next/navigation";
import { ZoneMappingForm } from "./zone-mapping-form";

interface Props {
  courierId: string;
  warehouses: SelectOption[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddZoneMappingSheet({ courierId, warehouses, open, onOpenChange }: Props) {
  const router = useRouter();

  function handleSuccess() {
    onOpenChange(false);
    router.refresh();
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Add Zone Mapping</SheetTitle>
          <SheetDescription>
            Create a new zone mapping by assigning a pincode to a delivery zone and warehouse.
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6">
          <ZoneMappingForm
            defaultValues={{
              courier: courierId,
            }}
            warehouses={warehouses}
            onSuccess={handleSuccess}
          />
        </div>
      </SheetContent>
    </Sheet>
  );
}
