"use client";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { zoneOptions } from "@/data/shipping";
import { ZoneMapping } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { SelectOption } from "@/types/general";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { zoneMappingFormSchema, ZoneMappingFormSchema } from "./schema";

interface Props {
  warehouses: SelectOption[];
  defaultValues?: Partial<ZoneMapping>;
  onSuccess?: () => void;
}

export function ZoneMappingForm({ warehouses, defaultValues, onSuccess }: Props) {
  const form = useForm<ZoneMappingFormSchema>({
    resolver: zodResolver(zoneMappingFormSchema),
    defaultValues,
  });
  const { isSubmitting } = form.formState;

  async function onSubmit(values: ZoneMappingFormSchema) {
    const rpc = defaultValues ? orpc.zones.update : orpc.zones.create;
    if (!defaultValues?.courier) {
      toast.error("Courier is required");
      return;
    }

    const { error, data } = await safe(
      rpc([
        {
          pincode: values.pincode,
          zone: values.zone,
          courier: defaultValues.courier,
          warehouse: values.warehouse,
        },
      ])
    );
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    onSuccess?.();
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
      <Form {...form}>
        <FormField
          control={form.control}
          name="pincode"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Pincode</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  placeholder="Enter pincode (e.g., 110001)"
                  {...field}
                  disabled={!!defaultValues}
                  readOnly={!!defaultValues}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="zone"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Zone</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a zone" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {zoneOptions.map((zone) => (
                    <SelectItem key={zone.value} value={zone.value}>
                      {zone.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="warehouse"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Warehouse</FormLabel>
              <Select onValueChange={(value) => field.onChange(Number(value))} defaultValue={String(field.value)}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a warehouse" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {warehouses.map((warehouse) => (
                    <SelectItem key={warehouse.value} value={warehouse.value}>
                      {warehouse.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button disabled={isSubmitting} isLoading={isSubmitting} className="w-full">
          Submit
        </Button>
      </Form>
    </form>
  );
}
