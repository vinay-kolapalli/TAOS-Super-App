import { zones } from "@/data/shipping";
import { z } from "zod";

export const zoneMappingFormSchema = z.object({
  pincode: z.coerce.number<number>().min(100000).max(999999),
  zone: z.enum(zones),
  warehouse: z.coerce.number<number>().min(1),
});

export type ZoneMappingFormSchema = z.infer<typeof zoneMappingFormSchema>;

export const bulkImportSchema = z.object({
  file: z
    .instanceof(File)
    .refine((file) => {
      return file.size > 0;
    }, "Please select a file")
    .refine((file) => {
      return file.type === "text/csv" || file.name.endsWith(".csv");
    }, "Please select a CSV file"),
});

export type BulkImportSchema = z.infer<typeof bulkImportSchema>;
