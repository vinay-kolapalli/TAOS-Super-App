import { NotAllowed } from "@/components/not-allowed";
import { SidebarNav } from "@/components/sidebar/sidebar-nav";
import { permissionsList } from "@/data/permissions";
import { db } from "@/db";
import { couriers } from "@/db/schema/shipping";
import { isUserAllowed } from "@/lib/auth";
import { arrayContains, or } from "drizzle-orm";
import React from "react";

export default async function Layout({ children }: { children: React.ReactNode }) {
  const { isAllowed } = await isUserAllowed(permissionsList.zones.read);
  if (!isAllowed) {
    return <NotAllowed />;
  }

  const couriersData = await db.query.couriers.findMany({
    columns: { id: true, name: true },
    limit: 500,
    where: or(
      arrayContains(couriers.serviceabilityCheck, ["pincode"]),
      arrayContains(couriers.serviceabilityCheck, ["always_available"])
    ),
  });

  const sidebarMenu = couriersData.map((courier) => ({
    href: `/zones/${courier.id}`,
    title: courier.name,
  }));

  return (
    <div className="grid grid-rows-[auto_1fr] lg:grid-cols-[200px_1fr] gap-4 w-full">
      <aside className="lg:sticky lg:top-6 h-fit">
        <SidebarNav items={sidebarMenu} />
      </aside>
      <div className="flex-1">{children}</div>
    </div>
  );
}
