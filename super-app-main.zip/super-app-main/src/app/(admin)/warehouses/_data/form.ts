import { CreateWarehouseInputSchema } from "@/router/warehouses/schema";

export const platformFields: {
  id: keyof CreateWarehouseInputSchema["metadata"];
  label: string;
  placeholder: string;
}[] = [
  {
    id: "shiprocketWarehouseId",
    label: "Shiprocket Warehouse",
    placeholder: "warehouse-name",
  },
  {
    id: "shipwayWarehouseId",
    label: "Shipway Warehouse",
    placeholder: "warehouse-id",
  },
  {
    id: "shiphereWarehouseId",
    label: "Shiphere Warehouse",
    placeholder: "warehouse-id",
  },
  {
    id: "delhiveryWarehouseId",
    label: "Delhivery Warehouse",
    placeholder: "warehouse-name",
  },
  {
    id: "fshipWarehouseId",
    label: "Fship Warehouse",
    placeholder: "warehouse-id",
  },
  {
    id: "iThinkLogisticsWarehouseId",
    label: "iThinkLogistics Warehouse",
    placeholder: "warehouse-id",
  },
];
