import { Search } from "@/components/search";
import { Button } from "@/components/ui/button";
import { db } from "@/db";
import { warehouses } from "@/db/schema/warehouse";
import { asc, count } from "drizzle-orm";
import { nanoid } from "nanoid";
import Link from "next/link";
import { Suspense } from "react";
import { Warehouses } from "./_components/warehouses";

export default function Page() {
  return (
    <div className="w-full space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-lg font-bold">Warehouses</h2>
        <div className="flex gap-4 flex-wrap">
          <Search shallow={false} />
          <Link href="/warehouses/new">
            <Button>Create</Button>
          </Link>
        </div>
      </div>
      <Suspense key={nanoid()} fallback={<Warehouses warehouses={[]} totalWarehouses={0} isLoading={true} />}>
        <PageWithFetch />
      </Suspense>
    </div>
  );
}

async function PageWithFetch() {
  const warehousesData = await db.query.warehouses.findMany({ limit: 500, orderBy: [asc(warehouses.id)] });
  const [totalWarehouses] = await db.select({ count: count() }).from(warehouses);

  return <Warehouses warehouses={warehousesData} totalWarehouses={totalWarehouses.count} />;
}
