import { PageContainer, PageHeader } from "@/components/page";
import { db } from "@/db";
import { warehouses } from "@/db/schema/warehouse";
import { getCourierOptions } from "@/db/utils/shipping";
import { eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { WarehouseForm } from "../_components/warehouse-form";

interface Props {
  params: Promise<{
    id: string;
  }>;
}

export default async function Page({ params }: Props) {
  const paramsList = await params;
  const warehouse = await db.query.warehouses.findFirst({
    where: eq(warehouses.id, parseInt(paramsList.id)),
  });

  if (!warehouse) {
    return redirect("/warehouses");
  }

  const couriers = await getCourierOptions();

  return (
    <PageContainer>
      <PageHeader title="Edit warehouse" description="Modify and update the warehouse's details." />
      <WarehouseForm couriers={couriers} defaultValues={warehouse} />
    </PageContainer>
  );
}
