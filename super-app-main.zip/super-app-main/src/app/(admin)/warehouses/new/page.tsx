import { PageContainer, PageHeader } from "@/components/page";
import { getCourierOptions } from "@/db/utils/shipping";
import { WarehouseForm } from "../_components/warehouse-form";

export default async function Page() {
  const couriers = await getCourierOptions();

  return (
    <PageContainer>
      <PageHeader title="Create warehouse" description="Create a new warehouse to manage your inventory and orders." />
      <WarehouseForm
        defaultValues={{
          availableCouriers: [],
          availablePlatforms: [],
        }}
        couriers={couriers}
      />
    </PageContainer>
  );
}
