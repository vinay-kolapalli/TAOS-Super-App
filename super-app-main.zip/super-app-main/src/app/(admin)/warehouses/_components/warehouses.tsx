"use client";
import { DataTable, usePaginationSearchParams } from "@/components/ui/data-table";
import { Warehouse } from "@/db/types";
import { getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { columns } from "./columns";

interface Props {
  warehouses: Warehouse[];
  totalWarehouses: number;
  isLoading?: boolean;
}

export function Warehouses({ warehouses, totalWarehouses, isLoading }: Props) {
  const [pagination, setPagination] = usePaginationSearchParams({ shallow: false });

  const table = useReactTable({
    data: warehouses,
    columns,
    pageCount: Math.ceil(totalWarehouses / pagination.pageSize),
    getCoreRowModel: getCoreRowModel(),
    manualPagination: true,
    onPaginationChange: setPagination,
    state: {
      pagination,
    },
  });

  return <DataTable table={table} isLoading={isLoading} paginationType="numeric" />;
}
