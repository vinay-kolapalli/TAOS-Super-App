"use client";
import { MultiSelect } from "@/components/multi-select";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { courierPlatformsOptions } from "@/data/shipping";
import { statesList } from "@/data/states";
import { Warehouse } from "@/db/types";
import { orpc } from "@/lib/orpc/client";
import { createWarehouseInputSchema, CreateWarehouseInputSchema } from "@/router/warehouses/schema";
import { SelectOption } from "@/types/general";
import { zodResolver } from "@hookform/resolvers/zod";
import { safe } from "@orpc/client";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { platformFields } from "../_data/form";

interface Props {
  defaultValues?: Partial<Warehouse>;
  couriers: SelectOption[];
}

export function WarehouseForm({ defaultValues, couriers }: Props) {
  const router = useRouter();
  const form = useForm<CreateWarehouseInputSchema>({
    resolver: zodResolver(createWarehouseInputSchema),
    defaultValues,
  });

  async function onSubmit(values: CreateWarehouseInputSchema) {
    const rpc = defaultValues?.id ? orpc.warehouses.update : orpc.warehouses.create;
    const { error, data } = await safe(
      rpc({
        id: defaultValues?.id!,
        ...values,
      })
    );
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(data.message);
    router.push("/warehouses");
  }

  return (
    <form className="space-y-4" onSubmit={form.handleSubmit(onSubmit)}>
      <Form {...form}>
        <Tabs defaultValue="basic" className="w-full">
          <TabsList>
            <TabsTrigger value="basic">Basic</TabsTrigger>
            <TabsTrigger value="address">Address</TabsTrigger>
            <TabsTrigger value="metadata">Metadata</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Warehouse 1" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="spocName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SPOC Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John" {...field} value={field.value} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone</FormLabel>
                  <FormControl>
                    <Input placeholder="+91 9876543210" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="availableCouriers"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Available Couriers</FormLabel>
                  <FormControl>
                    <MultiSelect
                      options={couriers}
                      value={field.value}
                      onValueChange={field.onChange}
                      placeholder="Select couriers"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="availablePlatforms"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Available Platforms</FormLabel>
                  <FormControl>
                    <MultiSelect
                      options={courierPlatformsOptions}
                      value={field.value}
                      onValueChange={field.onChange}
                      placeholder="Select platforms"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </TabsContent>

          <TabsContent value="address" className="space-y-4">
            <FormField
              control={form.control}
              name="address1"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Address Line 1</FormLabel>
                  <FormControl>
                    <Input placeholder="Street address" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="address2"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Address Line 2</FormLabel>
                  <FormControl>
                    <Input placeholder="Apartment, suite, etc." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>City</FormLabel>
                  <FormControl>
                    <Input placeholder="Mumbai" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="state"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>State</FormLabel>
                  <FormControl>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select state" />
                      </SelectTrigger>
                      <SelectContent>
                        {statesList.map((state) => (
                          <SelectItem key={state.stateCode} value={state.stateCode}>
                            {state.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="country"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Country</FormLabel>
                  <FormControl>
                    <Input placeholder="India" {...field} readOnly disabled />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="pincode"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pincode</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="400703" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </TabsContent>

          <TabsContent value="metadata" className="space-y-4">
            <FormField
              control={form.control}
              name="metadata.storeId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Store ID</FormLabel>
                  <FormControl>
                    <Input placeholder="store-id" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            {platformFields.map((platformField) => (
              <FormField
                key={platformField.id}
                control={form.control}
                name={`metadata.${platformField.id}`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{platformField.label}</FormLabel>
                    <FormControl>
                      <Input placeholder={platformField.placeholder} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            ))}
          </TabsContent>
        </Tabs>

        <Button type="submit" disabled={form.formState.isSubmitting} isLoading={form.formState.isSubmitting}>
          Submit
        </Button>
      </Form>
    </form>
  );
}
