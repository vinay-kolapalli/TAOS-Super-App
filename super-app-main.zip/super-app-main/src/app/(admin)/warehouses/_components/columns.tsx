"use client";
import { Button } from "@/components/ui/button";
import { Warehouse } from "@/db/types";
import { IconDots } from "@tabler/icons-react";
import { ColumnDef } from "@tanstack/react-table";
import { WarehouseMenu } from "./warehouse-menu";

export const columns: ColumnDef<Warehouse>[] = [
  {
    accessorKey: "id",
    header: "Id",
    cell: ({ row }) => {
      return <div>{row.original.id}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "name",
    header: "Name",
    cell: ({ row }) => {
      return <div>{row.original.name}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "pincode",
    header: "Pincode",
    cell: ({ row }) => {
      return <div>{row.original.pincode}</div>;
    },
    enableSorting: false,
  },
  {
    accessorKey: "actions",
    header: "Actions",
    cell: ({ row }) => {
      return (
        <div>
          <WarehouseMenu id={row.original.id}>
            <Button variant="ghost" size="icon">
              <IconDots />
            </Button>
          </WarehouseMenu>
        </div>
      );
    },
    enableSorting: false,
  },
];
