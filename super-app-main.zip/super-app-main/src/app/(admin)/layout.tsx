import { LayoutHeader } from "@/components/layout-header";
import { AppSidebar } from "@/components/sidebar/app-sidebar";
import { ThemeProvider } from "@/components/theme-provider";
import { SidebarProvider } from "@/components/ui/sidebar";
import { ReactQueryContext } from "@/context/react-query-context";
import { getSession } from "@/lib/auth";
import { cookies } from "next/headers";
import NextTopLoader from "nextjs-toploader";
import { NuqsAdapter } from "nuqs/adapters/next/app";

async function Layout({ children }: { children: React.ReactNode }) {
  const cookieStore = await cookies();
  const sidebarState = cookieStore.get("sidebar:state");
  const session = await getSession();

  if (!session) {
    throw new Error("User not found");
  }

  return (
    <NuqsAdapter>
      <ReactQueryContext>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <SidebarProvider
            defaultOpen={
              typeof sidebarState?.value === "string"
                ? sidebarState.value === "true"
                : true
            }
          >
            <NextTopLoader
              color="currentColor"
              height={6}
              easing="ease-in-out"
              speed={400}
              crawl
              crawlSpeed={400}
            />
            {/* @ts-expect-error BetterAuth types are incorrect */}
            <AppSidebar user={session.user} />
            <div className="flex flex-col w-full">
              <LayoutHeader />
              <main className="flex flex-1">{children}</main>
            </div>
          </SidebarProvider>
        </ThemeProvider>
      </ReactQueryContext>
    </NuqsAdapter>
  );
}

export default Layout;
