"use client";
import { reviewDeskSchema, ReviewDeskSchema } from "@/app/(admin)/review-desk/_components/schema";
import { Form } from "@/components/ui/form";
import { useStoreProducts } from "@/hooks/product";
import { GetProductsOutputSchema } from "@/router/store/products/schema";
import { ShippingOrder } from "@/types/order";
import { zodResolver } from "@hookform/resolvers/zod";
import { createContext, useContext, useDeferredValue, useMemo, useState } from "react";
import { useForm } from "react-hook-form";

interface ReviewDeskContextType {
  order: ShippingOrder | null | undefined;
  orders: ShippingOrder[];
  setOrders: (orders: ShippingOrder[]) => void;
  products: GetProductsOutputSchema["data"];
  scannedProducts: GetProductsOutputSchema["data"];
  missingProducts: GetProductsOutputSchema["data"];
  addScannedProducts: (productPermalinks: string[]) => void;
  removeScannedProducts: (productPermalinks: string[]) => void;
  reset: () => void;
}

interface Props {
  children: React.ReactNode;
}

const defaultFormValues: ReviewDeskSchema = {
  orderNumber: "",
  reviewedBy: "ratna",
  scannedProductUrls: "",
};

export const ReviewDeskContext = createContext<ReviewDeskContextType>({
  order: null,
  orders: [],
  setOrders: () => {},
  products: [],
  scannedProducts: [],
  missingProducts: [],
  addScannedProducts: (productPermalinks: string[]) => {},
  removeScannedProducts: (productPermalinks: string[]) => {},
  reset: () => {},
});

export const useReviewDesk = () => useContext(ReviewDeskContext);

export function ReviewDeskContextProvider({ children }: Props) {
  const [orders, setOrders] = useState<ShippingOrder[]>([]);
  const { data: products } = useStoreProducts();

  const form = useForm<ReviewDeskSchema>({
    resolver: zodResolver(reviewDeskSchema),
    defaultValues: defaultFormValues,
  });

  const orderNumber = useDeferredValue(form.watch("orderNumber"));
  const activeOrder = useMemo(
    () => orders.find((order) => order.number === Number(orderNumber)),
    [orders, orderNumber]
  );
  const activeOrderLineItems = useMemo(
    () => new Set(activeOrder?.lineItems.map((item) => item.productId)),
    [activeOrder]
  );

  const scannedProductUrls = useDeferredValue(new Set(form.watch("scannedProductUrls")?.split("\n")));
  const scannedProducts = useMemo(() => {
    return products?.filter((product) => scannedProductUrls.has(product.url) && activeOrderLineItems.has(product.id));
  }, [activeOrderLineItems, products, scannedProductUrls]);
  const missingProducts = useMemo(() => {
    return products?.filter((product) => {
      return !scannedProductUrls.has(product.url) && activeOrderLineItems.has(product.id);
    });
  }, [activeOrderLineItems, products, scannedProductUrls]);

  function addScannedProducts(productPermalinks: string[]) {
    const scannedProductUrls = (form.getValues("scannedProductUrls") ?? "").split("\n");
    const uniqueProductUrls = new Set([...scannedProductUrls.filter(Boolean), ...productPermalinks]);
    form.setValue("scannedProductUrls", Array.from(uniqueProductUrls).join("\n"));
  }

  function removeScannedProducts(productPermalinks: string[]) {
    const scannedProductUrls = (form.getValues("scannedProductUrls") ?? "").split("\n");
    const filteredUrls = scannedProductUrls.filter((url) => !productPermalinks.includes(url) && url);
    form.setValue("scannedProductUrls", filteredUrls.join("\n"));
  }

  function reset() {
    const reviewedBy = form.getValues("reviewedBy");
    form.reset({
      orderNumber: "",
      reviewedBy: reviewedBy,
      scannedProductUrls: "",
    });
  }

  return (
    <ReviewDeskContext.Provider
      value={{
        order: activeOrder,
        orders,
        setOrders,
        products: products ?? [],
        scannedProducts: scannedProducts ?? [],
        missingProducts: missingProducts ?? [],
        addScannedProducts,
        removeScannedProducts,
        reset,
      }}
    >
      <Form {...form}>{children}</Form>
    </ReviewDeskContext.Provider>
  );
}
