import { z } from "zod";

export const reviewDeskSchema = z.object({
  orderNumber: z.string(),
  scannedProductUrls: z.string(),
  reviewedBy: z.string(),
});

export type ReviewDeskSchema = z.infer<typeof reviewDeskSchema>;
