"use client";
import { useReviewDesk } from "@/app/(admin)/review-desk/_context/review-desk";
import { generateShippingLabel } from "@/app/(admin)/review-desk/_utils/generate-shipping-label";
import { Button } from "@/components/ui/button";
import { FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { orpc } from "@/lib/orpc/client";
import { tryCatch } from "@/lib/try-catch";
import { getGrowBagsCount } from "@/utils/grow-bags";
import { printBuffer } from "@/utils/print";
import { safe } from "@orpc/client";
import { useFormContext } from "react-hook-form";
import toast from "react-hot-toast";
import { reviewedBy } from "../_data/options";
import { sendDataToForm } from "../_utils/send-data-to-form";
import { ReviewDeskSchema } from "./schema";

export function ReviewDeskForm() {
  const { order, products, reset } = useReviewDesk();
  const form = useFormContext<ReviewDeskSchema>();
  const { isSubmitting } = form.formState;

  async function handleSubmit(values: ReviewDeskSchema) {
    if (!order) return;
    const toastId = toast.loading("Reviewing order...");
    const scannedProducts = new Set(values.scannedProductUrls.split("\n"));
    const orderProducts = products.filter((product) => scannedProducts.has(product.url));

    const { error, data } = await safe(
      orpc.orders.reviews.create({
        orderId: order.id,
        orderNumber: Number(order.number),
        reviewedBy: values.reviewedBy,
        scannedProducts: orderProducts.map((product) => product.name),
      })
    );
    if (error) {
      toast.error(error.message, { id: toastId });
      return;
    }

    await sendDataToForm({
      products: orderProducts.map((product) => product.name),
      growBags: getGrowBagsCount(order.calculations.total),
      orderNumber: order.number,
      reviewedBy: values.reviewedBy,
    });

    await handlePrint();
    reset();
    toast.success(data.message, { id: toastId });
  }

  async function handlePrint() {
    if (!order) return;
    const isGift = Boolean(order.shippingMethod?.toLowerCase().includes("gift"));
    const shippingLabel = await generateShippingLabel({
      orderNumber: order.number,
      name: order.shipping.firstName + " " + order.shipping.lastName,
      address: order.shipping.address1 + " " + order.shipping.address2,
      city: order.shipping.city,
      state: order.shipping.state,
      postcode: order.shipping.postcode,
      phone: order.shipping.phone,
      isGift,
    });
    const print = await tryCatch(printBuffer(shippingLabel));
    if (print.error) {
      toast.error(print.error.message);
      return;
    }
  }

  return (
    <form className="flex flex-col gap-3" onSubmit={form.handleSubmit(handleSubmit)}>
      <FormField
        control={form.control}
        name="orderNumber"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Order number</FormLabel>
            <FormControl>
              <Input type="text" inputMode="numeric" pattern="[0-9]*" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={form.control}
        name="reviewedBy"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Reviewed by</FormLabel>
            <Select onValueChange={field.onChange} value={field.value}>
              <FormControl>
                <SelectTrigger>
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                {reviewedBy.map((reviewed) => (
                  <SelectItem key={reviewed.value} value={reviewed.value}>
                    {reviewed.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={form.control}
        name="scannedProductUrls"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Scanned Products</FormLabel>
            <FormControl>
              <Textarea {...field} placeholder="Scan products here..." />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <div className="flex gap-2 items-center flex-wrap">
        <Button disabled={!order?.isPaid || isSubmitting}>Submit & Print</Button>
      </div>
      {!order?.isPaid && <p className="text-sm text-muted-foreground">Note: Unpaid orders cannot be reviewed.</p>}
    </form>
  );
}
