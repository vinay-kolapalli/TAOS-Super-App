"use client";
import { Button } from "@/components/ui/button";
import { tryCatch } from "@/lib/try-catch";
import { useState } from "react";
import toast from "react-hot-toast";
import { useReviewDesk } from "../_context/review-desk";
import { fetchLatestOrders } from "../_utils/fetch";

export function FetchOrdersButton() {
  const [isLoading, setIsLoading] = useState(false);
  const { setOrders } = useReviewDesk();

  async function handleFetchOrders() {
    setIsLoading(true);
    const toastId = toast.loading("Fetching orders...");
    const orders = await tryCatch(fetchLatestOrders());
    setIsLoading(false);
    if (orders.error) {
      toast.error("Failed to fetch orders", { id: toastId });
      return;
    }
    setOrders(orders.data);
    toast.success("Orders fetched successfully", { id: toastId });
  }

  return (
    <Button className="w-full" variant="outline" onClick={handleFetchOrders} disabled={isLoading}>
      Fetch Orders
    </Button>
  );
}
