"use client";
import { useReviewDesk } from "@/app/(admin)/review-desk/_context/review-desk";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { GetProductsOutputSchema } from "@/router/store/products/schema";
import { getGrowBagsCount } from "@/utils/grow-bags";
import { IconPlus, IconX } from "@tabler/icons-react";
import { format } from "date-fns";
import { useMemo } from "react";

export function OrderReviewDetails() {
  const { order, missingProducts, scannedProducts, addScannedProducts, removeScannedProducts } = useReviewDesk();
  const growBagsCount = useMemo(() => getGrowBagsCount(Number(order?.calculations.total)), [order?.calculations.total]);

  if (!order) {
    return (
      <div className="border border-dashed rounded-lg p-4 min-h-[200px] flex items-center justify-center">
        <p className="text-sm text-muted-foreground">Enter order number to view review details</p>
      </div>
    );
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader className="flex flex-row items-start bg-muted">
        <div className="grid grid-cols-2 gap-0.5">
          <div className="grid gap-0.5">
            <CardTitle className="text-lg flex gap-2 items-center">
              Order #{order.number} {!order.isPaid && <Badge variant="destructive">Unpaid</Badge>}
            </CardTitle>
            <CardDescription>Date: {format(order.createdAt, "dd MMM yyyy")}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex flex-col gap-4 pt-5">
        <Label>Free Grow Bags: {growBagsCount}</Label>
        <Label className="flex items-center justify-between gap-2">
          Scanned Products{" "}
          <RemoveButton onClick={() => removeScannedProducts(scannedProducts.map((product) => product.url))} />
        </Label>
        <ScrollArea className="h-48">
          <div className="flex flex-col gap-2">
            {scannedProducts.map((product) => (
              <ScannedProduct key={product.id} product={product} />
            ))}
            {scannedProducts.length === 0 && <NoProducts message="No products scanned" />}
          </div>
        </ScrollArea>
        <Label className="flex items-center justify-between gap-2">
          Missing Products{" "}
          <AddButton onClick={() => addScannedProducts(missingProducts.map((product) => product.url))} />
        </Label>
        <ScrollArea className="h-48">
          <div className="flex flex-col gap-2">
            {missingProducts.map((product) => (
              <MissingProduct key={product.id} product={product} />
            ))}
            {missingProducts.length === 0 && <NoProducts message="No missing products" />}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function AddButton({ onClick }: { onClick?: () => void }) {
  return (
    <Button type="button" className="p-1! w-fit h-fit" variant="secondary" size="icon" onClick={onClick}>
      <IconPlus />
    </Button>
  );
}

function RemoveButton({ onClick }: { onClick?: () => void }) {
  return (
    <Button type="button" className="p-1! w-fit h-fit" variant="destructive" size="icon" onClick={onClick}>
      <IconX />
    </Button>
  );
}

function ScannedProduct({ product }: { product: GetProductsOutputSchema["data"][number] }) {
  const { removeScannedProducts } = useReviewDesk();
  return (
    <div className="p-2 text-sm rounded-lg border bg-background flex items-center justify-between">
      {product.name}{" "}
      <RemoveButton
        onClick={() => {
          removeScannedProducts([product.url]);
        }}
      />
    </div>
  );
}

function MissingProduct({ product }: { product: GetProductsOutputSchema["data"][number] }) {
  const { addScannedProducts } = useReviewDesk();
  return (
    <div className="p-2 text-sm rounded-lg border bg-background flex items-center justify-between">
      {product.name}
      <AddButton
        onClick={() => {
          addScannedProducts([product.url]);
        }}
      />
    </div>
  );
}

function NoProducts({ message }: { message: string }) {
  return (
    <div className="p-3 rounded-lg border bg-background text-center h-48 flex items-center justify-center">
      {message}
    </div>
  );
}
