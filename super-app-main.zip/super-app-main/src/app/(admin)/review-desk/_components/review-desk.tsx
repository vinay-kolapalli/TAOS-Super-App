import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FetchOrdersButton } from "./fetch-orders-button";
import { ReviewDeskForm } from "./review-desk-form";

export function ReviewDesk() {
  return (
    <Card>
      <CardHeader className="flex md:flex-row gap-5 justify-between">
        <div>
          <CardTitle>Review Desk</CardTitle>
          <CardDescription className="mt-1">Review and print packing slip for orders.</CardDescription>
        </div>
        <div>
          <FetchOrdersButton />
        </div>
      </CardHeader>
      <CardContent>
        <ReviewDeskForm />
      </CardContent>
    </Card>
  );
}
