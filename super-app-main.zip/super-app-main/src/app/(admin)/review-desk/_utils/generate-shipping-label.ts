import mailToQR from "@/images/mail-to-qr.png";
import jsPDF from "jspdf";
import { generateBarcode } from "../../../../utils/barcode";

interface Data {
  orderNumber: number;
  name: string;
  address: string;
  city: string;
  state: string;
  postcode: number;
  phone: number;
  isGift: boolean;
}

function wrapText(text: string, width: number): string[] {
  const words = text
    .replace(/[\u200B-\u200F\u202A-\u202E\uFEFF]/g, "")
    .trim()
    .split(" ");
  const lines: string[] = [];
  let currentLine = "";

  words.forEach((word) => {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    if (testLine.length <= width) {
      currentLine = testLine;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  });

  if (currentLine) {
    lines.push(currentLine);
  }

  return lines;
}

const FROM_ADDRESS =
  "From: THE AFFORDABLE ORGANIC STORE, #7-8-275, Gowthamnagar, Ferozguda, Hyderabad, Telangana 500011, Ph.040-66588313";

export async function generateShippingLabel(data: Data): Promise<Buffer> {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "in",
    format: [3, 4],
  });

  const normalFont = "helvetica";
  const boldFont = "helvetica";
  const x = 0.1;
  let y = 0.3;

  // Recipient information
  doc.setFont(normalFont, "normal");
  doc.setFontSize(12);
  doc.text("To:", x, y);

  // Name
  const nameLines = wrapText(data.name, 20);
  for (let i = 0; i < nameLines.length; i++) {
    if (i > 0) y += 0.2;
    doc.text(nameLines[i], x + 0.3, y);
  }

  // Address
  const addressLines = wrapText(data.address, 30);
  for (const line of addressLines) {
    y += 0.2;
    doc.text(line, x, y);
  }

  // City, state, postcode
  y += 0.2;
  const locationLines = wrapText(`${data.city}, ${data.state}, ${data.postcode}`, 35);
  for (let i = 0; i < locationLines.length; i++) {
    if (i > 0) y += 0.2;
    doc.text(locationLines[i], x, y);
  }

  // Phone and shipping method
  y += 0.2;
  doc.text("Ph No:", x, y);

  let phoneText = data.phone + " ";

  if (data.isGift) {
    phoneText += "Gift";
  }

  if (data.isGift) {
    doc.setFont(boldFont, "bold");
  }
  doc.text(phoneText, x + 0.6, y);
  doc.setFont(normalFont, "normal");

  // Sender information
  y += 0.15;
  const fromLines = wrapText(FROM_ADDRESS, 45);
  doc.setFontSize(8);
  for (const line of fromLines) {
    y += 0.15;
    doc.text(line, x, y);
  }

  // Barcode - reduced gap between from address and barcode
  y += 0.1;
  const barcode = await generateBarcode(String(data.orderNumber));
  doc.addImage(barcode, "PNG", (3 - 1.67) / 2, y, 1.67, 0.49);

  // QR code and support text
  y += 0.7;
  doc.text("For any feedback or support scan QR code and write to us", 0.06, y);

  y += 0.15;
  const imageRes = await fetch(mailToQR.src);
  const imageBuffer = await imageRes.arrayBuffer();
  const qrBase64 = Buffer.from(imageBuffer).toString("base64");
  doc.addImage(qrBase64, "PNG", 1.15, y, 0.7, 0.7);

  y += 0.85;
  doc.text("Write to us", 1.25, y);

  return Buffer.from(doc.output("arraybuffer"));
}
