interface FormData {
  orderNumber: number;
  growBags: string | number;
  reviewedBy: string;
  products: string[];
}

export async function sendDataToForm(data: FormData) {
  try {
    const formUrl = new URL(
      "https://docs.google.com/forms/d/e/1FAIpQLSeIGu_ApkxidyowzowNyRDTUdYiJVbL7u3_ru-NfdASaV_Yfg/formResponse",
    );
    formUrl.searchParams.set("usp", "pp_url");
    formUrl.searchParams.set("entry.170553110", String(data.orderNumber));
    formUrl.searchParams.set("entry.1048691243", data.reviewedBy);
    formUrl.searchParams.set("entry.2032777150", String(data.growBags));
    formUrl.searchParams.set("entry.501330611", data.products.join(", "));

    await fetch(formUrl);
  } catch (error) {}
}
