import { OrderReviewDetails } from "@/app/(admin)/review-desk/_components/order-review-details";
import { ReviewDeskContextProvider } from "@/app/(admin)/review-desk/_context/review-desk";
import { ReviewDesk } from "./_components/review-desk";

function Page() {
  return (
    <ReviewDeskContextProvider>
      <div className="grid flex-1 items-start gap-4 lg:grid-cols-2 h-fit">
        <div className="space-y-5">
          <ReviewDesk />
        </div>
        <div className="space-y-5">
          <OrderReviewDetails />
        </div>
      </div>
    </ReviewDeskContextProvider>
  );
}

export default Page;
