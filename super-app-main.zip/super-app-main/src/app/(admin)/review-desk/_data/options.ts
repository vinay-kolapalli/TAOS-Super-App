export const reviewedBy = [
  {
    name: "Aravind",
    value: "aravind",
  },
  {
    name: "Manish",
    value: "manish",
  },
  {
    name: "Rahul",
    value: "rahul",
  },
  {
    name: "Srimukh",
    value: "srimukh",
  },
  {
    name: "Naveen",
    value: "naveen",
  },
  {
    name: "Mahesh",
    value: "mahesh",
  },
  {
    name: "Ratna",
    value: "ratna",
  },
];
