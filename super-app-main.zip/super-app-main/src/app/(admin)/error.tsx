"use client";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardTitle,
} from "@/components/ui/card";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <Card className="w-full h-fit">
      <CardContent className="text-center flex flex-col items-center gap-3 max-w-lg mx-auto px-4 py-14">
        <CardTitle className="text-lg">Uh-oh! Something went wrong</CardTitle>
        <CardDescription>
          We&apos;re sorry, but we&apos;re having a little trouble right now.
        </CardDescription>
        <Button onClick={() => reset()}>Try again</Button>
      </CardContent>
    </Card>
  );
}
